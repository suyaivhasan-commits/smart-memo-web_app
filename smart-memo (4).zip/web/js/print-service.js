/**
 * Smart Memo Web - Print & PDF Service
 * Generates high-fidelity A4 and POS 80mm/58mm thermal printouts matching MemoPaperView.kt and PdfPrintGenerator.kt
 */

function toBanglaDigits(numStr) {
  const bn = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(numStr).replace(/[0-9]/g, (d) => bn[parseInt(d)]);
}

function formatTaka(amount) {
  const formatted = Number(amount || 0).toLocaleString("en-IN", {
    maximumFractionDigits: 2
  });
  return "৳ " + toBanglaDigits(formatted);
}

export function generateA4Html(memo, profile) {
  const shopName = profile.shopName || memo.shopNameSnapshot || "মেসার্স আল-আমিন ট্রেডার্স";
  const address = profile.address || memo.shopAddressSnapshot || "বাজার রোড, রাজশাহী";
  const phone = profile.phone || memo.shopPhoneSnapshot || "";
  const notice = profile.memoNotice || memo.memoNoticeSnapshot || "ধন্যবাদ, আবার আসবেন";
  const primaryColor = (profile.memoDesign && profile.memoDesign.primaryColorHex) || "#0F2B48";
  const secondaryColor = (profile.memoDesign && profile.memoDesign.secondaryColorHex) || "#00897B";

  const rows = (memo.items || []).map((item, index) => `
    <tr>
      <td style="text-align: center;">${toBanglaDigits(item.serial || index + 1)}</td>
      <td><strong>${escapeHtml(item.productName)}</strong></td>
      <td style="text-align: center;">${toBanglaDigits(item.quantity)} ${escapeHtml(item.unit || "পিস")}</td>
      <td style="text-align: right;">${toBanglaDigits(item.unitPrice)}</td>
      <td style="text-align: right;"><strong>${toBanglaDigits(item.totalPrice)}</strong></td>
    </tr>
  `).join("");

  return `
    <div class="a4-memo-wrapper" style="--primary-color: ${primaryColor}; --secondary-color: ${secondaryColor};">
      <div class="memo-header">
        <div class="memo-title-area">
          <h1 class="shop-title">${escapeHtml(shopName)}</h1>
          <p class="shop-meta">${escapeHtml(profile.shopType || "পাইকারী ও খুচরা বিক্রেতা")}</p>
          <p class="shop-contact">ঠিকানা: ${escapeHtml(address)} ${phone ? `| মোবা: ${toBanglaDigits(phone)}` : ""}</p>
        </div>
        <div class="memo-badge">ক্যাশ মেমো</div>
      </div>

      <div class="memo-meta-row">
        <div>
          <p><strong>মেমো নং:</strong> ${escapeHtml(memo.memoNumber)}</p>
          <p><strong>ক্রেতার নাম:</strong> ${escapeHtml(memo.customerName || "সাধারণ ক্রেতা")}</p>
          ${memo.customerPhone ? `<p><strong>মোবাইল:</strong> ${toBanglaDigits(memo.customerPhone)}</p>` : ""}
          ${memo.customerAddress ? `<p><strong>ঠিকানা:</strong> ${escapeHtml(memo.customerAddress)}</p>` : ""}
        </div>
        <div style="text-align: right;">
          <p><strong>তারিখ:</strong> ${toBanglaDigits(memo.memoDate)}</p>
          <p><strong>পেমেন্ট মাধ্যম:</strong> ${escapeHtml(memo.paymentType || "নগদ")}</p>
        </div>
      </div>

      <table class="memo-table">
        <thead>
          <tr>
            <th style="width: 8%;">নং</th>
            <th style="width: 48%;">বিবরণ</th>
            <th style="width: 14%; text-align: center;">পরিমাণ</th>
            <th style="width: 15%; text-align: right;">দর (টাকা)</th>
            <th style="width: 15%; text-align: right;">মোট (টাকা)</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>

      <div class="memo-calculation-section">
        <div class="memo-notice-box">
          <p class="notice-text">📌 ${escapeHtml(notice)}</p>
          <p class="terms-text">* বিক্রিত পণ্য সাধারণ নিয়মে ফেরতযোগ্য। ভুলত্রুটি সংশোধনযোগ্য।</p>
        </div>

        <div class="memo-totals-box">
          <div class="total-row"><span>মোট টাকা:</span> <span>${formatTaka(memo.subtotal)}</span></div>
          ${memo.discount > 0 ? `<div class="total-row"><span>বিশেষ ছাড়:</span> <span>- ${formatTaka(memo.discount)}</span></div>` : ""}
          ${memo.extraCharges > 0 ? `<div class="total-row"><span>লেবার/অন্যান্য:</span> <span>+ ${formatTaka(memo.extraCharges)}</span></div>` : ""}
          <div class="total-row grand-total"><span>সর্বমোট বিল:</span> <span>${formatTaka(memo.grandTotal)}</span></div>
          <div class="total-row"><span>জমা/পরিশোধ:</span> <span>${formatTaka(memo.paidAmount)}</span></div>
          <div class="total-row due-row" style="color: ${memo.dueAmount > 0 ? '#DC2626' : '#16A34A'}; font-weight: bold;">
            <span>${memo.dueAmount > 0 ? 'বাকি পাওনা:' : 'অবশিষ্ট:'}</span> 
            <span>${formatTaka(memo.dueAmount)}</span>
          </div>
        </div>
      </div>

      <div class="memo-signatures">
        <div class="sig-line">ক্রেতার স্বাক্ষর</div>
        <div class="sig-line">বিক্রেতার স্বাক্ষর</div>
      </div>
    </div>
  `;
}

export function generatePOSHtml(memo, profile) {
  const shopName = profile.shopName || memo.shopNameSnapshot || "মেসার্স আল-আমিন ট্রেডার্স";
  const address = profile.address || memo.shopAddressSnapshot || "বাজার রোড, রাজশাহী";
  const phone = profile.phone || memo.shopPhoneSnapshot || "";
  const notice = profile.memoNotice || memo.memoNoticeSnapshot || "ধন্যবাদ, আবার আসবেন";

  const rows = (memo.items || []).map((item, index) => `
    <div class="pos-item-row">
      <div class="pos-item-name">${index + 1}. ${escapeHtml(item.productName)}</div>
      <div class="pos-item-details">
        <span>${toBanglaDigits(item.quantity)} x ${toBanglaDigits(item.unitPrice)}</span>
        <span>${toBanglaDigits(item.totalPrice)}</span>
      </div>
    </div>
  `).join("");

  return `
    <div class="pos-memo-wrapper">
      <div class="pos-center">
        <h2 class="pos-shop-name">${escapeHtml(shopName)}</h2>
        <p class="pos-sub">${escapeHtml(address)}</p>
        ${phone ? `<p class="pos-sub">মোবা: ${toBanglaDigits(phone)}</p>` : ""}
        <div class="pos-divider">==============================</div>
        <div class="pos-badge">ক্যাশ মেমো</div>
      </div>

      <div class="pos-meta">
        <div>মেমো: ${escapeHtml(memo.memoNumber)}</div>
        <div>তারিখ: ${toBanglaDigits(memo.memoDate)}</div>
        <div>ক্রেতা: ${escapeHtml(memo.customerName || "সাধারণ ক্রেতা")}</div>
        ${memo.customerPhone ? `<div>মোবাইল: ${toBanglaDigits(memo.customerPhone)}</div>` : ""}
      </div>

      <div class="pos-divider">------------------------------</div>

      <div class="pos-items-list">
        ${rows}
      </div>

      <div class="pos-divider">------------------------------</div>

      <div class="pos-calc-row"><span>মোট:</span> <span>${formatTaka(memo.subtotal)}</span></div>
      ${memo.discount > 0 ? `<div class="pos-calc-row"><span>ছাড়:</span> <span>- ${formatTaka(memo.discount)}</span></div>` : ""}
      ${memo.extraCharges > 0 ? `<div class="pos-calc-row"><span>অন্যান্য:</span> <span>+ ${formatTaka(memo.extraCharges)}</span></div>` : ""}
      <div class="pos-calc-row pos-bold"><span>সর্বমোট:</span> <span>${formatTaka(memo.grandTotal)}</span></div>
      <div class="pos-calc-row"><span>পরিশোধ:</span> <span>${formatTaka(memo.paidAmount)}</span></div>
      <div class="pos-calc-row pos-bold" style="color: ${memo.dueAmount > 0 ? '#DC2626' : '#000000'};">
        <span>${memo.dueAmount > 0 ? 'বাকি:' : 'অবশিষ্ট:'}</span> 
        <span>${formatTaka(memo.dueAmount)}</span>
      </div>

      <div class="pos-divider">==============================</div>

      <div class="pos-center pos-footer">
        <p>${escapeHtml(notice)}</p>
        <p>সফটওয়্যার: Smart Memo</p>
      </div>
    </div>
  `;
}

export function triggerPrint(contentHtml, format = "A4") {
  const printContainer = document.getElementById("print-mount-area");
  if (!printContainer) return;

  printContainer.innerHTML = contentHtml;
  printContainer.className = format === "POS" ? "print-format-pos" : "print-format-a4";

  // Trigger print after slight render tick
  setTimeout(() => {
    window.print();
  }, 150);
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
