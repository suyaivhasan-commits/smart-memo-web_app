/**
 * Smart Memo Web - Firebase Configuration
 * Project ID: smart-memo-49fa4
 * Web App Client Credentials
 */

export const firebaseConfig = {
  apiKey: "AIzaSyAZSdE7ip4yCvsbZKTxGCuPtfWpyYamBCc",
  authDomain: "smart-memo-49fa4.firebaseapp.com",
  databaseURL: "https://smart-memo-49fa4-default-rtdb.firebaseio.com",
  projectId: "smart-memo-49fa4",
  storageBucket: "smart-memo-49fa4.firebasestorage.app",
  messagingSenderId: "855363479391",
  appId: "1:855363479391:web:52947121b4e6123864b8ea",
  measurementId: "G-2ET6S7TF9V"
};

export function getActiveFirebaseConfig() {
  return firebaseConfig;
}

export function saveWebConfig(appId) {
  if (appId && appId.trim()) {
    localStorage.setItem('smart_memo_web_appid', appId.trim());
  }
}
