/**
 * Smart Memo Web - Firebase Authentication Module
 */

import { initializeApp, getApps, getApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  collection,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getActiveFirebaseConfig } from "./firebase-config.js";

let app;
let auth;
let db;

export function initializeFirebase() {
  try {
    const config = getActiveFirebaseConfig();
    app = getApps().length === 0 ? initializeApp(config) : getApp();
    auth = getAuth(app);
    db = getFirestore(app);
    return { app, auth, db, error: null };
  } catch (error) {
    console.error("Firebase init failed:", error);
    return { app: null, auth: null, db: null, error: error.message };
  }
}

export async function loginWithEmail(email, password) {
  if (!auth) initializeFirebase();
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
    return { success: true, user: userCredential.user };
  } catch (error) {
    return { success: false, error: translateAuthError(error.code, error.message) };
  }
}

export async function loginWithGoogle() {
  if (!auth) initializeFirebase();
  try {
    const provider = new GoogleAuthProvider();
    const result = await signInWithPopup(auth, provider);
    return { success: true, user: result.user };
  } catch (error) {
    return { success: false, error: translateAuthError(error.code, error.message) };
  }
}

export async function logoutUser() {
  if (!auth) initializeFirebase();
  try {
    await signOut(auth);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

export async function sendResetEmail(email) {
  if (!auth) initializeFirebase();
  try {
    await sendPasswordResetEmail(auth, email.trim());
    return { success: true };
  } catch (error) {
    return { success: false, error: translateAuthError(error.code, error.message) };
  }
}

export function onAuthStatusChange(callback) {
  if (!auth) initializeFirebase();
  return onAuthStateChanged(auth, callback);
}

// Read-only observation of ShopProfile info for Dashboard Header
export function observeShopProfile(userId, onData, onError) {
  if (!db) initializeFirebase();
  const profileDoc = doc(db, "users", userId, "shop_profile", "info");
  return onSnapshot(profileDoc, (snapshot) => {
    if (snapshot.exists()) {
      onData(snapshot.data());
    } else {
      onData(null);
    }
  }, (err) => {
    console.warn("Shop profile read error:", err);
    if (onError) onError(err);
  });
}

// Read-only observation of Memos for summary counters
export function observeMemosSummary(userId, onData, onError) {
  if (!db) initializeFirebase();
  const memosCol = collection(db, "users", userId, "memos");
  return onSnapshot(memosCol, (snapshot) => {
    const list = [];
    snapshot.forEach(docSnap => {
      const data = docSnap.data();
      if (!data.isDeleted) {
        list.push({ id: docSnap.id, ...data });
      }
    });
    onData(list);
  }, (err) => {
    console.warn("Memos observation error:", err);
    if (onError) onError(err);
  });
}

function translateAuthError(code, fallbackMessage) {
  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
      return 'ইমেইল বা পাসওয়ার্ড ভুল হয়েছে। দয়া করে পুনরায় চেষ্টা করুন।';
    case 'auth/user-not-found':
      return 'এই ইমেইল দিয়ে কোনো অ্যাকাউন্ট খুঁজে পাওয়া যায়নি।';
    case 'auth/invalid-email':
      return 'সঠিক ইমেইল ঠিকানা প্রদান করুন।';
    case 'auth/user-disabled':
      return 'এই অ্যাকাউন্টটি নিষ্ক্রিয় করা হয়েছে।';
    case 'auth/too-many-requests':
      return 'অতিরিক্ত ভুলের কারণে সাময়িকভাবে বন্ধ রয়েছে। কিছুক্ষণ পর চেষ্টা করুন।';
    case 'auth/popup-closed-by-user':
      return 'লগইন উইন্ডোটি বন্ধ করে দেওয়া হয়েছে।';
    case 'auth/network-request-failed':
      return 'ইন্টারনেট সংযোগ সমস্যা হয়েছে। সংযোগ পরীক্ষা করুন।';
    default:
      return fallbackMessage || 'লগইন করতে সমস্যা হয়েছে।';
  }
}
