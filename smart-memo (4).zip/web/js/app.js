/**
 * Smart Memo Web - Main Full Application Controller
 * Handles Auth, Dashboard, New Memo, Archive, Customers, Products, Payments, Settings & Printing.
 */

import {
  initializeFirebase,
  loginWithEmail,
  loginWithGoogle,
  logoutUser,
  sendResetEmail,
  onAuthStatusChange
} from "./auth.js";

import {
  observeShopProfile,
  saveShopProfile,
  observeProducts,
  saveProduct,
  deleteProduct,
  observeCustomers,
  saveCustomer,
  observeMemos,
  saveMemo,
  deleteMemo,
  deleteMemos,
  observePayments,
  recordDuePayment
} from "./db-service.js";

import {
  generateA4Html,
  generatePOSHtml,
  triggerPrint
} from "./print-service.js";

import { getActiveFirebaseConfig, saveWebConfig } from "./firebase-config.js";

// --- Global State ---
let db = null;
let currentUser = null;
let currentProfile = {};
let products = [];
let customers = [];
let memos = [];
let payments = [];

let activeTab = "dashboard";
let bulkSelectionMode = false;
let selectedMemoIds = new Set();
let pendingDeleteAction = null;
let currentViewingMemo = null;

let unsubProfile = null;
let unsubProducts = null;
let unsubCustomers = null;
let unsubMemos = null;
let unsubPayments = null;

// --- DOM References ---
const authSection = document.getElementById("auth-section");
const appWorkspace = document.getElementById("app-workspace");
const appNav = document.getElementById("app-nav");
const btnLogout = document.getElementById("btn-logout");
const userDisplayEmail = document.getElementById("user-display-email");
const globalAlert = document.getElementById("global-alert");

// Utility: Bengali Numerals
function toBanglaDigits(numStr) {
  const bn = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(numStr ?? "").replace(/[0-9]/g, (d) => bn[parseInt(d)]);
}

function formatTaka(amount) {
  const formatted = Number(amount || 0).toLocaleString("en-IN", {
    maximumFractionDigits: 2
  });
  return "৳ " + toBanglaDigits(formatted);
}

function getTodayIsoDate() {
  const d = new Date();
  const day = String(d.getDate()).padStart(2, "0");
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const year = d.getFullYear();
  return `${year}-${month}-${day}`;
}

function getTodayDisplayDate() {
  const d = new Date();
  const day = String(d.getDate()).padStart(2, "0");
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const year = d.getFullYear();
  return `${day}-${month}-${year}`;
}

function showToast(message, isError = false) {
  if (!globalAlert) return;
  globalAlert.textContent = message;
  globalAlert.className = isError ? "alert-box alert-danger" : "alert-box alert-success";
  globalAlert.style.display = "block";
  setTimeout(() => {
    globalAlert.style.display = "none";
  }, 4000);
}

// Modal Helpers
window.openModal = function (id) {
  const el = document.getElementById(id);
  if (el) el.classList.add("active");
};

window.closeModal = function (id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove("active");
};

// Tab Switching
window.switchTab = function (tabName) {
  activeTab = tabName;
  document.querySelectorAll(".nav-tab").forEach((t) => {
    t.classList.toggle("active", t.getAttribute("data-tab") === tabName);
  });
  document.querySelectorAll(".tab-panel").forEach((p) => {
    p.classList.toggle("active", p.id === `panel-${tabName}`);
  });
  if (tabName === "new-memo") {
    prepareNewMemoForm();
  }
};

// --- Initialization ---
document.addEventListener("DOMContentLoaded", () => {
  const initRes = initializeFirebase();
  if (initRes.error) {
    showToast("Firebase সংযোগ ত্রুটি: " + initRes.error, true);
  }
  db = initRes.db;

  // Tab click bindings
  document.querySelectorAll(".nav-tab").forEach((btn) => {
    btn.addEventListener("click", () => {
      window.switchTab(btn.getAttribute("data-tab"));
    });
  });

  // Auth Status
  onAuthStatusChange((user) => {
    currentUser = user;
    if (user) {
      handleUserLoggedIn(user);
    } else {
      handleUserLoggedOut();
    }
  });

  // Auth Forms
  setupAuthEvents();

  // New Memo Events
  setupNewMemoEvents();

  // Archive & Bulk Delete Events
  setupArchiveEvents();

  // Customer & Product Modal Events
  setupCrudEvents();

  // Settings Events
  setupSettingsEvents();
});

// --- Auth State Handlers ---
function handleUserLoggedIn(user) {
  authSection.style.display = "none";
  appWorkspace.style.display = "block";
  appNav.style.display = "flex";
  btnLogout.style.display = "inline-flex";
  userDisplayEmail.textContent = user.email || "দোকানদার";

  // Clean old listeners
  detachListeners();

  // Start Firestore Live Streams
  unsubProfile = observeShopProfile(db, user.uid, (p) => {
    currentProfile = p || {};
    updateShopBrandingUI();
  });

  unsubProducts = observeProducts(db, user.uid, (prods) => {
    products = prods;
    updateProductsUI();
    updateProductsDatalist();
    updateDashboardStats();
  });

  unsubCustomers = observeCustomers(db, user.uid, (custs) => {
    customers = custs;
    updateCustomersUI();
    updateCustomersDatalist();
  });

  unsubMemos = observeMemos(db, user.uid, (memoList) => {
    memos = memoList;
    updateDashboardStats();
    updateDashboardRecentMemos();
    updateArchiveTable();
    updateNextMemoNumber();
  });

  unsubPayments = observePayments(db, user.uid, (pays) => {
    payments = pays;
    updatePaymentsUI();
  });
}

function handleUserLoggedOut() {
  detachListeners();
  authSection.style.display = "flex";
  appWorkspace.style.display = "none";
  appNav.style.display = "none";
  btnLogout.style.display = "none";
  userDisplayEmail.textContent = "";
  document.getElementById("shop-name-header").textContent = "Smart Memo";
}

function detachListeners() {
  if (unsubProfile) unsubProfile();
  if (unsubProducts) unsubProducts();
  if (unsubCustomers) unsubCustomers();
  if (unsubMemos) unsubMemos();
  if (unsubPayments) unsubPayments();
}

// --- Auth Events ---
function setupAuthEvents() {
  const loginForm = document.getElementById("login-form");
  const emailInput = document.getElementById("email-input");
  const passInput = document.getElementById("password-input");
  const btnGoogle = document.getElementById("btn-google-login");
  const btnForgot = document.getElementById("btn-forgot-password");

  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const res = await loginWithEmail(emailInput.value, passInput.value);
      if (!res.success) {
        showToast(res.error, true);
      }
    });
  }

  if (btnGoogle) {
    btnGoogle.addEventListener("click", async () => {
      const res = await loginWithGoogle();
      if (!res.success) {
        showToast(res.error, true);
      }
    });
  }

  if (btnLogout) {
    btnLogout.addEventListener("click", async () => {
      await logoutUser();
    });
  }

  if (btnForgot) {
    btnForgot.addEventListener("click", async () => {
      const email = emailInput.value.trim();
      if (!email) {
        showToast("পাসওয়ার্ড রিসেট করতে ইমেইল লিখুন", true);
        return;
      }
      const res = await sendResetEmail(email);
      if (res.success) {
        showToast("আপনার ইমেইলে রিসেট লিংক পাঠানো হয়েছে");
      } else {
        showToast(res.error, true);
      }
    });
  }
}

// --- Shop Profile & Branding ---
function updateShopBrandingUI() {
  const name = currentProfile.shopName || "মেসার্স আল-আমিন ট্রেডার্স";
  const address = currentProfile.address || "১২০, বাজার রোড, রাজশাহী";
  document.getElementById("shop-name-header").textContent = name;
  document.getElementById("shop-name-banner").textContent = name;
  document.getElementById("shop-address-banner").textContent = address;

  // Settings form initial values
  document.getElementById("setting-shop-name").value = currentProfile.shopName || "";
  document.getElementById("setting-owner-name").value = currentProfile.ownerName || "";
  document.getElementById("setting-address").value = currentProfile.address || "";
  document.getElementById("setting-phone").value = currentProfile.phone || "";
  document.getElementById("setting-alt-phone").value = currentProfile.altPhone || "";
  document.getElementById("setting-email").value = currentProfile.email || "";
  document.getElementById("setting-shop-type").value = currentProfile.shopType || "";
  document.getElementById("setting-memo-notice").value = currentProfile.memoNotice || "ধন্যবাদ, আবার আসবেন";
  document.getElementById("setting-paper-size").value = currentProfile.paperSize || "A4";

  const cfg = getActiveFirebaseConfig();
  document.getElementById("setting-web-appid").value = cfg.appId || "";
}

// --- Dashboard Statistics ---
function updateDashboardStats() {
  const todayDisplay = getTodayDisplayDate();
  const todayMemos = memos.filter((m) => m.memoDate === todayDisplay);
  const todaySales = todayMemos.reduce((sum, m) => sum + (Number(m.grandTotal) || 0), 0);
  const totalDues = memos.reduce((sum, m) => sum + (Number(m.dueAmount) || 0), 0);
  const stockVal = products.reduce((sum, p) => sum + ((Number(p.stock) || 0) * (Number(p.purchasePrice) || Number(p.salePrice) || 0)), 0);

  document.getElementById("stat-today-sales").textContent = formatTaka(todaySales);
  document.getElementById("stat-today-memos").textContent = `${toBanglaDigits(todayMemos.length)} টি`;
  document.getElementById("stat-total-dues").textContent = formatTaka(totalDues);
  document.getElementById("stat-total-stock-val").textContent = formatTaka(stockVal);
}

function updateDashboardRecentMemos() {
  const tbody = document.getElementById("dashboard-recent-memos-body");
  if (!tbody) return;
  const recent = memos.slice(0, 5);
  if (recent.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: #64748B;">কোনো মেমো পাওয়া যায়নি</td></tr>`;
    return;
  }
  tbody.innerHTML = recent.map((m) => `
    <tr>
      <td><strong>${m.memoNumber}</strong></td>
      <td>${toBanglaDigits(m.memoDate)}</td>
      <td>${m.customerName || "সাধারণ ক্রেতা"}</td>
      <td><strong>${formatTaka(m.grandTotal)}</strong></td>
      <td>${formatTaka(m.paidAmount)}</td>
      <td style="color: ${m.dueAmount > 0 ? '#DC2626' : '#16A34A'}; font-weight: bold;">${formatTaka(m.dueAmount)}</td>
      <td><span class="${m.dueAmount > 0 ? 'badge-due' : 'badge-paid'}">${m.dueAmount > 0 ? 'বাকি' : 'পরিশোধিত'}</span></td>
      <td style="text-align: right;">
        <button class="btn-secondary" style="padding: 4px 8px; font-size: 0.8rem;" onclick="window.viewMemoDetails('${m.id}')">দেখুন</button>
      </td>
    </tr>
  `).join("");
}

// --- TAB 2: NEW MEMO LOGIC ---
let memoItems = [];

function updateNextMemoNumber() {
  const badge = document.getElementById("new-memo-number-badge");
  if (!badge) return;
  const nextNum = `#${String(memos.length + 1).padStart(4, "0")}`;
  badge.textContent = `মেমো নং: ${nextNum}`;
}

function prepareNewMemoForm() {
  document.getElementById("memo-date").value = getTodayIsoDate();
  memoItems = [
    { serial: 1, productName: "", quantity: 1, unit: "পিস", unitPrice: 0, totalPrice: 0 }
  ];
  renderMemoItemRows();
  recalculateMemoTotals();
}

function renderMemoItemRows() {
  const container = document.getElementById("memo-items-container");
  if (!container) return;
  container.innerHTML = memoItems.map((item, index) => `
    <div class="item-row" data-index="${index}">
      <div>
        <input type="text" class="input-field item-product-input" placeholder="পণ্যের নাম লিখুন বা সিলেক্ট করুন" list="products-datalist" value="${escapeHtml(item.productName)}" data-index="${index}">
      </div>
      <div>
        <input type="number" class="input-field item-qty-input" placeholder="পরিমাণ" value="${item.quantity}" min="0.1" step="any" data-index="${index}">
      </div>
      <div>
        <select class="input-field item-unit-input" data-index="${index}">
          <option value="পিস" ${item.unit === 'পিস' ? 'selected' : ''}>পিস</option>
          <option value="কেজি" ${item.unit === 'কেজি' ? 'selected' : ''}>কেজি</option>
          <option value="লিটার" ${item.unit === 'লিটার' ? 'selected' : ''}>লিটার</option>
          <option value="ব্যাগ" ${item.unit === 'ব্যাগ' ? 'selected' : ''}>ব্যাগ</option>
          <option value="ডজন" ${item.unit === 'ডজন' ? 'selected' : ''}>ডজন</option>
          <option value="গজ" ${item.unit === 'গজ' ? 'selected' : ''}>গজ</option>
          <option value="ফুট" ${item.unit === 'ফুট' ? 'selected' : ''}>ফুট</option>
          <option value="মিটার" ${item.unit === 'মিটার' ? 'selected' : ''}>মিটার</option>
        </select>
      </div>
      <div>
        <input type="number" class="input-field item-rate-input" placeholder="দর" value="${item.unitPrice}" min="0" step="any" data-index="${index}">
      </div>
      <div>
        <button type="button" class="btn-danger" style="padding: 8px 12px;" onclick="window.removeMemoRow(${index})" ${memoItems.length <= 1 ? 'disabled' : ''}>✕</button>
      </div>
    </div>
  `).join("");

  // Attach live calculation events
  container.querySelectorAll(".item-product-input").forEach((inp) => {
    inp.addEventListener("input", (e) => {
      const idx = parseInt(e.target.dataset.index);
      const name = e.target.value.trim();
      memoItems[idx].productName = name;
      // Auto-fill price & unit if matched in products
      const matched = products.find((p) => p.name.toLowerCase() === name.toLowerCase());
      if (matched) {
        memoItems[idx].unitPrice = matched.salePrice || 0;
        memoItems[idx].unit = matched.unit || "পিস";
        renderMemoItemRows();
      }
      recalculateMemoTotals();
    });
  });

  container.querySelectorAll(".item-qty-input").forEach((inp) => {
    inp.addEventListener("input", (e) => {
      const idx = parseInt(e.target.dataset.index);
      memoItems[idx].quantity = parseFloat(e.target.value) || 0;
      recalculateMemoTotals();
    });
  });

  container.querySelectorAll(".item-rate-input").forEach((inp) => {
    inp.addEventListener("input", (e) => {
      const idx = parseInt(e.target.dataset.index);
      memoItems[idx].unitPrice = parseFloat(e.target.value) || 0;
      recalculateMemoTotals();
    });
  });

  container.querySelectorAll(".item-unit-input").forEach((sel) => {
    sel.addEventListener("change", (e) => {
      const idx = parseInt(e.target.dataset.index);
      memoItems[idx].unit = e.target.value;
    });
  });
}

window.removeMemoRow = function (index) {
  if (memoItems.length <= 1) return;
  memoItems.splice(index, 1);
  memoItems.forEach((item, i) => item.serial = i + 1);
  renderMemoItemRows();
  recalculateMemoTotals();
};

function recalculateMemoTotals() {
  let subtotal = 0;
  memoItems.forEach((item) => {
    item.totalPrice = Math.round((item.quantity * item.unitPrice) * 100) / 100;
    subtotal += item.totalPrice;
  });

  const discount = parseFloat(document.getElementById("calc-discount").value) || 0;
  const extra = parseFloat(document.getElementById("calc-extra").value) || 0;
  const grandTotal = Math.max(0, subtotal - discount + extra);
  const paid = parseFloat(document.getElementById("calc-paid").value) || 0;
  const due = Math.max(0, grandTotal - paid);

  document.getElementById("calc-subtotal").textContent = formatTaka(subtotal);
  document.getElementById("calc-grand-total").textContent = formatTaka(grandTotal);
  document.getElementById("calc-due-amount").textContent = formatTaka(due);

  return { subtotal, discount, extra, grandTotal, paid, due };
}

function setupNewMemoEvents() {
  const btnAdd = document.getElementById("btn-add-item-row");
  if (btnAdd) {
    btnAdd.addEventListener("click", () => {
      memoItems.push({
        serial: memoItems.length + 1,
        productName: "",
        quantity: 1,
        unit: "পিস",
        unitPrice: 0,
        totalPrice: 0
      });
      renderMemoItemRows();
    });
  }

  document.getElementById("calc-discount").addEventListener("input", recalculateMemoTotals);
  document.getElementById("calc-extra").addEventListener("input", recalculateMemoTotals);
  document.getElementById("calc-paid").addEventListener("input", recalculateMemoTotals);

  document.getElementById("btn-reset-memo-form").addEventListener("click", prepareNewMemoForm);

  // Form Submission
  const memoForm = document.getElementById("new-memo-form");
  if (memoForm) {
    memoForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      await submitNewMemo(false, null);
    });
  }

  document.getElementById("btn-save-print-a4").addEventListener("click", async () => {
    await submitNewMemo(true, "A4");
  });

  document.getElementById("btn-save-print-pos").addEventListener("click", async () => {
    await submitNewMemo(true, "POS");
  });
}

async function submitNewMemo(printAfter = false, printFormat = "A4") {
  if (!currentUser) return;
  const validItems = memoItems.filter((i) => i.productName.trim() !== "");
  if (validItems.length === 0) {
    showToast("অন্তত একটি পণ্যের নাম লিখুন", true);
    return;
  }

  const { subtotal, discount, extra, grandTotal, paid, due } = recalculateMemoTotals();
  const dateIso = document.getElementById("memo-date").value || getTodayIsoDate();
  const [y, m, d] = dateIso.split("-");
  const dateFormatted = `${d}-${m}-${y}`;

  const nextNum = `#${String(memos.length + 1).padStart(4, "0")}`;

  const memoData = {
    memoNumber: nextNum,
    memoDate: dateFormatted,
    customerName: document.getElementById("memo-customer-name").value.trim(),
    customerPhone: document.getElementById("memo-customer-phone").value.trim(),
    customerAddress: document.getElementById("memo-customer-address").value.trim(),
    paymentType: document.getElementById("memo-payment-type").value,
    items: validItems,
    subtotal: subtotal,
    discount: discount,
    extraCharges: extra,
    grandTotal: grandTotal,
    paidAmount: paid,
    dueAmount: due,
    shopNameSnapshot: currentProfile.shopName || "মেসার্স আল-আমিন ট্রেডার্স",
    shopAddressSnapshot: currentProfile.address || "বাজার রোড, রাজশাহী",
    shopPhoneSnapshot: currentProfile.phone || "",
    memoNoticeSnapshot: currentProfile.memoNotice || "ধন্যবাদ, আবার আসবেন",
    designConfig: currentProfile.memoDesign || {}
  };

  try {
    const memoId = await saveMemo(db, currentUser.uid, memoData, true);
    memoData.id = memoId;
    showToast(`মেমো নং ${nextNum} সফলভাবে সংরক্ষিত হয়েছে!`);
    prepareNewMemoForm();

    if (printAfter) {
      if (printFormat === "POS") {
        triggerPrint(generatePOSHtml(memoData, currentProfile), "POS");
      } else {
        triggerPrint(generateA4Html(memoData, currentProfile), "A4");
      }
    }
    window.switchTab("archive");
  } catch (err) {
    showToast("মেমো সংরক্ষণে ত্রুটি: " + err.message, true);
  }
}

// --- TAB 3: ARCHIVE & SEARCH ---
function setupArchiveEvents() {
  document.getElementById("archive-search-input").addEventListener("input", updateArchiveTable);
  document.getElementById("archive-time-filter").addEventListener("change", updateArchiveTable);
  document.getElementById("archive-status-filter").addEventListener("change", updateArchiveTable);

  const btnToggleBulk = document.getElementById("btn-toggle-bulk-mode");
  const bulkBar = document.getElementById("bulk-actions-bar");
  const thCheckbox = document.getElementById("th-bulk-checkbox");

  btnToggleBulk.addEventListener("click", () => {
    bulkSelectionMode = !bulkSelectionMode;
    selectedMemoIds.clear();
    bulkBar.style.display = bulkSelectionMode ? "flex" : "none";
    thCheckbox.style.display = bulkSelectionMode ? "table-cell" : "none";
    btnToggleBulk.textContent = bulkSelectionMode ? "নির্বাচন মোড বন্ধ" : "একাধিক নির্বাচন / মুছুন";
    updateArchiveTable();
  });

  document.getElementById("btn-bulk-select-all").addEventListener("click", () => {
    const visible = getFilteredMemos();
    if (selectedMemoIds.size === visible.length) {
      selectedMemoIds.clear();
    } else {
      visible.forEach((m) => selectedMemoIds.add(m.id));
    }
    updateBulkCountBadge();
    updateArchiveTable();
  });

  document.getElementById("btn-bulk-select-7days").addEventListener("click", () => {
    const visible = getFilteredMemos();
    visible.forEach((m) => {
      if (isOlderThanDays(m.memoDate, 7)) selectedMemoIds.add(m.id);
    });
    updateBulkCountBadge();
    updateArchiveTable();
  });

  document.getElementById("btn-bulk-select-30days").addEventListener("click", () => {
    const visible = getFilteredMemos();
    visible.forEach((m) => {
      if (isOlderThanDays(m.memoDate, 30)) selectedMemoIds.add(m.id);
    });
    updateBulkCountBadge();
    updateArchiveTable();
  });

  document.getElementById("btn-bulk-select-paid-only").addEventListener("click", () => {
    const visible = getFilteredMemos();
    visible.forEach((m) => {
      if ((Number(m.dueAmount) || 0) <= 0) selectedMemoIds.add(m.id);
    });
    updateBulkCountBadge();
    updateArchiveTable();
  });

  document.getElementById("btn-execute-bulk-delete").addEventListener("click", () => {
    if (selectedMemoIds.size === 0) {
      showToast("মুছে ফেলার জন্য কোনো মেমো নির্বাচন করা হয়নি", true);
      return;
    }
    promptDeleteConfirmation([...selectedMemoIds], true);
  });
}

function isOlderThanDays(dateStr, days) {
  try {
    const [d, m, y] = dateStr.split("-");
    const memoDate = new Date(`${y}-${m}-${d}`).getTime();
    const now = Date.now();
    const diffDays = (now - memoDate) / (1000 * 60 * 60 * 24);
    return diffDays >= days;
  } catch (e) {
    return false;
  }
}

function getFilteredMemos() {
  const query = (document.getElementById("archive-search-input").value || "").trim().toLowerCase();
  const timeFilter = document.getElementById("archive-time-filter").value;
  const statusFilter = document.getElementById("archive-status-filter").value;
  const today = getTodayDisplayDate();

  return memos.filter((m) => {
    const matchesSearch = !query ||
      (m.memoNumber && m.memoNumber.toLowerCase().includes(query)) ||
      (m.customerName && m.customerName.toLowerCase().includes(query)) ||
      (m.customerPhone && m.customerPhone.includes(query));

    let matchesTime = true;
    if (timeFilter === "TODAY") matchesTime = m.memoDate === today;

    let matchesStatus = true;
    if (statusFilter === "PAID") matchesStatus = (Number(m.dueAmount) || 0) <= 0;
    if (statusFilter === "DUE") matchesStatus = (Number(m.dueAmount) || 0) > 0;

    return matchesSearch && matchesTime && matchesStatus;
  });
}

function updateArchiveTable() {
  const tbody = document.getElementById("archive-memos-table-body");
  if (!tbody) return;
  const list = getFilteredMemos();

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" style="text-align: center; color: #64748B;">কোনো মেমো পাওয়া যায়নি</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map((m) => {
    const isChecked = selectedMemoIds.has(m.id);
    return `
      <tr>
        ${bulkSelectionMode ? `<td><input type="checkbox" class="memo-chk" data-id="${m.id}" ${isChecked ? 'checked' : ''}></td>` : ''}
        <td><strong>${m.memoNumber}</strong></td>
        <td>${toBanglaDigits(m.memoDate)}</td>
        <td>${escapeHtml(m.customerName || "সাধারণ ক্রেতা")}</td>
        <td>${toBanglaDigits(m.customerPhone || "")}</td>
        <td><strong>${formatTaka(m.grandTotal)}</strong></td>
        <td>${formatTaka(m.paidAmount)}</td>
        <td style="color: ${m.dueAmount > 0 ? '#DC2626' : '#16A34A'}; font-weight: bold;">${formatTaka(m.dueAmount)}</td>
        <td><span class="${m.dueAmount > 0 ? 'badge-due' : 'badge-paid'}">${m.dueAmount > 0 ? 'বাকি' : 'পরিশোধিত'}</span></td>
        <td style="text-align: right; white-space: nowrap;">
          <button class="btn-secondary" style="padding: 4px 8px; font-size: 0.8rem;" onclick="window.viewMemoDetails('${m.id}')">দেখুন</button>
          <button class="btn-secondary" style="padding: 4px 8px; font-size: 0.8rem;" onclick="window.printMemoById('${m.id}', 'A4')">A4</button>
          <button class="btn-secondary" style="padding: 4px 8px; font-size: 0.8rem;" onclick="window.printMemoById('${m.id}', 'POS')">POS</button>
          <button class="btn-danger" style="padding: 4px 8px; font-size: 0.8rem;" onclick="window.confirmDeleteSingleMemo('${m.id}')">মুছুন</button>
        </td>
      </tr>
    `;
  }).join("");

  // Attach checkbox events
  if (bulkSelectionMode) {
    tbody.querySelectorAll(".memo-chk").forEach((chk) => {
      chk.addEventListener("change", (e) => {
        const id = e.target.dataset.id;
        if (e.target.checked) selectedMemoIds.add(id);
        else selectedMemoIds.delete(id);
        updateBulkCountBadge();
      });
    });
  }
}

function updateBulkCountBadge() {
  document.getElementById("bulk-selected-count").textContent = `${toBanglaDigits(selectedMemoIds.size)} টি নির্বাচিত`;
}

// Single / Bulk Delete Dialog with DUE PROTECTION WARNING
window.confirmDeleteSingleMemo = function (memoId) {
  promptDeleteConfirmation([memoId], false);
};

function promptDeleteConfirmation(memoIds, isBulk) {
  const targetMemos = memos.filter((m) => memoIds.includes(m.id));
  const dueMemos = targetMemos.filter((m) => (Number(m.dueAmount) || 0) > 0);
  const totalDue = dueMemos.reduce((sum, m) => sum + Number(m.dueAmount), 0);

  let warningHtml = "";
  if (dueMemos.length > 0) {
    warningHtml = `
      <div style="background: #FEE2E2; border: 1.5px solid #FCA5A5; border-radius: 8px; padding: 12px; margin-top: 12px;">
        <strong style="color: #DC2626;">⚠️ সতর্কতা: বকেয়া মেমো অন্তর্ভুক্ত রয়েছে!</strong>
        <p style="font-size: 0.85rem; color: #991B1B; margin-top: 4px;">
          নির্বাচিত ${toBanglaDigits(targetMemos.length)}টি মেমোর মধ্যে ${toBanglaDigits(dueMemos.length)}টি মেমোতে মোট ${formatTaka(totalDue)} বকেয়া পাওনা রয়েছে! 
          মেমো ডিলিট করলে ক্রেতার বকেয়া হিসাব মেলানো কঠিন হতে পারে।
        </p>
      </div>
    `;
  }

  const confirmBody = document.getElementById("delete-confirm-body");
  confirmBody.innerHTML = `
    <p>আপনি কি নিশ্চিত যে ${toBanglaDigits(targetMemos.length)} টি মেমো স্থায়ীভাবে ডাটাবেস থেকে মুছে ফেলতে চান?</p>
    ${warningHtml}
  `;

  pendingDeleteAction = async () => {
    try {
      if (isBulk) {
        await deleteMemos(db, currentUser.uid, memoIds);
        selectedMemoIds.clear();
        updateBulkCountBadge();
      } else {
        await deleteMemo(db, currentUser.uid, memoIds[0]);
      }
      showToast("মেমো সফলভাবে মুছে ফেলা হয়েছে");
      window.closeModal("modal-delete-confirm");
    } catch (err) {
      showToast("ডিলিট ব্যর্থ: " + err.message, true);
    }
  };

  document.getElementById("btn-confirm-delete-action").onclick = pendingDeleteAction;
  window.openModal("modal-delete-confirm");
}

// View & Print Memo Modal Handlers
window.viewMemoDetails = function (memoId) {
  const memo = memos.find((m) => m.id === memoId);
  if (!memo) return;
  currentViewingMemo = memo;

  const body = document.getElementById("view-memo-body");
  body.innerHTML = generateA4Html(memo, currentProfile);

  document.getElementById("btn-print-viewed-a4").onclick = () => {
    triggerPrint(generateA4Html(memo, currentProfile), "A4");
  };
  document.getElementById("btn-print-viewed-pos").onclick = () => {
    triggerPrint(generatePOSHtml(memo, currentProfile), "POS");
  };

  window.openModal("modal-view-memo");
};

window.printMemoById = function (memoId, format) {
  const memo = memos.find((m) => m.id === memoId);
  if (!memo) return;
  if (format === "POS") {
    triggerPrint(generatePOSHtml(memo, currentProfile), "POS");
  } else {
    triggerPrint(generateA4Html(memo, currentProfile), "A4");
  }
};

// --- TAB 4 & 5: CRUD (CUSTOMERS & PRODUCTS) ---
function setupCrudEvents() {
  // Add Product Modal
  document.getElementById("btn-open-add-product-modal").addEventListener("click", () => {
    document.getElementById("form-product").reset();
    document.getElementById("product-edit-id").value = "";
    document.getElementById("product-modal-title").textContent = "নতুন পণ্য যোগ করুন";
    window.openModal("modal-add-product");
  });

  document.getElementById("form-product").addEventListener("submit", async (e) => {
    e.preventDefault();
    const prod = {
      id: document.getElementById("product-edit-id").value,
      name: document.getElementById("prod-input-name").value,
      category: document.getElementById("prod-input-category").value,
      unit: document.getElementById("prod-input-unit").value,
      purchasePrice: parseFloat(document.getElementById("prod-input-purchase-price").value) || 0,
      salePrice: parseFloat(document.getElementById("prod-input-sale-price").value) || 0,
      stock: parseFloat(document.getElementById("prod-input-stock").value) || 0
    };
    try {
      await saveProduct(db, currentUser.uid, prod);
      showToast("পণ্য সফলভাবে সংরক্ষিত হয়েছে");
      window.closeModal("modal-add-product");
    } catch (err) {
      showToast("পণ্য সংরক্ষণে ত্রুটি: " + err.message, true);
    }
  });

  // Add Customer Modal
  document.getElementById("btn-open-add-customer-modal").addEventListener("click", () => {
    document.getElementById("form-customer").reset();
    window.openModal("modal-add-customer");
  });

  document.getElementById("form-customer").addEventListener("submit", async (e) => {
    e.preventDefault();
    const cust = {
      name: document.getElementById("cust-input-name").value,
      phone: document.getElementById("cust-input-phone").value,
      address: document.getElementById("cust-input-address").value
    };
    try {
      await saveCustomer(db, currentUser.uid, cust);
      showToast("গ্রাহক সফলভাবে সংরক্ষিত হয়েছে");
      window.closeModal("modal-add-customer");
    } catch (err) {
      showToast("গ্রাহক সংরক্ষণে ত্রুটি: " + err.message, true);
    }
  });

  // Collect Payment Modal
  const payForm = document.getElementById("form-collect-payment");
  payForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const custId = document.getElementById("pay-customer-id").value;
    const custName = document.getElementById("pay-customer-name").value;
    const amount = parseFloat(document.getElementById("pay-amount").value) || 0;
    const method = document.getElementById("pay-method").value;
    const date = document.getElementById("pay-date").value;
    const note = document.getElementById("pay-note").value;

    if (amount <= 0) {
      showToast("সঠিক টাকার পরিমাণ লিখুন", true);
      return;
    }

    try {
      await recordDuePayment(db, currentUser.uid, {
        customerId: custId,
        customerName: custName,
        amount: amount,
        method: method,
        date: date,
        note: note
      });
      showToast("বাকি পরিশোধ সফলভাবে জমা হয়েছে!");
      window.closeModal("modal-collect-payment");
    } catch (err) {
      showToast("পেমেন্ট সংরক্ষণে ত্রুটি: " + err.message, true);
    }
  });

  document.getElementById("customer-search-input").addEventListener("input", updateCustomersUI);
  document.getElementById("product-search-input").addEventListener("input", updateProductsUI);
}

function updateProductsUI() {
  const tbody = document.getElementById("products-table-body");
  if (!tbody) return;
  const q = (document.getElementById("product-search-input").value || "").trim().toLowerCase();
  const filtered = products.filter((p) => !q || p.name.toLowerCase().includes(q));

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: #64748B;">কোনো পণ্য পাওয়া যায়নি</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map((p) => {
    const stockVal = (Number(p.stock) || 0) * (Number(p.salePrice) || 0);
    return `
      <tr>
        <td><strong>${escapeHtml(p.name)}</strong></td>
        <td>${escapeHtml(p.category || "সাধারণ")}</td>
        <td>${escapeHtml(p.unit || "পিস")}</td>
        <td>${formatTaka(p.purchasePrice)}</td>
        <td><strong>${formatTaka(p.salePrice)}</strong></td>
        <td style="color: ${p.stock <= 5 ? '#DC2626' : '#16A34A'}; font-weight: bold;">${toBanglaDigits(p.stock)}</td>
        <td>${formatTaka(stockVal)}</td>
        <td style="text-align: right;">
          <button class="btn-secondary" style="padding: 4px 8px; font-size: 0.8rem;" onclick="window.editProduct('${p.id}')">সম্পাদনা</button>
          <button class="btn-danger" style="padding: 4px 8px; font-size: 0.8rem;" onclick="window.deleteProductById('${p.id}')">মুছুন</button>
        </td>
      </tr>
    `;
  }).join("");
}

window.editProduct = function (id) {
  const p = products.find((prod) => prod.id === id);
  if (!p) return;
  document.getElementById("product-edit-id").value = p.id;
  document.getElementById("prod-input-name").value = p.name || "";
  document.getElementById("prod-input-category").value = p.category || "সাধারণ";
  document.getElementById("prod-input-unit").value = p.unit || "পিস";
  document.getElementById("prod-input-purchase-price").value = p.purchasePrice || 0;
  document.getElementById("prod-input-sale-price").value = p.salePrice || 0;
  document.getElementById("prod-input-stock").value = p.stock || 0;
  document.getElementById("product-modal-title").textContent = "পণ্য সম্পাদনা করুন";
  window.openModal("modal-add-product");
};

window.deleteProductById = async function (id) {
  if (confirm("আপনি কি নিশ্চিত যে পণ্যটি মুছে ফেলতে চান?")) {
    try {
      await deleteProduct(db, currentUser.uid, id);
      showToast("পণ্য মুছে ফেলা হয়েছে");
    } catch (err) {
      showToast("মুছতে ব্যর্থ: " + err.message, true);
    }
  }
};

function updateCustomersUI() {
  const tbody = document.getElementById("customers-table-body");
  if (!tbody) return;
  const q = (document.getElementById("customer-search-input").value || "").trim().toLowerCase();
  const filtered = customers.filter((c) => !q || c.name.toLowerCase().includes(q) || (c.phone && c.phone.includes(q)));

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: #64748B;">কোনো গ্রাহক পাওয়া যায়নি</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map((c) => `
    <tr>
      <td><strong>${escapeHtml(c.name)}</strong></td>
      <td>${toBanglaDigits(c.phone || "")}</td>
      <td>${escapeHtml(c.address || "")}</td>
      <td>${formatTaka(c.totalPurchases)}</td>
      <td>${formatTaka(c.totalPaid)}</td>
      <td style="color: ${c.totalDue > 0 ? '#DC2626' : '#16A34A'}; font-weight: bold;">${formatTaka(c.totalDue)}</td>
      <td style="text-align: right;">
        <button class="btn-primary" style="padding: 4px 10px; font-size: 0.8rem;" onclick="window.openCollectPaymentModal('${c.id}')">💵 বাকি গ্রহণ</button>
      </td>
    </tr>
  `).join("");
}

window.openCollectPaymentModal = function (customerId) {
  const cust = customers.find((c) => c.id === customerId);
  if (!cust) return;
  document.getElementById("pay-customer-id").value = cust.id;
  document.getElementById("pay-customer-name").value = cust.name;
  document.getElementById("pay-current-due").textContent = formatTaka(cust.totalDue);
  document.getElementById("pay-amount").value = cust.totalDue > 0 ? cust.totalDue : "";
  document.getElementById("pay-date").value = getTodayIsoDate();
  document.getElementById("pay-note").value = "";
  window.openModal("modal-collect-payment");
};

function updatePaymentsUI() {
  const tbody = document.getElementById("payments-table-body");
  if (!tbody) return;
  if (payments.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: #64748B;">কোনো পেমেন্ট রেকর্ড নেই</td></tr>`;
    return;
  }
  tbody.innerHTML = payments.map((p) => `
    <tr>
      <td>${toBanglaDigits(p.date || "")}</td>
      <td><strong>${escapeHtml(p.customerName || "সাধারণ ক্রেতা")}</strong></td>
      <td>${escapeHtml(p.memoNumber || "-")}</td>
      <td style="font-weight: bold; color: #16A34A;">${formatTaka(p.amount)}</td>
      <td>${escapeHtml(p.paymentMethod || "নগদ")}</td>
      <td>${escapeHtml(p.note || "-")}</td>
    </tr>
  `).join("");
}

function updateCustomersDatalist() {
  const dl = document.getElementById("customers-datalist");
  if (!dl) return;
  dl.innerHTML = customers.map((c) => `<option value="${escapeHtml(c.name)}">${c.phone ? `(${c.phone})` : ""}</option>`).join("");
}

function updateProductsDatalist() {
  const dl = document.getElementById("products-datalist");
  if (!dl) return;
  dl.innerHTML = products.map((p) => `<option value="${escapeHtml(p.name)}">স্টক: ${p.stock} ${p.unit} | দর: ৳${p.salePrice}</option>`).join("");
}

// --- TAB 7: SETTINGS ---
function setupSettingsEvents() {
  const form = document.getElementById("shop-settings-form");
  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const updated = {
        shopName: document.getElementById("setting-shop-name").value.trim(),
        ownerName: document.getElementById("setting-owner-name").value.trim(),
        address: document.getElementById("setting-address").value.trim(),
        phone: document.getElementById("setting-phone").value.trim(),
        altPhone: document.getElementById("setting-alt-phone").value.trim(),
        email: document.getElementById("setting-email").value.trim(),
        shopType: document.getElementById("setting-shop-type").value.trim(),
        memoNotice: document.getElementById("setting-memo-notice").value.trim(),
        paperSize: document.getElementById("setting-paper-size").value,
        memoDesign: {
          ...(currentProfile.memoDesign || {}),
          primaryColorHex: document.getElementById("setting-primary-color").value,
          secondaryColorHex: document.getElementById("setting-secondary-color").value
        }
      };

      const webAppId = document.getElementById("setting-web-appid").value.trim();
      if (webAppId) {
        saveWebConfig(webAppId);
      }

      try {
        await saveShopProfile(db, currentUser.uid, updated);
        showToast("দোকানের সেটিংস সফলভাবে সংরক্ষিত হয়েছে!");
      } catch (err) {
        showToast("সেটিংস সংরক্ষণে ত্রুটি: " + err.message, true);
      }
    });
  }
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
