/**
 * Smart Memo Web - Firestore Database Service
 * Exactly matches Android ShopRepository.kt collection structure, field names & business logic.
 */

import {
  getFirestore,
  doc,
  collection,
  setDoc,
  updateDoc,
  deleteDoc,
  writeBatch,
  query,
  where,
  getDocs,
  onSnapshot,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// --- 1. Shop Profile ---
export function observeShopProfile(db, userId, onData, onError) {
  const profileRef = doc(db, "users", userId, "shop_profile", "info");
  return onSnapshot(profileRef, (snap) => {
    if (snap.exists()) {
      onData({ id: snap.id, ...snap.data() });
    } else {
      onData(null);
    }
  }, onError);
}

export async function saveShopProfile(db, userId, profileData) {
  const profileRef = doc(db, "users", userId, "shop_profile", "info");
  const payload = {
    userId: userId,
    shopName: profileData.shopName || "মেসার্স আল-আমিন ট্রেডার্স",
    ownerName: profileData.ownerName || "",
    address: profileData.address || "",
    phone: profileData.phone || "",
    altPhone: profileData.altPhone || "",
    email: profileData.email || "",
    memoNotice: profileData.memoNotice || "ধন্যবাদ, আবার আসবেন",
    paperSize: profileData.paperSize || "A4",
    designStyle: profileData.designStyle || "STANDARD",
    shopType: profileData.shopType || "স্যানিটারি ও ইলেকট্রিক",
    logoPath: profileData.logoPath || "",
    shopPhotoPath: profileData.shopPhotoPath || "",
    memoDesign: profileData.memoDesign || {},
    updatedAt: serverTimestamp()
  };
  await setDoc(profileRef, payload, { merge: true });
}

// --- 2. Products & Inventory ---
export function observeProducts(db, userId, onData, onError) {
  const productsCol = collection(db, "users", userId, "products");
  return onSnapshot(productsCol, (snap) => {
    const list = [];
    snap.forEach((d) => {
      list.push({ id: d.id, ...d.data() });
    });
    // Sort by name
    list.sort((a, b) => (a.name || "").localeCompare(b.name || ""));
    onData(list);
  }, onError);
}

export async function saveProduct(db, userId, product) {
  const productsCol = collection(db, "users", userId, "products");
  const docRef = product.id ? doc(db, "users", userId, "products", product.id) : doc(productsCol);
  const payload = {
    userId: userId,
    name: product.name.trim(),
    category: product.category || "অন্যান্য",
    unit: product.unit || "পিস",
    purchasePrice: Number(product.purchasePrice) || 0.0,
    salePrice: Number(product.salePrice) || 0.0,
    stock: Number(product.stock) || 0.0,
    code: product.code || "",
    updatedAt: serverTimestamp()
  };
  if (!product.id) {
    payload.createdAt = serverTimestamp();
  }
  await setDoc(docRef, payload, { merge: true });
  return docRef.id;
}

export async function deleteProduct(db, userId, productId) {
  const docRef = doc(db, "users", userId, "products", productId);
  await deleteDoc(docRef);
}

// --- 3. Customers ---
export function observeCustomers(db, userId, onData, onError) {
  const customersCol = collection(db, "users", userId, "customers");
  return onSnapshot(customersCol, (snap) => {
    const list = [];
    snap.forEach((d) => {
      list.push({ id: d.id, ...d.data() });
    });
    list.sort((a, b) => (a.name || "").localeCompare(b.name || ""));
    onData(list);
  }, onError);
}

export async function saveCustomer(db, userId, customer) {
  const customersCol = collection(db, "users", userId, "customers");
  const docRef = customer.id ? doc(db, "users", userId, "customers", customer.id) : doc(customersCol);
  const payload = {
    userId: userId,
    name: customer.name.trim(),
    phone: customer.phone ? customer.phone.trim() : "",
    address: customer.address || "",
    totalPurchases: Number(customer.totalPurchases) || 0.0,
    totalPaid: Number(customer.totalPaid) || 0.0,
    totalDue: Number(customer.totalDue) || 0.0,
    memoCount: Number(customer.memoCount) || 0,
    updatedAt: serverTimestamp()
  };
  if (!customer.id) {
    payload.createdAt = serverTimestamp();
  }
  await setDoc(docRef, payload, { merge: true });
  return docRef.id;
}

// --- 4. Memos ---
export function observeMemos(db, userId, onData, onError) {
  const memosCol = collection(db, "users", userId, "memos");
  return onSnapshot(memosCol, (snap) => {
    const list = [];
    snap.forEach((d) => {
      const data = d.data();
      if (!data.isDeleted) {
        list.push({ id: d.id, ...data });
      }
    });
    // Sort descending by memoNumber
    list.sort((a, b) => (b.memoNumber || "").localeCompare(a.memoNumber || ""));
    onData(list);
  }, onError);
}

export async function saveMemo(db, userId, memo, isNew = true) {
  const memosCol = collection(db, "users", userId, "memos");
  const targetId = memo.id || doc(memosCol).id;
  const docRef = doc(db, "users", userId, "memos", targetId);

  const payload = {
    id: targetId,
    userId: userId,
    memoNumber: memo.memoNumber || "#0001",
    memoDate: memo.memoDate,
    customerId: memo.customerId || "",
    customerName: memo.customerName ? memo.customerName.trim() : "",
    customerPhone: memo.customerPhone ? memo.customerPhone.trim() : "",
    customerAddress: memo.customerAddress || "",
    paymentType: memo.paymentType || "নগদ",
    items: memo.items || [],
    subtotal: Number(memo.subtotal) || 0.0,
    discount: Number(memo.discount) || 0.0,
    extraCharges: Number(memo.extraCharges) || 0.0,
    grandTotal: Number(memo.grandTotal) || 0.0,
    paidAmount: Number(memo.paidAmount) || 0.0,
    dueAmount: Number(memo.dueAmount) || 0.0,
    shopNameSnapshot: memo.shopNameSnapshot || "",
    shopAddressSnapshot: memo.shopAddressSnapshot || "",
    shopPhoneSnapshot: memo.shopPhoneSnapshot || "",
    memoNoticeSnapshot: memo.memoNoticeSnapshot || "ধন্যবাদ, আবার আসবেন",
    designConfig: memo.designConfig || {},
    isDeleted: false,
    updatedAt: serverTimestamp()
  };

  if (isNew) {
    payload.createdAt = serverTimestamp();
  }

  await setDoc(docRef, payload, { merge: true });

  // Update customer totals if customer name or phone is provided
  if (memo.customerName || memo.customerPhone) {
    try {
      await updateCustomerFromMemo(db, userId, memo);
    } catch (e) {
      console.warn("Customer update error:", e);
    }
  }

  // Deduct product inventory stock if items exist
  if (isNew && memo.items && memo.items.length > 0) {
    try {
      await deductInventoryStock(db, userId, memo.items);
    } catch (e) {
      console.warn("Stock deduction error:", e);
    }
  }

  return targetId;
}

export async function deleteMemo(db, userId, memoId) {
  const docRef = doc(db, "users", userId, "memos", memoId);
  await deleteDoc(docRef);
}

export async function deleteMemos(db, userId, memoIds) {
  if (!memoIds || memoIds.length === 0) return;
  // Firestore batches support up to 500 writes
  const chunks = [];
  for (let i = 0; i < memoIds.length; i += 400) {
    chunks.push(memoIds.slice(i, i + 400));
  }
  for (const chunk of chunks) {
    const batch = writeBatch(db);
    for (const id of chunk) {
      const docRef = doc(db, "users", userId, "memos", id);
      batch.delete(docRef);
    }
    await batch.commit();
  }
}

// Helpers for memo creation
async function updateCustomerFromMemo(db, userId, memo) {
  const phone = (memo.customerPhone || "").trim();
  const name = (memo.customerName || "").trim();
  const customersCol = collection(db, "users", userId, "customers");

  let customerDoc = null;
  if (phone) {
    const q = query(customersCol, where("phone", "==", phone));
    const snap = await getDocs(q);
    if (!snap.empty) {
      customerDoc = snap.docs[0];
    }
  }

  if (customerDoc) {
    const current = customerDoc.data();
    await updateDoc(customerDoc.ref, {
      totalPurchases: (Number(current.totalPurchases) || 0) + Number(memo.grandTotal),
      totalPaid: (Number(current.totalPaid) || 0) + Number(memo.paidAmount),
      totalDue: (Number(current.totalDue) || 0) + Number(memo.dueAmount),
      memoCount: (Number(current.memoCount) || 0) + 1,
      updatedAt: serverTimestamp()
    });
  } else {
    // Add new customer
    await setDoc(doc(customersCol), {
      userId: userId,
      name: name || "সাধারণ ক্রেতা",
      phone: phone,
      address: memo.customerAddress || "",
      totalPurchases: Number(memo.grandTotal),
      totalPaid: Number(memo.paidAmount),
      totalDue: Number(memo.dueAmount),
      memoCount: 1,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  }
}

async function deductInventoryStock(db, userId, items) {
  const productsCol = collection(db, "users", userId, "products");
  for (const item of items) {
    if (!item.productName || !item.productName.trim()) continue;
    const q = query(productsCol, where("name", "==", item.productName.trim()));
    const snap = await getDocs(q);
    for (const docSnap of snap.docs) {
      const currentStock = Number(docSnap.data().stock) || 0.0;
      const newStock = Math.max(0, currentStock - (Number(item.quantity) || 1));
      await updateDoc(docSnap.ref, {
        stock: newStock,
        updatedAt: serverTimestamp()
      });
    }
  }
}

// --- 5. Payments ---
export function observePayments(db, userId, onData, onError) {
  const paymentsCol = collection(db, "users", userId, "payments");
  return onSnapshot(paymentsCol, (snap) => {
    const list = [];
    snap.forEach((d) => {
      list.push({ id: d.id, ...d.data() });
    });
    // Sort descending by date
    list.sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    onData(list);
  }, onError);
}

export async function recordDuePayment(db, userId, { memo, customerId, customerName, amount, method, note, date }) {
  const paymentsCol = collection(db, "users", userId, "payments");
  const paymentDoc = doc(paymentsCol);

  const payload = {
    userId: userId,
    memoId: memo ? memo.id : "",
    memoNumber: memo ? memo.memoNumber : "",
    customerId: customerId || "",
    customerName: customerName || (memo ? memo.customerName : "সাধারণ ক্রেতা"),
    amount: Number(amount) || 0.0,
    date: date || new Date().toISOString().split("T")[0],
    paymentMethod: method || "নগদ",
    note: note || "",
    createdAt: serverTimestamp()
  };

  await setDoc(paymentDoc, payload);

  // Update customer totals
  if (customerId) {
    const custRef = doc(db, "users", userId, "customers", customerId);
    try {
      const snap = await getDocs(query(collection(db, "users", userId, "customers"), where("__name__", "==", customerId)));
      if (!snap.empty) {
        const cur = snap.docs[0].data();
        const curDue = Number(cur.totalDue) || 0.0;
        const curPaid = Number(cur.totalPaid) || 0.0;
        await updateDoc(custRef, {
          totalDue: Math.max(0, curDue - Number(amount)),
          totalPaid: curPaid + Number(amount),
          updatedAt: serverTimestamp()
        });
      }
    } catch (e) {
      console.warn("Customer payment update error:", e);
    }
  }

  // Update memo totals if memo is attached
  if (memo && memo.id) {
    const memoRef = doc(db, "users", userId, "memos", memo.id);
    const newPaid = (Number(memo.paidAmount) || 0.0) + Number(amount);
    const newDue = Math.max(0, (Number(memo.grandTotal) || 0.0) - newPaid);
    await updateDoc(memoRef, {
      paidAmount: newPaid,
      dueAmount: newDue,
      updatedAt: serverTimestamp()
    });
  }
}
