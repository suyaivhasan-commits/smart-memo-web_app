package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Memo
import com.example.data.model.MemoDesignConfig
import com.example.data.model.ShopProfile
import com.example.util.BengaliUtils
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MemoPaperView(
    memo: Memo,
    shopProfile: ShopProfile,
    modifier: Modifier = Modifier
) {
    val items = memo.items.filter { it.productName.isNotBlank() }
    val effectiveItems = if (items.isEmpty()) memo.items else items
    val itemsPerPage = 25
    val totalPages = ((effectiveItems.size - 1) / itemsPerPage + 1).coerceAtLeast(1)

    var currentPage by remember { mutableIntStateOf(0) }

    val design = if (memo.designConfig.presetId.isNotBlank() && memo.designConfig != MemoDesignConfig()) {
        memo.designConfig
    } else {
        shopProfile.memoDesign
    }
    val primaryColor = parseColorSafely(design.primaryColorHex, Color(0xFF0F2B48))
    val secondaryColor = parseColorSafely(design.secondaryColorHex, Color(0xFF00897B))
    val tableHeaderBg = parseColorSafely(design.tableHeaderBgHex, Color(0xFFF1F5F9))
    val tableLineColor = parseColorSafely(design.tableLineColorHex, Color(0xFF334155))

    val logoPath = memo.shopLogoSnapshot.ifBlank { shopProfile.logoPath }
    val hasLogo = design.showLogo && logoPath.isNotBlank() && File(logoPath).exists()

    val logoDp = when (design.logoSize) {
        "SMALL" -> 40.dp
        "LARGE" -> 64.dp
        else -> 52.dp
    }

    val studioImagePath = design.studioImagePath.ifBlank { shopProfile.memoDesign.studioImagePath }
    val hasStudioImage = design.showStudioImage && studioImagePath.isNotBlank() && File(studioImagePath).exists()
    val studioImageHeight = when (design.studioImageSize) {
        "SMALL" -> 55.dp
        "LARGE" -> 110.dp
        else -> 80.dp
    }
    val studioImagePaddingVal = when (design.studioImagePadding) {
        "COMPACT" -> 2.dp
        "SPACIOUS" -> 8.dp
        else -> 4.dp
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("memo_paper_view")
    ) {
        // Multi-page Tabs if > 25 items
        if (totalPages > 1) {
            Surface(
                color = primaryColor.copy(alpha = 0.08f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(4.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    for (i in 0 until totalPages) {
                        val isSelected = (currentPage == i)
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSelected) secondaryColor else Color.Transparent,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { currentPage = i }
                                .padding(vertical = 6.dp)
                        ) {
                            Text(
                                text = "পৃষ্ঠা ${i + 1} (${(i * 25) + 1} - ${((i + 1) * 25).coerceAtMost(effectiveItems.size)} নং পণ্য)",
                                color = if (isSelected) Color.White else primaryColor,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // The Paper Canvas Sheet
        Surface(
            color = Color.White,
            shadowElevation = 3.dp,
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, primaryColor, RoundedCornerShape(4.dp))
                .padding(2.dp)
                .border(0.8.dp, primaryColor.copy(alpha = 0.6f), RoundedCornerShape(2.dp))
                .padding(10.dp)
        ) {
            val startIdx = (currentPage * itemsPerPage).coerceAtMost(effectiveItems.size)
            val endIdx = (startIdx + itemsPerPage).coerceAtMost(effectiveItems.size)
            val pageItems = if (startIdx < endIdx) effectiveItems.subList(startIdx, endIdx) else emptyList()
            val isFinalPage = (currentPage == totalPages - 1)

            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                // Header Details
                val shopName = memo.shopNameSnapshot.ifBlank { shopProfile.shopName }
                val shopOwner = memo.shopOwnerSnapshot.ifBlank { shopProfile.ownerName }
                val shopAddr = memo.shopAddressSnapshot.ifBlank { shopProfile.address }
                val shopPhone = memo.shopPhoneSnapshot.ifBlank { shopProfile.phone }

                // Header Layout with Logo Support
                if (hasLogo && design.logoPosition == "CENTER") {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        AsyncImage(
                            model = File(logoPath),
                            contentDescription = "দোকানের লোগো",
                            modifier = Modifier
                                .size(logoDp)
                                .clip(CircleShape)
                                .border(1.dp, secondaryColor, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (hasLogo && design.logoPosition == "LEFT") {
                        AsyncImage(
                            model = File(logoPath),
                            contentDescription = "দোকানের লোগো",
                            modifier = Modifier
                                .size(logoDp)
                                .clip(CircleShape)
                                .border(1.5.dp, secondaryColor, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = shopName,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Black,
                            color = primaryColor,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (shopOwner.isNotBlank()) {
                            Text(
                                text = "প্রোপ্রাইটর: $shopOwner",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Text(
                            text = shopAddr,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF334155),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "মোবাইল: $shopPhone",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1E293B),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (hasLogo && design.logoPosition == "RIGHT") {
                        Spacer(modifier = Modifier.width(8.dp))
                        AsyncImage(
                            model = File(logoPath),
                            contentDescription = "দোকানের লোগো",
                            modifier = Modifier
                                .size(logoDp)
                                .clip(CircleShape)
                                .border(1.5.dp, secondaryColor, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Cash Memo Badge
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .background(secondaryColor, RoundedCornerShape(12.dp))
                        .padding(horizontal = 16.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "বিক্রয় মেমো",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Top Banner Design Image
                if (hasStudioImage && design.studioImagePosition == "TOP_BANNER") {
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = studioImagePaddingVal),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = File(studioImagePath),
                            contentDescription = "দোকানের ব্যানার",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(studioImageHeight)
                                .clip(RoundedCornerShape(6.dp))
                                .border(0.8.dp, primaryColor.copy(alpha = 0.35f), RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.Fit
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                }

                if (totalPages > 1) {
                    Text(
                        text = "পৃষ্ঠা ${currentPage + 1} / $totalPages",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor,
                        modifier = Modifier.align(Alignment.End)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Memo & Customer Meta Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "মেমো নং: ${memo.memoNumber}",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor
                    )
                    Text(
                        text = "তারিখ: ${memo.memoDate.ifBlank { BengaliUtils.getCurrentDateStr() }}",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "ক্রেতা: ${memo.customerName.ifBlank { "সাধারণ ক্রেতা" }}",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF000000)
                    )
                    Text(
                        text = "মোবাইল: ${memo.customerPhone.ifBlank { "—" }}",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF000000)
                    )
                }

                if (memo.customerAddress.isNotBlank()) {
                    Text(
                        text = "ঠিকানা: ${memo.customerAddress}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF1E293B)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Table Header
                Surface(
                    color = tableHeaderBg,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.8.dp, tableLineColor)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "নং",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.width(30.dp)
                        )
                        Box(modifier = Modifier.width(0.8.dp).height(16.dp).background(tableLineColor))
                        Text(
                            text = "পণ্যের বিবরণ",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor,
                            modifier = Modifier.weight(1f).padding(start = 6.dp)
                        )
                        Box(modifier = Modifier.width(0.8.dp).height(16.dp).background(tableLineColor))
                        Text(
                            text = "পরিমাণ",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.width(44.dp)
                        )
                        Box(modifier = Modifier.width(0.8.dp).height(16.dp).background(tableLineColor))
                        Text(
                            text = "একক",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.width(38.dp)
                        )
                        Box(modifier = Modifier.width(0.8.dp).height(16.dp).background(tableLineColor))
                        Text(
                            text = "দর (৳)",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor,
                            textAlign = TextAlign.End,
                            modifier = Modifier.width(48.dp).padding(end = 4.dp)
                        )
                        Box(modifier = Modifier.width(0.8.dp).height(16.dp).background(tableLineColor))
                        Text(
                            text = "মোট (৳)",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor,
                            textAlign = TextAlign.End,
                            modifier = Modifier.width(58.dp).padding(end = 6.dp)
                        )
                    }
                }

                // Table Rows (up to 25 rows per page)
                val rowsToShow = maxOf(pageItems.size, 8).coerceAtMost(itemsPerPage)

                for (i in 0 until rowsToShow) {
                    val item = pageItems.getOrNull(i)
                    val rowBg = if (i % 2 == 1) Color(0xFFF8FAFC) else Color.White

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(rowBg)
                            .border(0.5.dp, tableLineColor.copy(alpha = 0.4f))
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val serialText = item?.serial?.toString() ?: "${(currentPage * itemsPerPage) + i + 1}"
                        Text(
                            text = serialText,
                            fontSize = 10.sp,
                            color = if (item != null) Color(0xFF000000) else Color(0xFF94A3B8),
                            fontWeight = if (item != null) FontWeight.SemiBold else FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.width(30.dp)
                        )
                        Text(
                            text = item?.productName ?: "",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF000000),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).padding(start = 6.dp)
                        )
                        Text(
                            text = if (item != null) BengaliUtils.formatCleanNumber(item.quantity) else "",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF000000),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.width(44.dp)
                        )
                        Text(
                            text = item?.unit ?: "",
                            fontSize = 9.5.sp,
                            color = Color(0xFF1E293B),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.width(38.dp)
                        )
                        Text(
                            text = if (item != null) BengaliUtils.formatNumber(item.unitPrice) else "",
                            fontSize = 10.sp,
                            color = Color(0xFF000000),
                            textAlign = TextAlign.End,
                            modifier = Modifier.width(48.dp).padding(end = 4.dp)
                        )
                        Text(
                            text = if (item != null) BengaliUtils.formatNumber(item.totalPrice) else "",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF000000),
                            textAlign = TextAlign.End,
                            modifier = Modifier.width(58.dp).padding(end = 6.dp)
                        )
                    }
                }

                // Product Images Preview Section (if BELOW_TABLE and has images)
                val showPhotos = design.showProductImages && memo.productImages.isNotEmpty()
                if (showPhotos && design.productImagesPosition == "BELOW_TABLE") {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "পণ্যের ছবি:",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        memo.productImages.take(5).forEach { imgPath ->
                            if (File(imgPath).exists()) {
                                AsyncImage(
                                    model = File(imgPath),
                                    contentDescription = "পণ্য",
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .border(1.dp, tableLineColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }
                }

                // Below Table Studio Image
                if (hasStudioImage && design.studioImagePosition == "BELOW_TABLE") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = studioImagePaddingVal),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = File(studioImagePath),
                            contentDescription = "ডিজাইন ছবি",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(studioImageHeight)
                                .clip(RoundedCornerShape(6.dp))
                                .border(0.8.dp, tableLineColor.copy(alpha = 0.35f), RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.Fit
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Calculations (on final page)
                if (isFinalPage) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                            // If photos are BESIDE_TOTALS
                            if (showPhotos && design.productImagesPosition == "BESIDE_TOTALS") {
                                Text(
                                    text = "পণ্যের ছবি:",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = primaryColor
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    memo.productImages.take(3).forEach { imgPath ->
                                        if (File(imgPath).exists()) {
                                            AsyncImage(
                                                model = File(imgPath),
                                                contentDescription = "পণ্য",
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .border(0.8.dp, tableLineColor, RoundedCornerShape(4.dp)),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                            }

                            // Beside Totals Studio Image
                            if (hasStudioImage && design.studioImagePosition == "BESIDE_TOTALS") {
                                Box(modifier = Modifier.padding(vertical = studioImagePaddingVal)) {
                                    AsyncImage(
                                        model = File(studioImagePath),
                                        contentDescription = "ডিজাইন ছবি",
                                        modifier = Modifier
                                            .width(130.dp)
                                            .height(studioImageHeight)
                                            .clip(RoundedCornerShape(4.dp))
                                            .border(0.8.dp, tableLineColor.copy(alpha = 0.35f), RoundedCornerShape(4.dp)),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }

                            Text(
                                text = memo.memoNoticeSnapshot.ifBlank { shopProfile.memoNotice },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = secondaryColor
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "পেমেন্ট পদ্ধতি: ${memo.paymentType}",
                                fontSize = 10.sp,
                                color = Color(0xFF475569)
                            )
                        }

                        // Totals Summary Box
                        Column(
                            modifier = Modifier
                                .width(160.dp)
                                .border(0.8.dp, tableLineColor, RoundedCornerShape(2.dp))
                        ) {
                            SummaryRow(label = "মোট পণ্য মূল্য:", value = BengaliUtils.formatTaka(memo.subtotal))
                            if (memo.discount > 0.0) {
                                SummaryRow(label = "ছাড়:", value = BengaliUtils.formatTaka(memo.discount))
                            }
                            if (memo.extraCharges > 0.0) {
                                SummaryRow(label = "অতিরিক্ত চার্জ:", value = BengaliUtils.formatTaka(memo.extraCharges))
                            }
                            SummaryRow(
                                label = "সর্বমোট বিল:",
                                value = BengaliUtils.formatTaka(memo.grandTotal),
                                isHighlight = true,
                                highlightBg = tableHeaderBg
                            )
                            SummaryRow(label = "জমা টাকা:", value = BengaliUtils.formatTaka(memo.paidAmount))
                            SummaryRow(
                                label = "বাকি টাকা:",
                                value = BengaliUtils.formatTaka(memo.dueAmount),
                                textColor = if (memo.dueAmount > 0) Color(0xFFDC2626) else Color(0xFF16A34A)
                            )
                        }
                    }
                } else {
                    Text(
                        text = "পরবর্তী পৃষ্ঠায় সমাপ্তি... ->",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(26.dp))

                // Signatures
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(modifier = Modifier.width(90.dp).height(1.dp).background(Color(0xFF64748B)))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "ক্রেতার স্বাক্ষর", fontSize = 9.5.sp, color = Color(0xFF475569))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(modifier = Modifier.width(90.dp).height(1.dp).background(Color(0xFF64748B)))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "বিক্রেতার স্বাক্ষর", fontSize = 9.5.sp, color = Color(0xFF475569))
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(
    label: String,
    value: String,
    isHighlight: Boolean = false,
    highlightBg: Color = Color(0xFFE2E8F0),
    textColor: Color = Color(0xFF0F172A)
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isHighlight) highlightBg else Color.Transparent)
            .border(0.4.dp, Color(0xFFCBD5E1))
            .padding(horizontal = 6.dp, vertical = 2.5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 9.5.sp,
            fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.Medium,
            color = Color(0xFF1E293B)
        )
        Text(
            text = value,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

private fun parseColorSafely(hex: String, defaultColor: Color): Color {
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) {
        defaultColor
    }
}
