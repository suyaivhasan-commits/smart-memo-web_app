package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Pages
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemoItem
import com.example.data.model.Product
import com.example.ui.components.AppHeader
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel
import com.example.util.BengaliUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewMemoScreen(
    viewModel: SmartMemoViewModel
) {
    val context = LocalContext.current
    val shopProfile by viewModel.shopProfile.collectAsState()
    val memoNumber by viewModel.formMemoNumber.collectAsState()
    val memoDate by viewModel.formMemoDate.collectAsState()
    val customerName by viewModel.formCustomerName.collectAsState()
    val customerPhone by viewModel.formCustomerPhone.collectAsState()
    val customerAddress by viewModel.formCustomerAddress.collectAsState()
    val paymentType by viewModel.formPaymentType.collectAsState()
    val discountStr by viewModel.formDiscount.collectAsState()
    val extraChargesStr by viewModel.formExtraCharges.collectAsState()
    val paidAmountStr by viewModel.formPaidAmount.collectAsState()
    val items by viewModel.formItems.collectAsState()
    val products by viewModel.products.collectAsState()
    val customers by viewModel.customers.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    val subtotal = viewModel.computeFormSubtotal()
    val grandTotal = viewModel.computeFormGrandTotal()
    val dueAmount = viewModel.computeFormDue()

    val highContrastColors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFF000000),
        unfocusedTextColor = Color(0xFF000000),
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White,
        focusedLabelColor = Color(0xFF111111),
        unfocusedLabelColor = Color(0xFF111111),
        focusedPlaceholderColor = Color(0xFF333333),
        unfocusedPlaceholderColor = Color(0xFF333333),
        focusedBorderColor = SmartTealPrimary,
        unfocusedBorderColor = Color(0xFF475569),
        cursorColor = Color(0xFF000000)
    )

    val boldInputStyle = androidx.compose.ui.text.TextStyle(
        color = Color(0xFF000000),
        fontSize = 13.5.sp,
        fontWeight = FontWeight.SemiBold
    )

    // 25 items per page calculation
    val itemsPerPage = 25
    val totalPages = ((items.size - 1) / itemsPerPage + 1).coerceAtLeast(1)
    var activePage by remember { mutableIntStateOf(0) }

    // Dialog for picking existing inventory product
    var showProductPickerForIndex by remember { mutableStateOf<Int?>(null) }
    var showCustomerPicker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("new_memo_screen")
    ) {
        AppHeader(
            title = if (viewModel.editingMemoId.collectAsState().value != null) "মেমো সম্পাদনা" else "নতুন মেমো",
            shopProfile = shopProfile,
            showBackButton = true,
            onBackClick = { viewModel.navigateBack() },
            onSettingsClick = { viewModel.navigateTo(Screen.SHOP_SETTINGS) }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Shop Details Preview Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = shopProfile.shopName,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = SmartNavyPrimary
                        )
                        Text(
                            text = "${shopProfile.address} | ☎ ${shopProfile.phone}",
                            fontSize = 11.5.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            // Customer & Memo Metadata Inputs
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = memoNumber,
                                onValueChange = { viewModel.formMemoNumber.value = it },
                                label = { Text("মেমো নং", fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("memo_number_input"),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = memoDate,
                                onValueChange = { viewModel.formMemoDate.value = it },
                                label = { Text("তারিখ (DD-MM-YYYY)", fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("memo_date_input"),
                                singleLine = true
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = customerName,
                                onValueChange = { viewModel.formCustomerName.value = it },
                                label = { Text("ক্রেতার নাম", fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                placeholder = { Text("ক্রেতার নাম লিখুন...", color = Color(0xFF333333)) },
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("customer_name_input"),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            OutlinedButton(
                                onClick = { showCustomerPicker = true },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("খুঁজুন", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111111))
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = customerPhone,
                                onValueChange = { viewModel.formCustomerPhone.value = it },
                                label = { Text("মোবাইল নম্বর", fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                placeholder = { Text("০১৭১২-...", color = Color(0xFF333333)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("customer_phone_input"),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = customerAddress,
                                onValueChange = { viewModel.formCustomerAddress.value = it },
                                label = { Text("ঠিকানা (ঐচ্ছিক)", fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                placeholder = { Text("ঠিকানা...", color = Color(0xFF333333)) },
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        // Payment Type Selector
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "পেমেন্ট:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SmartNavyPrimary
                            )
                            listOf("নগদ", "বিকাশ", "নগদ/বাকি", "বাকি").forEach { type ->
                                val selected = (paymentType == type)
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (selected) SmartTealPrimary else Color(0xFFE2E8F0),
                                    modifier = Modifier
                                        .clickable { viewModel.formPaymentType.value = type }
                                        .padding(vertical = 2.dp)
                                ) {
                                    Text(
                                        text = type,
                                        fontSize = 11.5.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selected) Color.White else Color(0xFF1E293B),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Multi-Page Indicator if > 25 items
            if (totalPages > 1) {
                item {
                    Surface(
                        color = Color(0xFFDBEAFE),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Pages,
                                    contentDescription = null,
                                    tint = Color(0xFF1E40AF),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "মোট $totalPages টি পৃষ্ঠা (সর্বমোট ${items.size} টি পণ্য)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E40AF)
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                for (p in 0 until totalPages) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (activePage == p) SmartTealPrimary else Color.White,
                                        modifier = Modifier
                                            .clickable { activePage = p }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "পৃষ্ঠা ${p + 1}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (activePage == p) Color.White else Color(0xFF1E293B)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section Header for Items
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "পণ্যের বিবরণ (পৃষ্ঠা ${activePage + 1}: ${(activePage * itemsPerPage) + 1} থেকে ${((activePage + 1) * itemsPerPage).coerceAtMost(items.size)} নং)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = SmartNavyPrimary
                    )

                    Button(
                        onClick = {
                            viewModel.addFormItemRow()
                            // If just crossed 25 items boundary, jump to the new page
                            val newSize = items.size + 1
                            if (newSize > (activePage + 1) * itemsPerPage) {
                                activePage = (newSize - 1) / itemsPerPage
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("add_product_row_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ পণ্য যোগ করুন", fontSize = 12.sp)
                    }
                }
            }

            // Items List for Active Page (up to 25 items per page)
            val pageStart = activePage * itemsPerPage
            val pageEnd = (pageStart + itemsPerPage).coerceAtMost(items.size)
            val currentItems = items.subList(pageStart, pageEnd)

            itemsIndexed(currentItems) { relativeIdx, item ->
                val actualIndex = pageStart + relativeIdx

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = SmartNavyPrimary.copy(alpha = 0.08f)
                            ) {
                                Text(
                                    text = "${item.serial} নং",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SmartNavyPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            OutlinedTextField(
                                value = item.productName,
                                onValueChange = { newName ->
                                    viewModel.updateFormItemWithStrings(
                                        actualIndex,
                                        newName,
                                        item.quantityStr,
                                        item.unit,
                                        item.unitPriceStr
                                    )
                                },
                                label = { Text("পণ্যের নাম *", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                placeholder = { Text("যেমন: LED বাল্ব", color = Color(0xFF333333)) },
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("product_name_input_$actualIndex"),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.width(6.dp))

                            // Pick from product inventory button
                            IconButton(
                                onClick = { showProductPickerForIndex = actualIndex },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Inventory,
                                    contentDescription = "স্টক থেকে বাছুন",
                                    tint = SmartTealPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            if (items.size > 1) {
                                IconButton(
                                    onClick = { viewModel.removeFormItem(actualIndex) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "মুছুন",
                                        tint = Color(0xFFDC2626),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Quantity, Unit, Rate, Total
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = item.quantityStr,
                                onValueChange = { qStr ->
                                    viewModel.updateFormItemWithStrings(
                                        actualIndex,
                                        item.productName,
                                        qStr,
                                        item.unit,
                                        item.unitPriceStr
                                    )
                                },
                                label = { Text("পরিমাণ", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                placeholder = { Text("১০", color = Color(0xFF333333)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("quantity_input_$actualIndex"),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = item.unit,
                                onValueChange = { u ->
                                    viewModel.updateFormItemWithStrings(
                                        actualIndex,
                                        item.productName,
                                        item.quantityStr,
                                        u,
                                        item.unitPriceStr
                                    )
                                },
                                label = { Text("একক", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                placeholder = { Text("পিস", color = Color(0xFF333333)) },
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier.weight(0.9f),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = item.unitPriceStr,
                                onValueChange = { rStr ->
                                    viewModel.updateFormItemWithStrings(
                                        actualIndex,
                                        item.productName,
                                        item.quantityStr,
                                        item.unit,
                                        rStr
                                    )
                                },
                                label = { Text("দর (৳)", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                placeholder = { Text("৫০", color = Color(0xFF333333)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier
                                    .weight(1.1f)
                                    .testTag("rate_input_$actualIndex"),
                                singleLine = true
                            )

                            Surface(
                                modifier = Modifier.weight(1.3f),
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFF1F5F9),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Text("মোট মূল্য", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111111))
                                    Text(
                                        text = BengaliUtils.formatTaka(item.totalPrice),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF0F172A),
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Calculation Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "বিল ও হিসাব বিবরণী",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = SmartNavyPrimary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("মোট পণ্যমূল্য:", fontSize = 13.sp, color = Color(0xFF475569))
                            Text(
                                text = BengaliUtils.formatTaka(subtotal),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = SmartNavyPrimary
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = discountStr,
                                onValueChange = { viewModel.formDiscount.value = it },
                                label = { Text("ছাড় (৳)", fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                placeholder = { Text("০", color = Color(0xFF333333)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("discount_input"),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = extraChargesStr,
                                onValueChange = { viewModel.formExtraCharges.value = it },
                                label = { Text("অন্যান্য খরচ (৳)", fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                placeholder = { Text("০", color = Color(0xFF333333)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("extra_charges_input"),
                                singleLine = true
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFE2E8F0),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "সর্বমোট বিল:",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SmartNavyPrimary
                                )
                                Text(
                                    text = BengaliUtils.formatTaka(grandTotal),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = SmartNavyPrimary
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = paidAmountStr,
                                onValueChange = { viewModel.formPaidAmount.value = it },
                                label = { Text("জমা টাকা (৳)", fontWeight = FontWeight.Bold, color = Color(0xFF111111)) },
                                placeholder = { Text(BengaliUtils.formatNumber(grandTotal), color = Color(0xFF333333)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                colors = highContrastColors,
                                textStyle = boldInputStyle,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("paid_amount_input"),
                                singleLine = true
                            )

                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                color = if (dueAmount > 0) Color(0xFFFEE2E2) else Color(0xFFDCFCE7)
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Text(
                                        text = if (dueAmount > 0) "বাকি টাকা" else "অবস্থা",
                                        fontSize = 11.sp,
                                        color = if (dueAmount > 0) Color(0xFF991B1B) else Color(0xFF166534)
                                    )
                                    Text(
                                        text = if (dueAmount > 0) BengaliUtils.formatTaka(dueAmount) else "পরিশোধিত",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (dueAmount > 0) Color(0xFFDC2626) else Color(0xFF16A34A)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.startNewMemo() },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("রিসেট")
                    }

                    Button(
                        onClick = {
                            viewModel.saveMemo { savedMemo ->
                                Toast.makeText(context, "মেমো সফলভাবে সংরক্ষণ করা হয়েছে!", Toast.LENGTH_SHORT).show()
                                viewModel.selectMemoForDetail(savedMemo)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                        modifier = Modifier
                            .weight(2f)
                            .height(48.dp)
                            .testTag("save_memo_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("সংরক্ষণ ও মেমো দেখুন", fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    // Product Picker Dialog
    if (showProductPickerForIndex != null) {
        val targetIdx = showProductPickerForIndex!!
        AlertDialog(
            onDismissRequest = { showProductPickerForIndex = null },
            title = { Text("স্টক থেকে পণ্য নির্বাচন করুন") },
            text = {
                if (products.isEmpty()) {
                    Text("কোনো সংরক্ষিত পণ্য পাওয়া যায়নি। পণ্য তালিকায় পণ্য যোগ করুন।")
                } else {
                    LazyColumn(modifier = Modifier.height(260.dp)) {
                        items(products.size) { pIdx ->
                            val p = products[pIdx]
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.updateFormItemWithStrings(
                                            targetIdx,
                                            p.name,
                                            "1",
                                            p.unit,
                                            BengaliUtils.formatCleanNumber(p.salePrice)
                                        )
                                        showProductPickerForIndex = null
                                    }
                                    .padding(vertical = 6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(p.name, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                                        Text("${p.category} | স্টক: ${p.stock} ${p.unit}", fontSize = 11.sp, color = Color(0xFF64748B))
                                    }
                                    Text(BengaliUtils.formatTaka(p.salePrice), fontWeight = FontWeight.Bold, color = SmartTealPrimary)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showProductPickerForIndex = null }) {
                    Text("বন্ধ করুন")
                }
            }
        )
    }

    // Customer Picker Dialog
    if (showCustomerPicker) {
        AlertDialog(
            onDismissRequest = { showCustomerPicker = false },
            title = { Text("সংরক্ষিত গ্রাহক নির্বাচন করুন") },
            text = {
                if (customers.isEmpty()) {
                    Text("কোনো সংরক্ষিত গ্রাহক পাওয়া যায়নি।")
                } else {
                    LazyColumn(modifier = Modifier.height(260.dp)) {
                        items(customers.size) { cIdx ->
                            val c = customers[cIdx]
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.formCustomerName.value = c.name
                                        viewModel.formCustomerPhone.value = c.phone
                                        viewModel.formCustomerAddress.value = c.address
                                        showCustomerPicker = false
                                    }
                                    .padding(vertical = 6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(c.name, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                                        Text(c.phone, fontSize = 11.5.sp, color = Color(0xFF64748B))
                                    }
                                    if (c.totalDue > 0) {
                                        Text("বাকি: ${BengaliUtils.formatTaka(c.totalDue)}", fontSize = 11.sp, color = Color(0xFFDC2626))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCustomerPicker = false }) {
                    Text("বন্ধ করুন")
                }
            }
        )
    }
}
