package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.ui.components.AppHeader
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import java.io.File
import java.io.FileOutputStream

@Composable
fun BackupScreen(
    viewModel: SmartMemoViewModel
) {
    val context = LocalContext.current
    val shopProfile by viewModel.shopProfile.collectAsState()
    val memos by viewModel.memos.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val products by viewModel.products.collectAsState()
    val user = Firebase.auth.currentUser

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("backup_screen")
    ) {
        AppHeader(
            title = "ব্যাকআপ ও ডেটা পুনরুদ্ধার",
            shopProfile = shopProfile,
            showBackButton = true,
            onBackClick = { viewModel.navigateBack() },
            onSettingsClick = { viewModel.navigateTo(Screen.SHOP_SETTINGS) }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Cloud Sync Status Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFDCFCE7)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudDone,
                                    contentDescription = null,
                                    tint = Color(0xFF16A34A),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "ক্লাউড সিঙ্ক সক্রিয়",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SmartNavyPrimary
                                )
                                Text(
                                    text = "Firebase Firestore নিরাপদ ডেটাবেস",
                                    fontSize = 12.sp,
                                    color = Color(0xFF16A34A),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "আপনার প্রতিটি মেমো, পণ্য তালিকা, গ্রাহক তথ্য ও হিসাব ক্লাউডে তাৎক্ষণিকভাবে স্বয়ংক্রিয়ভাবে সংরক্ষিত হচ্ছে। নতুন ফোনে বা অ্যাপ পুনরায় ইনস্টল করলেও এই গুগল অ্যাকাউন্ট দিয়ে লগইন করলে আপনার সম্পূর্ণ ডেটা হুবহু ফিরে পাবেন।",
                            fontSize = 12.5.sp,
                            color = Color(0xFF475569),
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF1F5F9),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("লগইনকৃত অ্যাকাউন্ট:", fontSize = 11.sp, color = Color(0xFF64748B))
                                Text(user?.email ?: "গুগল অ্যাকাউন্ট", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SmartNavyPrimary)
                                Text("দোকানদার আইডি (User ID): ${user?.uid?.take(16)}...", fontSize = 10.sp, color = Color(0xFF94A3B8))
                            }
                        }
                    }
                }
            }

            // Export Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, tint = SmartTealPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "অফলাইন এক্সপোর্ট (CSV ফাইল)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = SmartNavyPrimary
                            )
                        }

                        Text(
                            text = "আপনার কম্পিউটারে বা এক্সেল সফটওয়্যারে হিসাব সংরক্ষণ করার জন্য মেমো এবং গ্রাহকের তালিকা CSV ফাইল আকারে ডাউনলোড বা শেয়ার করুন।",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )

                        Button(
                            onClick = {
                                exportMemosCsv(context, memos, shopProfile.shopName)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("সব মেমো CSV ডাউনলোড করুন (${memos.size} টি মেমো)")
                        }

                        OutlinedButton(
                            onClick = {
                                exportCustomersCsv(context, customers, shopProfile.shopName)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("গ্রাহকের হিসাব CSV ডাউনলোড করুন (${customers.size} জন)")
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

private fun exportMemosCsv(context: android.content.Context, memos: List<com.example.data.model.Memo>, shopName: String) {
    try {
        val file = File(context.cacheDir, "SmartMemo_Memos.csv")
        FileOutputStream(file).use { out ->
            val header = "MemoNumber,Date,CustomerName,Phone,Subtotal,Discount,GrandTotal,Paid,Due,ItemsCount\n"
            out.write(header.toByteArray(Charsets.UTF_8))
            for (m in memos) {
                val row = "\"${m.memoNumber}\",\"${m.memoDate}\",\"${m.customerName}\",\"${m.customerPhone}\",${m.subtotal},${m.discount},${m.grandTotal},${m.paidAmount},${m.dueAmount},${m.items.size}\n"
                out.write(row.toByteArray(Charsets.UTF_8))
            }
        }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "মেমো CSV এক্সপোর্ট"))
    } catch (e: Exception) {
        Toast.makeText(context, "এক্সপোর্ট ব্যর্থ: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun exportCustomersCsv(context: android.content.Context, customers: List<com.example.data.model.Customer>, shopName: String) {
    try {
        val file = File(context.cacheDir, "SmartMemo_Customers.csv")
        FileOutputStream(file).use { out ->
            val header = "Name,Phone,Address,TotalPurchases,TotalPaid,TotalDue,MemoCount\n"
            out.write(header.toByteArray(Charsets.UTF_8))
            for (c in customers) {
                val row = "\"${c.name}\",\"${c.phone}\",\"${c.address}\",${c.totalPurchases},${c.totalPaid},${c.totalDue},${c.memoCount}\n"
                out.write(row.toByteArray(Charsets.UTF_8))
            }
        }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "গ্রাহক CSV এক্সপোর্ট"))
    } catch (e: Exception) {
        Toast.makeText(context, "এক্সপোর্ট ব্যর্থ: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
