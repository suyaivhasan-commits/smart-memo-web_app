package com.example.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LocalShopStorage
import com.example.data.model.Customer
import com.example.data.model.Memo
import com.example.data.model.MemoDesignConfig
import com.example.data.model.MemoItem
import com.example.data.model.Payment
import com.example.data.model.Product
import com.example.data.model.ShopProfile
import com.example.data.repository.ShopRepository
import com.example.util.BengaliUtils
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class Screen {
    DASHBOARD,
    NEW_MEMO,
    MEMO_ARCHIVE,
    MEMO_DETAIL,
    PDF_PREVIEW,
    CUSTOMERS,
    PRODUCTS,
    DUE_MANAGEMENT,
    REPORTS,
    SHOP_SETTINGS,
    MEMO_DESIGN_STUDIO,
    BACKUP,
    HELP
}

enum class TimeFilter {
    ALL, TODAY, THIS_WEEK, THIS_MONTH, THIS_YEAR
}

enum class StatusFilter {
    ALL, PAID, DUE
}

class SmartMemoViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ShopRepository(application)
    private val auth: FirebaseAuth = Firebase.auth
    private val localShopStorage = LocalShopStorage(application)

    // --- Navigation & Backstack ---
    private val _currentScreen = MutableStateFlow(Screen.DASHBOARD)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenBackStack = mutableListOf<Screen>()

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            screenBackStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        return if (screenBackStack.isNotEmpty()) {
            _currentScreen.value = screenBackStack.removeAt(screenBackStack.size - 1)
            true
        } else if (_currentScreen.value != Screen.DASHBOARD) {
            _currentScreen.value = Screen.DASHBOARD
            true
        } else {
            false
        }
    }

    // --- Auth State ---
    private val _currentUser = MutableStateFlow<FirebaseUser?>(auth.currentUser)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    init {
        auth.addAuthStateListener { firebaseAuth ->
            _currentUser.value = firebaseAuth.currentUser
            if (firebaseAuth.currentUser != null) {
                loadUserData(firebaseAuth.currentUser!!.uid)
            }
        }
    }

    // --- Data Streams ---
    private val _shopProfile = MutableStateFlow(localShopStorage.loadProfile() ?: ShopProfile())
    val shopProfile: StateFlow<ShopProfile> = _shopProfile.asStateFlow()

    private val _memos = MutableStateFlow<List<Memo>>(emptyList())
    val memos: StateFlow<List<Memo>> = _memos.asStateFlow()

    private val _customers = MutableStateFlow<List<Customer>>(emptyList())
    val customers: StateFlow<List<Customer>> = _customers.asStateFlow()

    private val _products = MutableStateFlow<List<Product>>(emptyList())
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _payments = MutableStateFlow<List<Payment>>(emptyList())
    val payments: StateFlow<List<Payment>> = _payments.asStateFlow()

    private fun loadUserData(userId: String) {
        viewModelScope.launch {
            repository.observeShopProfile(userId).collect { profile ->
                if (profile != null) {
                    val local = localShopStorage.loadProfile()
                    val merged = if (profile.memoDesign != MemoDesignConfig()) {
                        profile
                    } else if (local != null && local.memoDesign != MemoDesignConfig()) {
                        profile.copy(memoDesign = local.memoDesign)
                    } else {
                        profile
                    }
                    _shopProfile.value = merged
                    studioDesignDraft.value = merged.memoDesign
                    localShopStorage.saveProfile(merged)
                } else {
                    // Seed initial default profile from local storage if available
                    val initial = localShopStorage.loadProfile() ?: ShopProfile(
                        userId = userId,
                        shopName = "মেসার্স আল-আমিন ট্রেডার্স",
                        ownerName = "মোঃ আব্দুল করিম",
                        address = "১২০, বাজার রোড, রাজশাহী",
                        phone = "০১৭১২-০৪৬৫৭৮",
                        email = auth.currentUser?.email ?: "",
                        memoNotice = "ধন্যবাদ, আবার আসবেন"
                    )
                    _shopProfile.value = initial
                    studioDesignDraft.value = initial.memoDesign
                    localShopStorage.saveProfile(initial)
                    repository.saveShopProfile(initial)
                }
            }
        }

        viewModelScope.launch {
            repository.observeMemos(userId).collect { list ->
                _memos.value = list
            }
        }

        viewModelScope.launch {
            repository.observeCustomers(userId).collect { list ->
                _customers.value = list
            }
        }

        viewModelScope.launch {
            repository.observeProducts(userId).collect { list ->
                _products.value = list
            }
        }

        viewModelScope.launch {
            repository.observePayments(userId).collect { list ->
                _payments.value = list
            }
        }
    }

    // --- Filter & Search State for Archive ---
    val searchQuery = MutableStateFlow("")
    val selectedTimeFilter = MutableStateFlow(TimeFilter.ALL)
    val selectedStatusFilter = MutableStateFlow(StatusFilter.ALL)

    val filteredMemos: StateFlow<List<Memo>> = combine(
        _memos,
        searchQuery,
        selectedTimeFilter,
        selectedStatusFilter
    ) { memosList, query, timeFilter, statusFilter ->
        val trimmedQuery = query.trim().lowercase(Locale.ROOT)
        val todayStr = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())

        memosList.filter { memo ->
            val matchesQuery = if (trimmedQuery.isBlank()) true else {
                memo.memoNumber.lowercase(Locale.ROOT).contains(trimmedQuery) ||
                memo.customerName.lowercase(Locale.ROOT).contains(trimmedQuery) ||
                memo.customerPhone.contains(trimmedQuery)
            }

            val matchesTime = when (timeFilter) {
                TimeFilter.ALL -> true
                TimeFilter.TODAY -> memo.memoDate == todayStr
                TimeFilter.THIS_WEEK -> isDateInCurrentWeek(memo.memoDate)
                TimeFilter.THIS_MONTH -> isDateInCurrentMonth(memo.memoDate)
                TimeFilter.THIS_YEAR -> isDateInCurrentYear(memo.memoDate)
            }

            val matchesStatus = when (statusFilter) {
                StatusFilter.ALL -> true
                StatusFilter.PAID -> memo.dueAmount <= 0.0
                StatusFilter.DUE -> memo.dueAmount > 0.0
            }

            matchesQuery && matchesTime && matchesStatus
        }.sortedByDescending { it.memoNumber }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Dashboard Aggregates ---
    val todaySales: StateFlow<Double> = _memos.combine(MutableStateFlow(Unit)) { list, _ ->
        val todayStr = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
        list.filter { it.memoDate == todayStr }.sumOf { it.grandTotal }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todayMemoCount: StateFlow<Int> = _memos.combine(MutableStateFlow(Unit)) { list, _ ->
        val todayStr = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
        list.count { it.memoDate == todayStr }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalDues: StateFlow<Double> = _memos.combine(MutableStateFlow(Unit)) { list, _ ->
        list.sumOf { it.dueAmount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalSalesAllTime: StateFlow<Double> = _memos.combine(MutableStateFlow(Unit)) { list, _ ->
        list.sumOf { it.grandTotal }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun openTodayMemos() {
        searchQuery.value = ""
        selectedTimeFilter.value = TimeFilter.TODAY
        selectedStatusFilter.value = StatusFilter.ALL
        navigateTo(Screen.MEMO_ARCHIVE)
    }

    fun openDueMemos() {
        searchQuery.value = ""
        selectedTimeFilter.value = TimeFilter.ALL
        selectedStatusFilter.value = StatusFilter.DUE
        navigateTo(Screen.MEMO_ARCHIVE)
    }

    // --- New / Edit Memo Form State ---
    var editingMemoId = MutableStateFlow<String?>(null)
    var formMemoNumber = MutableStateFlow("")
    var formMemoDate = MutableStateFlow(BengaliUtils.getCurrentDateStr())
    var formCustomerName = MutableStateFlow("")
    var formCustomerPhone = MutableStateFlow("")
    var formCustomerAddress = MutableStateFlow("")
    var formPaymentType = MutableStateFlow("নগদ")
    var formDiscount = MutableStateFlow("0")
    var formExtraCharges = MutableStateFlow("0")
    var formPaidAmount = MutableStateFlow("")
    var formProductImages = MutableStateFlow<List<String>>(emptyList())

    // Studio Design Draft State
    val studioDesignDraft = MutableStateFlow(_shopProfile.value.memoDesign)

    fun initStudioDraft() {
        val local = localShopStorage.loadProfile()
        if (local != null && local.memoDesign != MemoDesignConfig()) {
            _shopProfile.value = local
            studioDesignDraft.value = local.memoDesign
        } else {
            studioDesignDraft.value = _shopProfile.value.memoDesign
        }
    }

    fun updateStudioDraft(config: MemoDesignConfig) {
        studioDesignDraft.value = config
    }

    fun saveStudioDesign(
        config: MemoDesignConfig,
        onSuccess: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        studioDesignDraft.value = config
        val updated = _shopProfile.value.copy(memoDesign = config)
        updateShopProfile(updated, onSuccess = onSuccess, onError = onError)
    }

    fun resetStudioDesignToDefault() {
        val defaultPreset = when (_shopProfile.value.shopType) {
            "কাপড়ের দোকান / পোশাক", "ফ্যাশন" -> MemoDesignConfig.PRESET_FASHION
            "মুদি", "মুদি দোকান" -> MemoDesignConfig.PRESET_GROCERY
            "সাধারণ" -> MemoDesignConfig.PRESET_CLASSIC_BW
            else -> MemoDesignConfig.PRESET_SANITARY_ELECTRIC
        }
        studioDesignDraft.value = defaultPreset
    }

    fun addFormProductImage(path: String) {
        val current = formProductImages.value.toMutableList()
        if (current.size < 10) { // allows up to 10 photos
            current.add(path)
            formProductImages.value = current
        }
    }

    fun removeFormProductImage(index: Int) {
        val current = formProductImages.value.toMutableList()
        if (index in current.indices) {
            val removed = current.removeAt(index)
            formProductImages.value = current
        }
    }

    fun clearFormProductImages() {
        formProductImages.value = emptyList()
    }

    // List of memo items: initially 25 items or default 5 items, auto expandable
    var formItems = MutableStateFlow<List<MemoItem>>(
        List(5) { index -> MemoItem(serial = index + 1, quantityStr = "1", unitPriceStr = "") }
    )

    fun startNewMemo() {
        editingMemoId.value = null
        formMemoNumber.value = BengaliUtils.generateNextMemoNumber(_memos.value.size)
        formMemoDate.value = BengaliUtils.getCurrentDateStr()
        formCustomerName.value = ""
        formCustomerPhone.value = ""
        formCustomerAddress.value = ""
        formPaymentType.value = "নগদ"
        formDiscount.value = "0"
        formExtraCharges.value = "0"
        formPaidAmount.value = ""
        formProductImages.value = emptyList()
        formItems.value = List(5) { index -> MemoItem(serial = index + 1, quantityStr = "1", unitPriceStr = "") }
        navigateTo(Screen.NEW_MEMO)
    }

    fun editExistingMemo(memo: Memo) {
        editingMemoId.value = memo.id
        formMemoNumber.value = memo.memoNumber
        formMemoDate.value = memo.memoDate
        formCustomerName.value = memo.customerName
        formCustomerPhone.value = memo.customerPhone
        formCustomerAddress.value = memo.customerAddress
        formPaymentType.value = memo.paymentType
        formDiscount.value = if (memo.discount > 0) BengaliUtils.formatCleanNumber(memo.discount) else "0"
        formExtraCharges.value = if (memo.extraCharges > 0) BengaliUtils.formatCleanNumber(memo.extraCharges) else "0"
        formPaidAmount.value = if (memo.paidAmount > 0) BengaliUtils.formatCleanNumber(memo.paidAmount) else ""
        formProductImages.value = memo.productImages

        val items = if (memo.items.isNotEmpty()) {
            memo.items.map { item ->
                item.copy(
                    quantityStr = if (item.quantityStr.isNotBlank()) item.quantityStr else BengaliUtils.formatCleanNumber(item.quantity),
                    unitPriceStr = if (item.unitPriceStr.isNotBlank()) item.unitPriceStr else (if (item.unitPrice > 0) BengaliUtils.formatCleanNumber(item.unitPrice) else "")
                )
            }
        } else {
            List(5) { index -> MemoItem(serial = index + 1, quantityStr = "1", unitPriceStr = "") }
        }
        formItems.value = items
        navigateTo(Screen.NEW_MEMO)
    }

    fun addFormItemRow() {
        val currentList = formItems.value.toMutableList()
        val nextSerial = currentList.size + 1
        currentList.add(MemoItem(serial = nextSerial))
        formItems.value = currentList
    }

    fun updateFormItem(index: Int, name: String, qty: Double, unit: String, rate: Double) {
        val currentList = formItems.value.toMutableList()
        if (index in currentList.indices) {
            val total = qty * rate
            currentList[index] = currentList[index].copy(
                productName = name,
                quantity = qty,
                quantityStr = BengaliUtils.formatCleanNumber(qty),
                unit = unit,
                unitPrice = rate,
                unitPriceStr = if (rate > 0) BengaliUtils.formatCleanNumber(rate) else "",
                totalPrice = total
            )
            formItems.value = currentList
        }
    }

    fun updateFormItemWithStrings(index: Int, name: String, qtyStr: String, unit: String, rateStr: String) {
        val currentList = formItems.value.toMutableList()
        if (index in currentList.indices) {
            val parsedQty = BengaliUtils.parseNumber(qtyStr)
            val parsedRate = BengaliUtils.parseNumber(rateStr)
            val total = parsedQty * parsedRate
            currentList[index] = currentList[index].copy(
                productName = name,
                quantity = parsedQty,
                quantityStr = qtyStr,
                unit = unit,
                unitPrice = parsedRate,
                unitPriceStr = rateStr,
                totalPrice = total
            )
            formItems.value = currentList
        }
    }

    fun removeFormItem(index: Int) {
        val currentList = formItems.value.toMutableList()
        if (index in currentList.indices && currentList.size > 1) {
            currentList.removeAt(index)
            // Re-index serials
            val reindexed = currentList.mapIndexed { idx, item -> item.copy(serial = idx + 1) }
            formItems.value = reindexed
        }
    }

    fun computeFormSubtotal(): Double {
        return formItems.value.filter { it.productName.isNotBlank() }.sumOf { it.totalPrice }
    }

    fun computeFormGrandTotal(): Double {
        val sub = computeFormSubtotal()
        val disc = formDiscount.value.toDoubleOrNull() ?: 0.0
        val extra = formExtraCharges.value.toDoubleOrNull() ?: 0.0
        return (sub - disc + extra).coerceAtLeast(0.0)
    }

    fun computeFormDue(): Double {
        val grand = computeFormGrandTotal()
        val paid = formPaidAmount.value.toDoubleOrNull() ?: 0.0
        return (grand - paid).coerceAtLeast(0.0)
    }

    fun saveMemo(onComplete: (Memo) -> Unit) {
        val uid = auth.currentUser?.uid ?: return
        viewModelScope.launch {
            val validItems = formItems.value.filter { it.productName.isNotBlank() }
            val effectiveItems = if (validItems.isEmpty()) {
                listOf(MemoItem(serial = 1, productName = "পণ্য", quantity = 1.0, unitPrice = 0.0, totalPrice = 0.0))
            } else {
                validItems
            }

            val subtotal = computeFormSubtotal()
            val discount = formDiscount.value.toDoubleOrNull() ?: 0.0
            val extra = formExtraCharges.value.toDoubleOrNull() ?: 0.0
            val grand = computeFormGrandTotal()
            val paid = formPaidAmount.value.toDoubleOrNull() ?: grand
            val due = (grand - paid).coerceAtLeast(0.0)

            val pageCount = ((effectiveItems.size - 1) / 25 + 1).coerceAtLeast(1)

            val isNew = editingMemoId.value == null
            val memo = Memo(
                id = editingMemoId.value ?: "",
                userId = uid,
                memoNumber = formMemoNumber.value.ifBlank { BengaliUtils.generateNextMemoNumber(_memos.value.size) },
                memoDate = formMemoDate.value.ifBlank { BengaliUtils.getCurrentDateStr() },
                customerName = formCustomerName.value,
                customerPhone = formCustomerPhone.value,
                customerAddress = formCustomerAddress.value,
                paymentType = formPaymentType.value,
                items = effectiveItems,
                subtotal = subtotal,
                discount = discount,
                extraCharges = extra,
                grandTotal = grand,
                paidAmount = paid,
                dueAmount = due,
                shopNameSnapshot = _shopProfile.value.shopName,
                shopOwnerSnapshot = _shopProfile.value.ownerName,
                shopAddressSnapshot = _shopProfile.value.address,
                shopPhoneSnapshot = _shopProfile.value.phone,
                shopLogoSnapshot = _shopProfile.value.logoPath,
                shopPhotoSnapshot = _shopProfile.value.shopPhotoPath,
                memoNoticeSnapshot = _shopProfile.value.memoNotice,
                designConfig = _shopProfile.value.memoDesign,
                productImages = formProductImages.value,
                pageCount = pageCount
            )

            val savedId = repository.saveMemo(memo, isNew = isNew)
            val finalMemo = memo.copy(id = savedId)
            _selectedMemo.value = finalMemo
            onComplete(finalMemo)
        }
    }

    // --- Selected Memo for Detail / Preview ---
    private val _selectedMemo = MutableStateFlow<Memo?>(null)
    val selectedMemo: StateFlow<Memo?> = _selectedMemo.asStateFlow()

    fun selectMemoForDetail(memo: Memo) {
        _selectedMemo.value = memo
        navigateTo(Screen.MEMO_DETAIL)
    }

    fun selectMemoForPdf(memo: Memo) {
        _selectedMemo.value = memo
        navigateTo(Screen.PDF_PREVIEW)
    }

    fun deleteMemo(
        memo: Memo,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank()) {
            _memos.value = _memos.value.filter { it.id != memo.id }
            if (_selectedMemo.value?.id == memo.id) {
                _selectedMemo.value = null
                navigateBack()
            }
            onSuccess()
            return
        }
        viewModelScope.launch {
            try {
                repository.deleteMemo(uid, memo.id)
                _memos.value = _memos.value.filter { it.id != memo.id }
                if (_selectedMemo.value?.id == memo.id) {
                    _selectedMemo.value = null
                    navigateBack()
                }
                onSuccess()
            } catch (e: Exception) {
                Log.e("SmartMemoVM", "Error deleting memo", e)
                onError(e.localizedMessage ?: "মেমো ডিলিট করতে ব্যর্থ হয়েছে")
            }
        }
    }

    fun deleteMultipleMemos(
        memosToDelete: List<Memo>,
        onSuccess: (count: Int) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        if (memosToDelete.isEmpty()) return
        val uid = auth.currentUser?.uid
        val idsToDelete = memosToDelete.map { it.id }.toSet()
        if (uid.isNullOrBlank()) {
            _memos.value = _memos.value.filter { it.id !in idsToDelete }
            onSuccess(memosToDelete.size)
            return
        }
        viewModelScope.launch {
            try {
                repository.deleteMemos(uid, memosToDelete.map { it.id })
                _memos.value = _memos.value.filter { it.id !in idsToDelete }
                onSuccess(memosToDelete.size)
            } catch (e: Exception) {
                Log.e("SmartMemoVM", "Error deleting multiple memos", e)
                onError(e.localizedMessage ?: "মেমোগুলো ডিলিট করতে ব্যর্থ হয়েছে")
            }
        }
    }

    // --- Customer Management ---
    val customerQuery = MutableStateFlow("")

    fun saveCustomer(customer: Customer) {
        val uid = auth.currentUser?.uid ?: return
        viewModelScope.launch {
            repository.saveCustomer(customer.copy(userId = uid))
        }
    }

    // --- Product & Inventory Management ---
    val selectedCategory = MutableStateFlow("সব")
    val productSearchQuery = MutableStateFlow("")

    fun saveProduct(product: Product) {
        val uid = auth.currentUser?.uid ?: return
        viewModelScope.launch {
            repository.saveProduct(product.copy(userId = uid))
        }
    }

    fun deleteProduct(productId: String) {
        val uid = auth.currentUser?.uid ?: return
        viewModelScope.launch {
            repository.deleteProduct(uid, productId)
        }
    }

    // --- Payments & Dues ---
    fun recordDuePayment(memo: Memo?, customerId: String, customerName: String, amount: Double, method: String, note: String) {
        val uid = auth.currentUser?.uid ?: return
        viewModelScope.launch {
            val payment = Payment(
                userId = uid,
                memoId = memo?.id ?: "",
                memoNumber = memo?.memoNumber ?: "",
                customerId = customerId,
                customerName = customerName,
                amount = amount,
                date = BengaliUtils.getCurrentDateStr(),
                paymentMethod = method,
                note = note
            )
            repository.recordPayment(payment)
        }
    }

    // --- Shop Settings ---
    fun updateShopProfile(
        profile: ShopProfile,
        onSuccess: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        try {
            _shopProfile.value = profile
            studioDesignDraft.value = profile.memoDesign
            val localSaved = localShopStorage.saveProfile(profile)
            val uid = auth.currentUser?.uid
            if (uid != null) {
                viewModelScope.launch {
                    try {
                        repository.saveShopProfile(profile.copy(userId = uid))
                        onSuccess?.invoke()
                    } catch (e: Exception) {
                        Log.e("SmartMemoVM", "Firestore save error", e)
                        if (localSaved) {
                            onSuccess?.invoke()
                        } else {
                            onError?.invoke(e.localizedMessage ?: "ডাটাবেজে সংরক্ষণ ব্যর্থ")
                        }
                    }
                }
            } else {
                if (localSaved) {
                    onSuccess?.invoke()
                } else {
                    onError?.invoke("লোকাল সংরক্ষণ ব্যর্থ")
                }
            }
        } catch (e: Exception) {
            Log.e("SmartMemoVM", "Profile update failed", e)
            onError?.invoke(e.localizedMessage ?: "সংরক্ষণ ব্যর্থ হয়েছে")
        }
    }

    // --- Helpers for Date Filtering ---
    private fun isDateInCurrentWeek(dateStr: String): Boolean {
        return try {
            val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
            val date = sdf.parse(dateStr) ?: return false
            val cal = Calendar.getInstance()
            cal.time = date
            val curCal = Calendar.getInstance()
            cal.get(Calendar.WEEK_OF_YEAR) == curCal.get(Calendar.WEEK_OF_YEAR) &&
            cal.get(Calendar.YEAR) == curCal.get(Calendar.YEAR)
        } catch (e: Exception) {
            false
        }
    }

    private fun isDateInCurrentMonth(dateStr: String): Boolean {
        return try {
            val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
            val date = sdf.parse(dateStr) ?: return false
            val cal = Calendar.getInstance()
            cal.time = date
            val curCal = Calendar.getInstance()
            cal.get(Calendar.MONTH) == curCal.get(Calendar.MONTH) &&
            cal.get(Calendar.YEAR) == curCal.get(Calendar.YEAR)
        } catch (e: Exception) {
            false
        }
    }

    private fun isDateInCurrentYear(dateStr: String): Boolean {
        return try {
            val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
            val date = sdf.parse(dateStr) ?: return false
            val cal = Calendar.getInstance()
            cal.time = date
            val curCal = Calendar.getInstance()
            cal.get(Calendar.YEAR) == curCal.get(Calendar.YEAR)
        } catch (e: Exception) {
            false
        }
    }

    fun isMemoOlderThanDays(dateStr: String, days: Int): Boolean {
        return try {
            val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
            val date = sdf.parse(dateStr) ?: return false
            val diff = System.currentTimeMillis() - date.time
            val diffDays = diff / (1000L * 60 * 60 * 24)
            diffDays >= days
        } catch (_: Exception) {
            false
        }
    }
}

