package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.ui.components.AppHeader
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel
import com.example.util.BengaliUtils
import java.util.Locale

@Composable
fun CustomerScreen(
    viewModel: SmartMemoViewModel
) {
    val context = LocalContext.current
    val shopProfile by viewModel.shopProfile.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val allMemos by viewModel.memos.collectAsState()
    val customerQuery by viewModel.customerQuery.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedCustomerForDuePay by remember { mutableStateOf<Customer?>(null) }
    var viewingCustomerHistory by remember { mutableStateOf<Customer?>(null) }

    val filteredCustomers = customers.filter {
        val q = customerQuery.trim().lowercase(Locale.ROOT)
        if (q.isBlank()) true else {
            it.name.lowercase(Locale.ROOT).contains(q) || it.phone.contains(q)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("customer_screen")
    ) {
        AppHeader(
            title = "গ্রাহক ব্যবস্থাপনা",
            shopProfile = shopProfile,
            showBackButton = true,
            onBackClick = { viewModel.navigateBack() },
            onSettingsClick = { viewModel.navigateTo(Screen.SHOP_SETTINGS) }
        )

        // Top bar with search and Add button
        Surface(
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = customerQuery,
                    onValueChange = { viewModel.customerQuery.value = it },
                    placeholder = { Text("নাম বা ফোন নম্বর দিয়ে খুঁজুন...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SmartTealPrimary) },
                    trailingIcon = {
                        if (customerQuery.isNotBlank()) {
                            IconButton(onClick = { viewModel.customerQuery.value = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = null)
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("customer_search_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                    modifier = Modifier.testTag("add_customer_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("নতুন গ্রাহক", fontSize = 12.5.sp)
                }
            }
        }

        // Customer Count & Total Due Summary
        Surface(
            color = Color(0xFFE2E8F0),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "মোট গ্রাহক: ${filteredCustomers.size} জন",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = SmartNavyPrimary
                )
                val totalDue = filteredCustomers.sumOf { it.totalDue }
                Text(
                    text = "মোট বাকি: ${BengaliUtils.formatTaka(totalDue)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFDC2626)
                )
            }
        }

        if (filteredCustomers.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.People,
                    contentDescription = null,
                    tint = Color(0xFFCBD5E1),
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "কোনো গ্রাহক পাওয়া যায়নি",
                    fontSize = 15.sp,
                    color = Color(0xFF64748B)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredCustomers) { customer ->
                    CustomerCard(
                        customer = customer,
                        onClick = { viewingCustomerHistory = customer },
                        onPayDueClick = { selectedCustomerForDuePay = customer }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }

    // Add Customer Dialog
    if (showAddDialog) {
        var newName by remember { mutableStateOf("") }
        var newPhone by remember { mutableStateOf("") }
        var newAddress by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("নতুন গ্রাহক যোগ করুন", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("গ্রাহকের নাম *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("new_customer_name_input")
                    )
                    OutlinedTextField(
                        value = newPhone,
                        onValueChange = { newPhone = it },
                        label = { Text("মোবাইল নম্বর *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("new_customer_phone_input")
                    )
                    OutlinedTextField(
                        value = newAddress,
                        onValueChange = { newAddress = it },
                        label = { Text("ঠিকানা") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newName.isNotBlank() && newPhone.isNotBlank()) {
                            viewModel.saveCustomer(
                                Customer(
                                    name = newName.trim(),
                                    phone = newPhone.trim(),
                                    address = newAddress.trim()
                                )
                            )
                            showAddDialog = false
                            Toast.makeText(context, "গ্রাহক সফলভাবে যোগ হয়েছে!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "দয়া করে নাম এবং মোবাইল নম্বর দিন", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary)
                ) {
                    Text("সংরক্ষণ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Due Payment Dialog
    if (selectedCustomerForDuePay != null) {
        val cust = selectedCustomerForDuePay!!
        var payAmountStr by remember { mutableStateOf("") }
        var payNote by remember { mutableStateOf("বাকি আদায়") }
        var payMethod by remember { mutableStateOf("নগদ") }

        AlertDialog(
            onDismissRequest = { selectedCustomerForDuePay = null },
            title = { Text("বাকি টাকা জমা নিন", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("গ্রাহক: ${cust.name} (${cust.phone})", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("বর্তমান মোট বাকি: ${BengaliUtils.formatTaka(cust.totalDue)}", fontSize = 13.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = payAmountStr,
                        onValueChange = { payAmountStr = it },
                        label = { Text("জমার পরিমাণ (৳) *") },
                        placeholder = { Text(cust.totalDue.toString()) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("payment_amount_input")
                    )

                    OutlinedTextField(
                        value = payNote,
                        onValueChange = { payNote = it },
                        label = { Text("বিবরণ / নোট") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = BengaliUtils.parseNumber(payAmountStr)
                        if (amount > 0) {
                            viewModel.recordDuePayment(
                                memo = null,
                                customerId = cust.id,
                                customerName = cust.name,
                                amount = amount,
                                method = payMethod,
                                note = payNote
                            )
                            selectedCustomerForDuePay = null
                            Toast.makeText(context, "টাকা জমা সফলভাবে সম্পন্ন হয়েছে!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "সঠিক টাকার পরিমাণ দিন", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary)
                ) {
                    Text("জমা নিন")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedCustomerForDuePay = null }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Customer Memo History Dialog
    if (viewingCustomerHistory != null) {
        val cust = viewingCustomerHistory!!
        val customerMemos = allMemos.filter {
            it.customerPhone == cust.phone || (cust.phone.isBlank() && it.customerName == cust.name)
        }

        AlertDialog(
            onDismissRequest = { viewingCustomerHistory = null },
            title = { Text("${cust.name}-এর মেমোসমূহ", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.height(300.dp)) {
                    Text("ফোন: ${cust.phone} | মোট কেনাকাটা: ${BengaliUtils.formatTaka(cust.totalPurchases)}", fontSize = 12.sp, color = Color(0xFF64748B))
                    Spacer(modifier = Modifier.height(8.dp))

                    if (customerMemos.isEmpty()) {
                        Text("এই গ্রাহকের নামে কোনো সংরক্ষিত মেমো নেই।", fontSize = 13.sp)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(customerMemos) { m ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewingCustomerHistory = null
                                            viewModel.selectMemoForDetail(m)
                                        },
                                    color = Color(0xFFF8FAFC),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(m.memoNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SmartNavyPrimary)
                                            Text(m.memoDate, fontSize = 11.sp, color = Color(0xFF64748B))
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(BengaliUtils.formatTaka(m.grandTotal), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            if (m.dueAmount > 0) {
                                                Text("বাকি: ${BengaliUtils.formatTaka(m.dueAmount)}", fontSize = 11.sp, color = Color(0xFFDC2626))
                                            } else {
                                                Text("পরিশোধিত", fontSize = 11.sp, color = Color(0xFF16A34A))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { viewingCustomerHistory = null }) {
                    Text("বন্ধ করুন")
                }
            }
        )
    }
}

@Composable
private fun CustomerCard(
    customer: Customer,
    onClick: () -> Unit,
    onPayDueClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF3E8FF)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = Color(0xFF9333EA),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = customer.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "☎ ${customer.phone}",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                    if (customer.address.isNotBlank()) {
                        Text(
                            text = customer.address,
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "মোট বাকি",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = BengaliUtils.formatTaka(customer.totalDue),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (customer.totalDue > 0) Color(0xFFDC2626) else Color(0xFF16A34A)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "মোট কেনাকাটা: ${BengaliUtils.formatTaka(customer.totalPurchases)}",
                    fontSize = 11.5.sp,
                    color = Color(0xFF475569)
                )

                if (customer.totalDue > 0) {
                    Button(
                        onClick = onPayDueClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("টাকা জমা নিন", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
