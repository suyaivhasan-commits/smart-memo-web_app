package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.components.AppHeader
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel
import com.example.util.BengaliUtils
import java.util.Locale

@Composable
fun ProductScreen(
    viewModel: SmartMemoViewModel
) {
    val context = LocalContext.current
    val shopProfile by viewModel.shopProfile.collectAsState()
    val products by viewModel.products.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val productSearchQuery by viewModel.productSearchQuery.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var productToDelete by remember { mutableStateOf<Product?>(null) }

    val categories = listOf("সব", "ইলেকট্রিক", "স্যানিটারি", "মুদি", "পোশাক", "হার্ডওয়্যার", "অন্যান্য")

    val filteredProducts = products.filter { p ->
        val matchesCategory = if (selectedCategory == "সব") true else p.category == selectedCategory
        val q = productSearchQuery.trim().lowercase(Locale.ROOT)
        val matchesSearch = if (q.isBlank()) true else {
            p.name.lowercase(Locale.ROOT).contains(q) || p.code.lowercase(Locale.ROOT).contains(q)
        }
        matchesCategory && matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("product_screen")
    ) {
        AppHeader(
            title = "পণ্য ও স্টক ব্যবস্থাপনা",
            shopProfile = shopProfile,
            showBackButton = true,
            onBackClick = { viewModel.navigateBack() },
            onSettingsClick = { viewModel.navigateTo(Screen.SHOP_SETTINGS) }
        )

        // Top Filter & Search Section
        Surface(
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = productSearchQuery,
                        onValueChange = { viewModel.productSearchQuery.value = it },
                        placeholder = { Text("পণ্যের নাম বা কোড খুঁজুন...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SmartTealPrimary) },
                        trailingIcon = {
                            if (productSearchQuery.isNotBlank()) {
                                IconButton(onClick = { viewModel.productSearchQuery.value = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = null)
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("product_search_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    Button(
                        onClick = {
                            editingProduct = null
                            showAddEditDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                        modifier = Modifier.testTag("add_product_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("নতুন পণ্য", fontSize = 12.5.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Category Chips
                val scrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val isSelected = (selectedCategory == cat)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) SmartNavyPrimary else Color(0xFFF1F5F9),
                            modifier = Modifier
                                .clickable { viewModel.selectedCategory.value = cat }
                                .padding(vertical = 2.dp)
                        ) {
                            Text(
                                text = cat,
                                fontSize = 11.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else Color(0xFF334155),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        }

        // Count Banner
        Surface(
            color = Color(0xFFE2E8F0),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "মোট পণ্য: ${filteredProducts.size} টি",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = SmartNavyPrimary
                )
                val totalStockVal = filteredProducts.sumOf { it.stock * it.salePrice }
                Text(
                    text = "মোট স্টক মূল্য: ${BengaliUtils.formatTaka(totalStockVal)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = SmartTealPrimary
                )
            }
        }

        if (filteredProducts.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Inventory2,
                    contentDescription = null,
                    tint = Color(0xFFCBD5E1),
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "কোনো পণ্য পাওয়া যায়নি",
                    fontSize = 15.sp,
                    color = Color(0xFF64748B)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredProducts) { product ->
                    ProductCard(
                        product = product,
                        onEdit = {
                            editingProduct = product
                            showAddEditDialog = true
                        },
                        onDelete = { productToDelete = product }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }

    // Add / Edit Product Dialog
    if (showAddEditDialog) {
        var name by remember { mutableStateOf(editingProduct?.name ?: "") }
        var category by remember { mutableStateOf(editingProduct?.category ?: "অন্যান্য") }
        var unit by remember { mutableStateOf(editingProduct?.unit ?: "পিস") }
        var salePriceStr by remember { mutableStateOf(if (editingProduct != null) editingProduct!!.salePrice.toString() else "") }
        var purchasePriceStr by remember { mutableStateOf(if (editingProduct != null && editingProduct!!.purchasePrice > 0) editingProduct!!.purchasePrice.toString() else "") }
        var stockStr by remember { mutableStateOf(if (editingProduct != null) editingProduct!!.stock.toString() else "10") }
        var code by remember { mutableStateOf(editingProduct?.code ?: "") }

        val unitOptions = listOf("পিস", "মিটার", "ফুট", "কেজি", "লিটার", "প্যাকেট", "ডজন", "সেট", "বক্স")

        AlertDialog(
            onDismissRequest = { showAddEditDialog = false },
            title = {
                Text(
                    text = if (editingProduct != null) "পণ্য সম্পাদনা" else "নতুন পণ্য যোগ",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("পণ্যের নাম *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("product_name_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = { category = it },
                            label = { Text("ক্যাটাগরি") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = { Text("একক (পিস/মিটার)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = salePriceStr,
                            onValueChange = { salePriceStr = it },
                            label = { Text("বিক্রয় মূল্য (৳) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("product_sale_price_input")
                        )
                        OutlinedTextField(
                            value = purchasePriceStr,
                            onValueChange = { purchasePriceStr = it },
                            label = { Text("ক্রয় মূল্য (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = stockStr,
                            onValueChange = { stockStr = it },
                            label = { Text("বর্তমান স্টক") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("product_stock_input")
                        )
                        OutlinedTextField(
                            value = code,
                            onValueChange = { code = it },
                            label = { Text("পণ্য কোড") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val sp = BengaliUtils.parseNumber(salePriceStr)
                        val pp = BengaliUtils.parseNumber(purchasePriceStr)
                        val st = BengaliUtils.parseNumber(stockStr)
                        if (name.isNotBlank() && sp > 0) {
                            val prod = Product(
                                id = editingProduct?.id ?: "",
                                name = name.trim(),
                                category = category.trim(),
                                unit = unit.trim(),
                                salePrice = sp,
                                purchasePrice = pp,
                                stock = st,
                                code = code.trim()
                            )
                            viewModel.saveProduct(prod)
                            showAddEditDialog = false
                            Toast.makeText(context, "পণ্য সফলভাবে সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "দয়া করে পণ্যের নাম এবং বিক্রয়মূল্য দিন", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary)
                ) {
                    Text("সংরক্ষণ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddEditDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Delete Product Dialog
    if (productToDelete != null) {
        val prod = productToDelete!!
        AlertDialog(
            onDismissRequest = { productToDelete = null },
            title = { Text("পণ্য মুছে ফেলা নিশ্চিত করুন") },
            text = { Text("আপনি কি নিশ্চিত যে '${prod.name}' পণ্যটি তালিকা থেকে মুছে ফেলতে চান?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteProduct(prod.id)
                        productToDelete = null
                        Toast.makeText(context, "পণ্যটি মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("মুছে ফেলুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { productToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
private fun ProductCard(
    product: Product,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFEDD5)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Inventory2,
                    contentDescription = null,
                    tint = Color(0xFFEA580C),
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.name,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Text(
                    text = "${product.category} | একক: ${product.unit}",
                    fontSize = 11.5.sp,
                    color = Color(0xFF64748B)
                )

                // Stock Badge
                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isLowStock = product.stock <= 5
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (isLowStock) Color(0xFFFEE2E2) else Color(0xFFDCFCE7)
                    ) {
                        Text(
                            text = if (isLowStock) "স্বল্প স্টক: ${product.stock} ${product.unit}" else "স্টক: ${product.stock} ${product.unit}",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isLowStock) Color(0xFFDC2626) else Color(0xFF16A34A),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = BengaliUtils.formatTaka(product.salePrice),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = SmartNavyPrimary
                )
                if (product.purchasePrice > 0) {
                    Text(
                        text = "ক্রয়: ${BengaliUtils.formatTaka(product.purchasePrice)}",
                        fontSize = 10.5.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                Row(modifier = Modifier.padding(top = 4.dp)) {
                    IconButton(onClick = onEdit, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "সম্পাদনা", tint = SmartTealPrimary, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
