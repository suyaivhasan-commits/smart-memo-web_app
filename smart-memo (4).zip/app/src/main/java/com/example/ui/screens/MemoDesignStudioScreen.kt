package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.example.data.model.Memo
import com.example.data.model.MemoDesignConfig
import com.example.data.model.MemoItem
import com.example.ui.components.MemoPaperView
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.SmartMemoViewModel
import com.example.util.ImageStorageHelper
import java.io.File

@Composable
fun MemoDesignStudioScreen(
    viewModel: SmartMemoViewModel
) {
    val context = LocalContext.current
    val currentProfile by viewModel.shopProfile.collectAsState()
    val studioDraft by viewModel.studioDesignDraft.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.initStudioDraft()
    }

    BackHandler {
        viewModel.navigateBack()
    }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showLivePreviewModal by remember { mutableStateOf(false) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val savedPath = ImageStorageHelper.saveUriToInternalStorage(context, uri, "memo_studio_img")
            if (savedPath != null) {
                if (studioDraft.studioImagePath.isNotBlank() && studioDraft.studioImagePath != savedPath) {
                    ImageStorageHelper.deleteFile(studioDraft.studioImagePath)
                }
                viewModel.updateStudioDraft(
                    studioDraft.copy(
                        studioImagePath = savedPath,
                        showStudioImage = true
                    )
                )
                Toast.makeText(context, "ছবি সফলভাবে যুক্ত হয়েছে!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "ছবি সংরক্ষণ করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("memo_design_studio_screen")
    ) {
        // App Header
        Surface(
            color = SmartNavyPrimary,
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "ফিরে যান",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "মেমো ডিজাইন স্টুডিও",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "দোকানের ব্র্যান্ডিং, রং, লোগো ও মেমো স্টাইল নিয়ন্ত্রণ",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 11.5.sp
                    )
                }
                // Live preview quick toggle button
                IconButton(
                    onClick = { showLivePreviewModal = !showLivePreviewModal }
                ) {
                    Icon(
                        Icons.Default.Visibility,
                        contentDescription = "প্রিভিউ",
                        tint = if (showLivePreviewModal) SmartTealPrimary else Color.White
                    )
                }
            }
        }

        // 3 Tabs: ডিজাইন (Presets), রং (Colors), লেআউট (Layout)
        TabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = Color.White,
            contentColor = SmartNavyPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = SmartTealPrimary,
                    height = 3.dp
                )
            }
        ) {
            val tabs = listOf(
                "ডিজাইন" to Icons.Default.Style,
                "রং" to Icons.Default.Palette,
                "ছবি ও ব্যানার" to Icons.Default.Image,
                "লেআউট" to Icons.Default.Tune
            )
            tabs.forEachIndexed { index, (title, icon) ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = title,
                                fontSize = 13.sp,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Preview Card if toggled or at top
            if (showLivePreviewModal) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "লাইভ মেমো প্রিভিউ",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = SmartNavyPrimary
                                )
                                TextButton(onClick = { showLivePreviewModal = false }) {
                                    Text("লুকান", color = SmartTealPrimary, fontSize = 12.sp)
                                }
                            }
                            // Sample memo for preview
                            val sampleMemo = remember(studioDraft, currentProfile) {
                                Memo(
                                    memoNumber = "#0001",
                                    memoDate = "২৬-১০-২০২৬",
                                    customerName = "রাহিম মিয়া",
                                    customerPhone = "০১৭১২-২২৩৪৫৬",
                                    customerAddress = "ঢাকা, বাংলাদেশ",
                                    shopNameSnapshot = currentProfile.shopName,
                                    shopOwnerSnapshot = currentProfile.ownerName,
                                    shopAddressSnapshot = currentProfile.address,
                                    shopPhoneSnapshot = currentProfile.phone,
                                    shopLogoSnapshot = currentProfile.logoPath,
                                    shopPhotoSnapshot = currentProfile.shopPhotoPath,
                                    items = listOf(
                                        MemoItem(serial = 1, productName = "LED বাল্ব", quantity = 10.0, unit = "পিস", unitPrice = 50.0, totalPrice = 500.0, quantityStr = "১০", unitPriceStr = "৫০"),
                                        MemoItem(serial = 2, productName = "সুইচ", quantity = 5.0, unit = "পিস", unitPrice = 80.0, totalPrice = 400.0, quantityStr = "৫", unitPriceStr = "৮০"),
                                        MemoItem(serial = 3, productName = "পাইপ", quantity = 10.0, unit = "ফুট", unitPrice = 30.0, totalPrice = 300.0, quantityStr = "১০", unitPriceStr = "৩০")
                                    ),
                                    subtotal = 1200.0,
                                    discount = 50.0,
                                    grandTotal = 1150.0,
                                    paidAmount = 500.0,
                                    dueAmount = 650.0,
                                    designConfig = studioDraft
                                )
                            }
                            MemoPaperView(
                                memo = sampleMemo,
                                shopProfile = currentProfile.copy(memoDesign = studioDraft)
                            )
                        }
                    }
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> {
                    // TAB 1: DESIGN PRESETS (Section 6 from Infographic)
                    item {
                        Text(
                            text = "বিল্ট-ইন মেমো ডিজাইন প্রিসেট",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = SmartNavyPrimary
                        )
                        Text(
                            text = "আপনার দোকানের ধরন অনুযায়ী এক ক্লিকেই আকর্ষণীয় ডিজাইন বেছে নিন:",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    }

                    // 4 Preset Cards
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Preset 1: Fashion / Clothes
                            PresetCard(
                                title = "ডিজাইন - ১ (ফ্যাশন / কাপড়ের দোকান)",
                                subtitle = "আকর্ষণীয় ম্যাজেন্টা-রোজ হেডার, বুটিক ও পোশাকের দোকানের জন্য উপযুক্ত",
                                primaryColor = Color(0xFF881337),
                                secondaryColor = Color(0xFFBE185D),
                                isSelected = studioDraft.presetId == "PRESET_FASHION",
                                onClick = {
                                    viewModel.updateStudioDraft(
                                        MemoDesignConfig.PRESET_FASHION.copy(
                                            studioImagePath = studioDraft.studioImagePath,
                                            showStudioImage = studioDraft.showStudioImage,
                                            studioImagePosition = studioDraft.studioImagePosition,
                                            studioImageSize = studioDraft.studioImageSize,
                                            studioImagePadding = studioDraft.studioImagePadding
                                        )
                                    )
                                }
                            )

                            // Preset 2: Grocery
                            PresetCard(
                                title = "ডিজাইন - ২ (মুদি দোকান)",
                                subtitle = "ফ্রেশ এমারেল্ড গ্রিন আভা, জেনারেল স্টোর ও মুদি সামগ্রীর জন্য মানানসই",
                                primaryColor = Color(0xFF14532D),
                                secondaryColor = Color(0xFF16A34A),
                                isSelected = studioDraft.presetId == "PRESET_GROCERY",
                                onClick = {
                                    viewModel.updateStudioDraft(
                                        MemoDesignConfig.PRESET_GROCERY.copy(
                                            studioImagePath = studioDraft.studioImagePath,
                                            showStudioImage = studioDraft.showStudioImage,
                                            studioImagePosition = studioDraft.studioImagePosition,
                                            studioImageSize = studioDraft.studioImageSize,
                                            studioImagePadding = studioDraft.studioImagePadding
                                        )
                                    )
                                }
                            )

                            // Preset 3: Electric & Sanitary
                            PresetCard(
                                title = "ডিজাইন - ৩ (স্যানিটারি ও ইলেকট্রিক)",
                                subtitle = "ডিপ নেভি ব্লু ও ভাইব্রেন্ট টিল কম্বিনেশন, পেশাদার হার্ডওয়্যার ও ইলেকট্রিক লুক",
                                primaryColor = Color(0xFF0F2B48),
                                secondaryColor = Color(0xFF00897B),
                                isSelected = studioDraft.presetId == "PRESET_SANITARY_ELECTRIC",
                                onClick = {
                                    viewModel.updateStudioDraft(
                                        MemoDesignConfig.PRESET_SANITARY_ELECTRIC.copy(
                                            studioImagePath = studioDraft.studioImagePath,
                                            showStudioImage = studioDraft.showStudioImage,
                                            studioImagePosition = studioDraft.studioImagePosition,
                                            studioImageSize = studioDraft.studioImageSize,
                                            studioImagePadding = studioDraft.studioImagePadding
                                        )
                                    )
                                }
                            )

                            // Preset 4: Classic Black & White
                            PresetCard(
                                title = "ডিজাইন - ৪ (সাধারণ / ব্ল্যাক & হোয়াইট)",
                                subtitle = "অফিসিয়াল ক্লাসিক মনোক্রোম, সবচেয়ে দ্রুত ও সাশ্রয়ী কালির প্রিন্টিং",
                                primaryColor = Color(0xFF111827),
                                secondaryColor = Color(0xFF374151),
                                isSelected = studioDraft.presetId == "PRESET_CLASSIC_BW",
                                onClick = {
                                    viewModel.updateStudioDraft(
                                        MemoDesignConfig.PRESET_CLASSIC_BW.copy(
                                            studioImagePath = studioDraft.studioImagePath,
                                            showStudioImage = studioDraft.showStudioImage,
                                            studioImagePosition = studioDraft.studioImagePosition,
                                            studioImageSize = studioDraft.studioImageSize,
                                            studioImagePadding = studioDraft.studioImagePadding
                                        )
                                    )
                                }
                            )
                        }
                    }
                }

                1 -> {
                    // TAB 2: COLORS
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Text(
                                    text = "রং নির্বাচন (কালার প্যালেট)",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SmartNavyPrimary
                                )

                                Text(
                                    text = "দ্রুত পছন্দের রঙের সমন্বয় বেছে নিন:",
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B)
                                )

                                val palettes = listOf(
                                    ColorPaletteOption("নীল ও টিল", "#0F2B48", "#00897B", "#E0F2F1", "#334155"),
                                    ColorPaletteOption("পান্না সবুজ", "#14532D", "#16A34A", "#DCFCE7", "#15803D"),
                                    ColorPaletteOption("রোজ ও ম্যাজেন্টা", "#881337", "#BE185D", "#FCE7F3", "#9D174D"),
                                    ColorPaletteOption("ক্লাসিক সাদাকালো", "#111827", "#374151", "#F3F4F6", "#111827"),
                                    ColorPaletteOption("রয়্যাল বেগুনি", "#4C1D95", "#7C3AED", "#EDE9FE", "#6D28D9"),
                                    ColorPaletteOption("অ্যাম্বার ও কমলা", "#78350F", "#D97706", "#FEF3C7", "#B45309")
                                )

                                palettes.forEach { p ->
                                    val isCurrent = studioDraft.primaryColorHex == p.primary &&
                                            studioDraft.secondaryColorHex == p.secondary

                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.updateStudioDraft(
                                                    studioDraft.copy(
                                                        primaryColorHex = p.primary,
                                                        secondaryColorHex = p.secondary,
                                                        tableHeaderBgHex = p.tableHeaderBg,
                                                        tableLineColorHex = p.tableLine
                                                    )
                                                )
                                            },
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isCurrent) Color(0xFFF1F5F9) else Color.White,
                                        border = androidx.compose.foundation.BorderStroke(
                                            if (isCurrent) 2.dp else 1.dp,
                                            if (isCurrent) SmartTealPrimary else Color(0xFFE2E8F0)
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Color Swatches
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .background(parseHexColor(p.primary), CircleShape)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .background(parseHexColor(p.secondary), CircleShape)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .background(parseHexColor(p.tableHeaderBg), CircleShape)
                                                    .border(1.dp, Color(0xFFCBD5E1), CircleShape)
                                            )

                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(
                                                text = p.name,
                                                fontSize = 13.5.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFF0F172A),
                                                modifier = Modifier.weight(1f)
                                            )

                                            if (isCurrent) {
                                                Icon(
                                                    Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = SmartTealPrimary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // TAB 3: STUDIO PHOTO & BANNER
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(SmartTealPrimary.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Image,
                                            contentDescription = null,
                                            tint = SmartTealPrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "মেমোর জন্য ছবি ও ব্যানার",
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SmartNavyPrimary
                                        )
                                        Text(
                                            text = "গ্যালারি থেকে ছবি যোগ করুন। এটি পরবর্তী সব মেমোতে স্বয়ংক্রিয়ভাবে দৃশ্যমান থাকবে।",
                                            fontSize = 11.5.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }

                                val hasStudioImg = studioDraft.studioImagePath.isNotBlank() && File(studioDraft.studioImagePath).exists()

                                if (hasStudioImg) {
                                    // Preview Card
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFFF8FAFC), RoundedCornerShape(12.dp))
                                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                                            .padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "বর্তমান মেমো ছবি প্রিভিউ:",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = SmartNavyPrimary,
                                            modifier = Modifier.align(Alignment.Start)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        AsyncImage(
                                            model = File(studioDraft.studioImagePath),
                                            contentDescription = "মেমো ব্যানার ছবি",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(130.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .border(1.dp, SmartTealPrimary.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                                            contentScale = ContentScale.Fit
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Action buttons: Change / Delete
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = {
                                                    photoPickerLauncher.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                },
                                                modifier = Modifier.weight(1f).height(42.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("ছবি পরিবর্তন", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    ImageStorageHelper.deleteFile(studioDraft.studioImagePath)
                                                    viewModel.updateStudioDraft(
                                                        studioDraft.copy(
                                                            studioImagePath = "",
                                                            showStudioImage = false
                                                        )
                                                    )
                                                    Toast.makeText(context, "ছবিটি মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
                                                },
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                                                modifier = Modifier.weight(1f).height(42.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("ছবি মুছুন", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                            }
                                        }
                                    }

                                    // Switch Toggle: Show on Memo
                                    SwitchRow(
                                        label = "মেমোতে ছবি প্রদর্শন সক্রিয় রাখুন",
                                        description = "সক্রিয় থাকলে মেমো পেপারে ও প্রিন্টে এই ছবি দৃশ্যমান থাকবে",
                                        checked = studioDraft.showStudioImage,
                                        onCheckedChange = {
                                            viewModel.updateStudioDraft(studioDraft.copy(showStudioImage = it))
                                        }
                                    )

                                    Divider(color = Color(0xFFE2E8F0))

                                    // Position Selector
                                    Text(
                                        text = "মেমোতে ছবির অবস্থান (Position):",
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SmartNavyPrimary
                                    )
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf(
                                            "TOP_BANNER" to "মেমোর শীর্ষে ব্যানার (হেডারের নিচে)",
                                            "BELOW_TABLE" to "পণ্য টেবিলের নিচে (শোকেস)",
                                            "BESIDE_TOTALS" to "টোটাল হিসাবের পাশে (নিচে)"
                                        ).forEach { (pos, label) ->
                                            val isSel = studioDraft.studioImagePosition == pos
                                            Button(
                                                onClick = {
                                                    viewModel.updateStudioDraft(studioDraft.copy(studioImagePosition = pos))
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = if (isSel) SmartNavyPrimary else Color(0xFFF1F5F9),
                                                    contentColor = if (isSel) Color.White else Color(0xFF334155)
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.fillMaxWidth().height(38.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(label, fontSize = 12.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                                                    if (isSel) {
                                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    Divider(color = Color(0xFFE2E8F0))

                                    // Size Selector
                                    Text(
                                        text = "ছবির আকার (Size):",
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SmartNavyPrimary
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf(
                                            "SMALL" to "ছোট",
                                            "MEDIUM" to "মাঝারি",
                                            "LARGE" to "বড়"
                                        ).forEach { (sz, label) ->
                                            val isSel = studioDraft.studioImageSize == sz
                                            Button(
                                                onClick = {
                                                    viewModel.updateStudioDraft(studioDraft.copy(studioImageSize = sz))
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = if (isSel) SmartNavyPrimary else Color(0xFFF1F5F9),
                                                    contentColor = if (isSel) Color.White else Color(0xFF334155)
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f).height(38.dp)
                                            ) {
                                                Text(label, fontSize = 12.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                                            }
                                        }
                                    }

                                    Divider(color = Color(0xFFE2E8F0))

                                    // Margin / Padding Selector
                                    Text(
                                        text = "ছবির চারপাশে ফাঁকা জায়গা (Padding):",
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SmartNavyPrimary
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf(
                                            "COMPACT" to "কম",
                                            "NORMAL" to "সাধারণ",
                                            "SPACIOUS" to "বেশি"
                                        ).forEach { (pad, label) ->
                                            val isSel = studioDraft.studioImagePadding == pad
                                            Button(
                                                onClick = {
                                                    viewModel.updateStudioDraft(studioDraft.copy(studioImagePadding = pad))
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = if (isSel) SmartNavyPrimary else Color(0xFFF1F5F9),
                                                    contentColor = if (isSel) Color.White else Color(0xFF334155)
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f).height(38.dp)
                                            ) {
                                                Text(label, fontSize = 12.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                                            }
                                        }
                                    }
                                } else {
                                    // Empty state upload card
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFFF8FAFC), RoundedCornerShape(12.dp))
                                            .border(1.2.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp))
                                            .padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(60.dp)
                                                .clip(CircleShape)
                                                .background(SmartTealPrimary.copy(alpha = 0.1f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.Image,
                                                contentDescription = null,
                                                tint = SmartTealPrimary,
                                                modifier = Modifier.size(32.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Text(
                                            text = "মেমোর জন্য ছবি বা ব্যানার যোগ করুন",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SmartNavyPrimary,
                                            textAlign = TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "দোকানের ব্যানার, পণ্যের ছবি বা ব্র্যান্ড ইমেজ নির্বাচন করুন। একবার সংরক্ষণ করলে পরবর্তী সব মেমোতে স্বয়ংক্রিয়ভাবে দেখাবে।",
                                            fontSize = 12.sp,
                                            color = Color(0xFF64748B),
                                            textAlign = TextAlign.Center,
                                            lineHeight = 18.sp
                                        )
                                        Spacer(modifier = Modifier.height(14.dp))
                                        Button(
                                            onClick = {
                                                photoPickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth().height(44.dp)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("গ্যালারি থেকে ছবি নির্বাচন করুন", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                    }
                                }

                                // Helpful Instructions box
                                Surface(
                                    color = Color(0xFFF1F5F9),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("💡 ছবি সংরক্ষণের বিশেষ সুবিধা:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SmartNavyPrimary)
                                        Text("• নির্বাচিত ছবিটি অ্যাপের নিজস্ব স্টোরেজে স্থায়ীভাবে সংরক্ষিত থাকে।", fontSize = 11.sp, color = Color(0xFF475569))
                                        Text("• সংরক্ষণ করলে প্রতিটি নতুন মেমোতে এই ছবিটি স্বয়ংক্রিয়ভাবে প্রদর্শিত হবে।", fontSize = 11.sp, color = Color(0xFF475569))
                                        Text("• মেমো তৈরির সময় প্রতিবার আলাদাভাবে ছবি যুক্ত করার প্রয়োজন নেই।", fontSize = 11.sp, color = Color(0xFF475569))
                                        Text("• PDF ডাউনলোড ও প্রিন্টেও ছবিটি অক্ষুণ্ণ কোয়ালিটিতে দৃশ্যমান থাকবে।", fontSize = 11.sp, color = Color(0xFF475569))
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // TAB 4: LAYOUT & TOGGLES
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = "লেআউট ও উপাদান নিয়ন্ত্রণ",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SmartNavyPrimary
                                )

                                // Toggle 1: Show Logo
                                SwitchRow(
                                    label = "লোগো যোগ করুন",
                                    description = "মেমোর শীর্ষভাগে দোকানের লোগো দৃশ্যমান থাকবে",
                                    checked = studioDraft.showLogo,
                                    onCheckedChange = {
                                        viewModel.updateStudioDraft(studioDraft.copy(showLogo = it))
                                    }
                                )

                                // Toggle 2: Show Shop Photo
                                SwitchRow(
                                    label = "দোকানের ছবি যোগ করুন",
                                    description = "মেমোর কোণায় বা ব্যানারে দোকানের আউটলেট ছবি দেখাবে",
                                    checked = studioDraft.showShopPhoto,
                                    onCheckedChange = {
                                        viewModel.updateStudioDraft(studioDraft.copy(showShopPhoto = it))
                                    }
                                )

                                // Toggle 3: Show Product Photos
                                SwitchRow(
                                    label = "পণ্যের ছবি যোগ করুন",
                                    description = "মেমোতে যুক্ত করা পণ্যের ছবি প্রদর্শন সক্রিয় থাকবে",
                                    checked = studioDraft.showProductImages,
                                    onCheckedChange = {
                                        viewModel.updateStudioDraft(studioDraft.copy(showProductImages = it))
                                    }
                                )

                                Divider(color = Color(0xFFE2E8F0))

                                // Logo Position Selector
                                Text(
                                    text = "লোগোর অবস্থান:",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SmartNavyPrimary
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("LEFT" to "বামে", "CENTER" to "মাঝে", "RIGHT" to "ডানে").forEach { (pos, label) ->
                                        val isSel = studioDraft.logoPosition == pos
                                        Button(
                                            onClick = {
                                                viewModel.updateStudioDraft(studioDraft.copy(logoPosition = pos))
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isSel) SmartNavyPrimary else Color(0xFFF1F5F9),
                                                contentColor = if (isSel) Color.White else Color(0xFF334155)
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(label, fontSize = 12.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                                        }
                                    }
                                }

                                // Logo Size Selector
                                Text(
                                    text = "লোগোর সাইজ:",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SmartNavyPrimary
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("SMALL" to "ছোট", "MEDIUM" to "মাঝারি", "LARGE" to "বড়").forEach { (sz, label) ->
                                        val isSel = studioDraft.logoSize == sz
                                        Button(
                                            onClick = {
                                                viewModel.updateStudioDraft(studioDraft.copy(logoSize = sz))
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isSel) SmartNavyPrimary else Color(0xFFF1F5F9),
                                                contentColor = if (isSel) Color.White else Color(0xFF334155)
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(label, fontSize = 12.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                                        }
                                    }
                                }

                                Divider(color = Color(0xFFE2E8F0))

                                // Product Images Display Position
                                Text(
                                    text = "মেমোতে পণ্যের ছবির অবস্থান:",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SmartNavyPrimary
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(
                                        "BELOW_TABLE" to "টেবিলের নিচে (গ্রিড)",
                                        "BESIDE_TOTALS" to "টোটাল বক্সের পাশে"
                                    ).forEach { (loc, label) ->
                                        val isSel = studioDraft.productImagesPosition == loc
                                        Button(
                                            onClick = {
                                                viewModel.updateStudioDraft(studioDraft.copy(productImagesPosition = loc))
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isSel) SmartNavyPrimary else Color(0xFFF1F5F9),
                                                contentColor = if (isSel) Color.White else Color(0xFF334155)
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(label, fontSize = 11.5.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Quick Preview Button
            item {
                OutlinedButton(
                    onClick = { showLivePreviewModal = !showLivePreviewModal },
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = null, tint = SmartNavyPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        if (showLivePreviewModal) "প্রিভিউ বন্ধ করুন" else "মেমোর প্রিভিউ দেখুন",
                        color = SmartNavyPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            // Bottom Save & Reset Actions
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            showResetConfirmDialog = true
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF475569))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("রিসেট", color = Color(0xFF475569), fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = {
                            isSaving = true
                            viewModel.saveStudioDesign(
                                config = studioDraft,
                                onSuccess = {
                                    isSaving = false
                                    Toast.makeText(context, "মেমো ডিজাইন ও ছবি সফলভাবে সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                                    viewModel.navigateBack()
                                },
                                onError = { errorMsg ->
                                    isSaving = false
                                    Toast.makeText(context, "সংরক্ষণ ব্যর্থ হয়েছে: $errorMsg", Toast.LENGTH_LONG).show()
                                }
                            )
                        },
                        enabled = !isSaving,
                        colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                        modifier = Modifier
                            .weight(2f)
                            .height(48.dp)
                            .testTag("save_studio_design_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isSaving) "সংরক্ষণ হচ্ছে..." else "ডিজাইন সংরক্ষণ করুন", fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                    }
                }

                if (showResetConfirmDialog) {
                    androidx.compose.material3.AlertDialog(
                        onDismissRequest = { showResetConfirmDialog = false },
                        title = {
                            Text("ডিজাইন রিসেট নিশ্চিতকরণ", fontWeight = FontWeight.Bold, color = SmartNavyPrimary)
                        },
                        text = {
                            Text("আপনি কি নিশ্চিত যে বর্তমান মেমো ডিজাইনটি ডিফল্ট সেটিংসে ফিরিয়ে নিতে চান? আপনার অসংরক্ষিত পরিবর্তনগুলো ডিফল্ট হয়ে যাবে।")
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    viewModel.resetStudioDesignToDefault()
                                    showResetConfirmDialog = false
                                    Toast.makeText(context, "ডিফল্ট ডিজাইনে রিসেট করা হয়েছে", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                            ) {
                                Text("হ্যাঁ, রিসেট করুন", color = Color.White)
                            }
                        },
                        dismissButton = {
                            OutlinedButton(onClick = { showResetConfirmDialog = false }) {
                                Text("বাতিল", color = Color(0xFF475569))
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
private fun PresetCard(
    title: String,
    subtitle: String,
    primaryColor: Color,
    secondaryColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.5.dp else 1.dp,
            color = if (isSelected) SmartTealPrimary else Color(0xFFE2E8F0)
        ),
        shadowElevation = if (isSelected) 3.dp else 1.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Color bar indicator
                Box(
                    modifier = Modifier
                        .width(6.dp)
                        .height(38.dp)
                        .background(primaryColor, RoundedCornerShape(3.dp))
                )
                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Color chips preview
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(18.dp).background(primaryColor, CircleShape))
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(modifier = Modifier.size(18.dp).background(secondaryColor, CircleShape))
                    Spacer(modifier = Modifier.width(8.dp))
                    if (isSelected) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = "নির্বাচিত",
                            tint = SmartTealPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(
    label: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = label,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = description,
                fontSize = 11.5.sp,
                color = Color(0xFF64748B)
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = SmartTealPrimary
            )
        )
    }
}

private data class ColorPaletteOption(
    val name: String,
    val primary: String,
    val secondary: String,
    val tableHeaderBg: String,
    val tableLine: String
)

private fun parseHexColor(hex: String): Color {
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) {
        SmartNavyPrimary
    }
}
