package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel

@Composable
fun HelpScreen(
    viewModel: SmartMemoViewModel
) {
    val shopProfile by viewModel.shopProfile.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("help_screen")
    ) {
        AppHeader(
            title = "সাহায্য ও ব্যবহার নির্দেশিকা",
            shopProfile = shopProfile,
            showBackButton = true,
            onBackClick = { viewModel.navigateBack() },
            onSettingsClick = { viewModel.navigateTo(Screen.SHOP_SETTINGS) }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.HelpOutline, contentDescription = null, tint = SmartTealPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "প্রয়োজনীয় প্রশ্নের উত্তর (FAQ)",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = SmartNavyPrimary
                            )
                        }

                        FaqItem(
                            q = "১. কিভাবে নতুন মেমো তৈরি করব?",
                            a = "ড্যাশবোর্ড থেকে 'নতুন মেমো' বাটনে চাপ দিন। ক্রেতার নাম, মোবাইল লিখুন এবং পণ্যের নাম, পরিমাণ ও দর লিখুন। পরিমাণ ও দর পরিবর্তন করলে মোট টাকা সাথে সাথে হিসাব হবে।"
                        )

                        FaqItem(
                            q = "২. ২৫টির বেশি পণ্য হলে কি নতুন পৃষ্ঠা হবে?",
                            a = "হ্যাঁ! এটি এই সফটওয়্যারের বিশেষ বৈশিষ্ট্য। প্রথম পৃষ্ঠায় সর্বোচ্চ ২৫টি পণ্য থাকে। ২৬তম পণ্য যোগ করলে স্বয়ংক্রিয়ভাবে পৃষ্ঠা ২ তৈরি হয় এবং ক্রমিক নম্বর ২৬, ২৭, ২৮ হিসেবে অব্যাহত থাকে। সব পৃষ্ঠার যোগফল মিলে একটি পূর্ণাঙ্গ মেমো ও PDF তৈরি হয়।"
                        )

                        FaqItem(
                            q = "৩. কিভাবে মেমো প্রিন্ট ও PDF শেয়ার করব?",
                            a = "মেমো সংরক্ষণ করার পর বা মেমো আর্কাইভে গিয়ে মেমোটি খুলুন। উপরে 'প্রিন্ট' চাপলে প্রিন্ট ডায়ালগ আসবে এবং 'PDF শেয়ার' চাপলে WhatsApp, ইমেইল বা মেসেঞ্জারে সরাসরি আসল PDF ফাইল পাঠাতে পারবেন।"
                        )

                        FaqItem(
                            q = "৪. দোকানের নাম ও ঠিকানা কিভাবে বদলাব?",
                            a = "ড্যাশবোর্ড থেকে 'দোকানের সেটিংস'-এ যান। সেখানে আপনার দোকানের নাম, প্রোপাইটর, ঠিকানা ও মোবাইল নম্বর লিখে সংরক্ষণ করুন। পরবর্তীতে তৈরি করা সব নতুন মেমোতে এই তথ্য চলে আসবে।"
                        )

                        FaqItem(
                            q = "৫. ফোন হারালে বা নতুন ফোন নিলে ডেটা থাকবে?",
                            a = "হ্যাঁ! সমস্ত ডেটা আপনার অনন্য গুগল আইডি দ্বারা সুরক্ষিত ক্লাউড ফায়ারস্টোর ডেটাবেসে সিঙ্ক থাকে। যেকোনো নতুন ফোনে একই গুগল অ্যাকাউন্ট দিয়ে সাইন ইন করলেই সমস্ত মেমো, পণ্য ও হিসাব হুবহু চলে আসবে।"
                        )
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SmartNavyPrimary)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape),
                            color = Color.White,
                            shadowElevation = 4.dp
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.app_logo),
                                contentDescription = "স্মার্ট মেমো লোগো",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "স্মার্ট মেমো - সংস্করণ ১.০",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "বাংলাদেশের যেকোনো ধরণের দোকানের নির্ভরযোগ্য মেমো ও ব্যবসা ব্যবস্থাপনা সফটওয়্যার।",
                                color = Color(0xFFCBD5E1),
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun FaqItem(q: String, a: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(q, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = SmartNavyPrimary)
        Spacer(modifier = Modifier.height(3.dp))
        Text(a, fontSize = 12.sp, color = Color(0xFF475569), lineHeight = 18.sp)
    }
}
