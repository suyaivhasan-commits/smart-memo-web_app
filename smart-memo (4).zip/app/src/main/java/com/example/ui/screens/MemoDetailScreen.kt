package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import com.example.util.BengaliUtils
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Memo
import com.example.ui.components.AppHeader
import com.example.ui.components.MemoPaperView
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel
import com.example.util.PdfPrintGenerator

@Composable
fun MemoDetailScreen(
    viewModel: SmartMemoViewModel
) {
    val context = LocalContext.current
    val selectedMemo by viewModel.selectedMemo.collectAsState()
    val shopProfile by viewModel.shopProfile.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (selectedMemo == null) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("কোনো মেমো নির্বাচিত নেই")
            Spacer(modifier = Modifier.height(12.dp))
            Button(onClick = { viewModel.navigateBack() }) {
                Text("ফিরে যান")
            }
        }
        return
    }

    val memo = selectedMemo!!

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("memo_detail_screen")
    ) {
        AppHeader(
            title = "মেমো বিবরণী (${memo.memoNumber})",
            shopProfile = shopProfile,
            showBackButton = true,
            onBackClick = { viewModel.navigateBack() },
            onSettingsClick = { viewModel.navigateTo(Screen.SHOP_SETTINGS) }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Action Toolbar Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "মেমো প্রিন্ট ও শেয়ার",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = SmartNavyPrimary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val pdf = PdfPrintGenerator.generateMemoPdf(context, memo, shopProfile)
                                    PdfPrintGenerator.printPdf(context, pdf, "Memo_${memo.memoNumber}")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).testTag("print_button")
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("প্রিন্ট", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    val pdf = PdfPrintGenerator.generateMemoPdf(context, memo, shopProfile)
                                    PdfPrintGenerator.sharePdf(context, pdf)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).testTag("share_pdf_button")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("PDF শেয়ার", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    val bmp = PdfPrintGenerator.generateMemoBitmap(memo, shopProfile, 0)
                                    PdfPrintGenerator.saveBitmapToGallery(context, bmp, memo.memoNumber)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).testTag("save_image_button")
                            ) {
                                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ছবি সেভ", fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.editExistingMemo(memo) },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).testTag("edit_memo_button")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("সম্পাদনা", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { showDeleteConfirm = true },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                                modifier = Modifier.weight(1f).testTag("delete_memo_button")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("মুছুন", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Real Paper Memo Preview
            item {
                MemoPaperView(
                    memo = memo,
                    shopProfile = shopProfile,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = {
                Text(
                    text = "মেমো মুছে ফেলা নিশ্চিত করুন",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFDC2626)
                )
            },
            text = {
                Column {
                    Text("আপনি কি নিশ্চিত যে মেমো নং ${memo.memoNumber} (${memo.customerName.ifBlank { "সাধারণ ক্রেতা" }}) মুছে ফেলতে চান?")
                    if (memo.dueAmount > 0) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEE2E2),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "⚠️ সতর্কতা: বকেয়া পাওনা রয়েছে!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFFDC2626)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "এই মেমোতে ${BengaliUtils.formatTaka(memo.dueAmount)} টাকা বাকি আছে। মেমোটি ডিলিট করলে ক্রেতার বাকি হিসাব মেলানো কঠিন হতে পারে।",
                                    fontSize = 12.sp,
                                    color = Color(0xFF991B1B)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        viewModel.deleteMemo(
                            memo = memo,
                            onSuccess = {
                                Toast.makeText(context, "মেমোটি সফলভাবে মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
                            },
                            onError = { err ->
                                Toast.makeText(context, "ডিলিট ব্যর্থ: $err", Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("মুছে ফেলুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}
