package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.model.ShopProfile
import com.example.data.repository.ShopRepository
import com.example.ui.theme.SmartNavyDark
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealLight
import com.example.ui.theme.SmartTealPrimary
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

// High-contrast color constants for maximum readability
private val LabelDarkColor = Color(0xFF111111)
private val PlaceholderDarkColor = Color(0xFF333333)
private val InputTextDarkColor = Color(0xFF000000)
private val BorderStrokeColor = Color(0xFF475569)

@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val repository = remember { ShopRepository(context) }

    // Tab state: 0 = Login (লগইন), 1 = Registration (রেজিস্ট্রেশন)
    var selectedTab by remember { mutableIntStateOf(0) }

    // Loading and Error state
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    // Login Form State
    var loginEmail by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var isLoginPasswordVisible by remember { mutableStateOf(false) }

    // Registration Form State
    var regShopName by remember { mutableStateOf("") }
    var regOwnerName by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var regEmail by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }
    var regConfirmPassword by remember { mutableStateOf("") }
    var isRegPasswordVisible by remember { mutableStateOf(false) }
    var isRegConfirmVisible by remember { mutableStateOf(false) }

    // Forgot Password Dialog
    var showForgotPasswordDialog by remember { mutableStateOf(false) }
    var resetEmail by remember { mutableStateOf("") }
    var resetEmailSent by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    // Reusable crisp input field styling
    val highContrastFieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = InputTextDarkColor,
        unfocusedTextColor = InputTextDarkColor,
        focusedContainerColor = Color(0xFFFFFFFF),
        unfocusedContainerColor = Color(0xFFFFFFFF),
        focusedLabelColor = LabelDarkColor,
        unfocusedLabelColor = LabelDarkColor,
        focusedPlaceholderColor = PlaceholderDarkColor,
        unfocusedPlaceholderColor = PlaceholderDarkColor,
        focusedBorderColor = SmartTealPrimary,
        unfocusedBorderColor = BorderStrokeColor,
        focusedLeadingIconColor = SmartTealPrimary,
        unfocusedLeadingIconColor = Color(0xFF1E293B),
        focusedTrailingIconColor = Color(0xFF1E293B),
        unfocusedTrailingIconColor = Color(0xFF1E293B),
        cursorColor = InputTextDarkColor
    )

    val inputTextStyle = TextStyle(
        color = InputTextDarkColor,
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        SmartNavyPrimary,
                        SmartNavyDark
                    )
                )
            )
            .testTag("auth_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 18.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // App Brand Emblem with New Logo
            Surface(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape),
                color = Color.White,
                shadowElevation = 8.dp
            ) {
                Image(
                    painter = painterResource(id = R.drawable.app_logo),
                    contentDescription = "স্মার্ট মেমো লোগো",
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(2.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "স্মার্ট মেমো",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Text(
                text = "আপনার ব্যবসার বিশ্বস্ত সহকারী",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = SmartTealLight,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Main Auth Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFFFFFFF)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    // Segmented Button / Tab Switcher with bold contrast
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    selectedTab = 0
                                    errorMessage = null
                                    successMessage = null
                                }
                                .testTag("tab_login"),
                            color = if (selectedTab == 0) SmartNavyPrimary else Color.Transparent,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "লগইন",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTab == 0) Color.White else Color(0xFF1E293B),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    selectedTab = 1
                                    errorMessage = null
                                    successMessage = null
                                }
                                .testTag("tab_register"),
                            color = if (selectedTab == 1) SmartNavyPrimary else Color.Transparent,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "রেজিস্ট্রেশন",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTab == 1) Color.White else Color(0xFF1E293B),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Error Message Banner (Bold Red on light pink)
                    if (errorMessage != null) {
                        Surface(
                            color = Color(0xFFFEE2E2),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDC2626)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = errorMessage!!,
                                    color = Color(0xFF991B1B),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 18.sp
                                )

                                // Direct action if email already exists
                                if (errorMessage!!.contains("ইতিমধ্যে একটি অ্যাকাউন্ট") ||
                                    errorMessage!!.contains("already in use", ignoreCase = true)
                                ) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = {
                                                if (regEmail.isNotBlank()) {
                                                    loginEmail = regEmail.trim()
                                                }
                                                selectedTab = 0 // Switch to Login Tab
                                                errorMessage = null
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = SmartNavyPrimary),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("switch_to_login_btn")
                                        ) {
                                            Text(
                                                text = "লগইন ট্যাবে যান",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                resetEmail = if (regEmail.isNotBlank()) regEmail.trim() else loginEmail.trim()
                                                resetEmailSent = false
                                                showForgotPasswordDialog = true
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF991B1B)),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDC2626)),
                                            modifier = Modifier.testTag("forgot_pw_from_error_btn")
                                        ) {
                                            Text(
                                                text = "পাসওয়ার্ড রিসেট",
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Success Message Banner (Bold Green on light green)
                    if (successMessage != null) {
                        Surface(
                            color = Color(0xFFDCFCE7),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF16A34A)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = successMessage!!,
                                color = Color(0xFF14532D),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(10.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // TAB 0: LOGIN
                    if (selectedTab == 0) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Login Email Field
                            OutlinedTextField(
                                value = loginEmail,
                                onValueChange = { loginEmail = it },
                                label = {
                                    Text(
                                        text = "ইমেইল ঠিকানা",
                                        color = LabelDarkColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp
                                    )
                                },
                                placeholder = {
                                    Text(
                                        text = "যেমন: shop@example.com",
                                        color = PlaceholderDarkColor,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.5.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Email, contentDescription = null, tint = SmartTealPrimary)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                textStyle = inputTextStyle,
                                colors = highContrastFieldColors,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("login_email_input"),
                                shape = RoundedCornerShape(10.dp)
                            )

                            // Login Password Field
                            OutlinedTextField(
                                value = loginPassword,
                                onValueChange = { loginPassword = it },
                                label = {
                                    Text(
                                        text = "পাসওয়ার্ড",
                                        color = LabelDarkColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp
                                    )
                                },
                                placeholder = {
                                    Text(
                                        text = "আপনার অ্যাকাউন্টের পাসওয়ার্ড",
                                        color = PlaceholderDarkColor,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.5.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = SmartTealPrimary)
                                },
                                trailingIcon = {
                                    IconButton(onClick = { isLoginPasswordVisible = !isLoginPasswordVisible }) {
                                        Icon(
                                            imageVector = if (isLoginPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                            contentDescription = if (isLoginPasswordVisible) "পাসওয়ার্ড লুকান" else "পাসওয়ার্ড দেখুন",
                                            tint = Color(0xFF1E293B)
                                        )
                                    }
                                },
                                visualTransformation = if (isLoginPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                singleLine = true,
                                textStyle = inputTextStyle,
                                colors = highContrastFieldColors,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("login_password_input"),
                                shape = RoundedCornerShape(10.dp)
                            )

                            // Forgot Password Link
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Text(
                                    text = "পাসওয়ার্ড ভুলে গেছেন?",
                                    color = SmartNavyPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .clickable {
                                            resetEmail = loginEmail.trim()
                                            resetEmailSent = false
                                            showForgotPasswordDialog = true
                                        }
                                        .padding(vertical = 4.dp, horizontal = 2.dp)
                                        .testTag("forgot_password_button")
                                )
                            }

                            // Login Button
                            Button(
                                onClick = {
                                    val email = loginEmail.trim()
                                    val password = loginPassword.trim()

                                    if (email.isBlank() || password.isBlank()) {
                                        errorMessage = "দয়া করে আপনার ইমেইল এবং পাসওয়ার্ড লিখুন।"
                                        return@Button
                                    }

                                    isLoading = true
                                    errorMessage = null
                                    coroutineScope.launch {
                                        try {
                                            Firebase.auth.signInWithEmailAndPassword(email, password).await()
                                            isLoading = false
                                            onAuthSuccess()
                                        } catch (e: FirebaseAuthInvalidUserException) {
                                            isLoading = false
                                            errorMessage = "এই ইমেইলে কোনো দোকান অ্যাকাউন্ট পাওয়া যায়নি। অনুগ্রহ করে রেজিস্ট্রেশন করুন।"
                                        } catch (e: FirebaseAuthInvalidCredentialsException) {
                                            isLoading = false
                                            errorMessage = "ইমেইল অথবা পাসওয়ার্ড সঠিক নয়। দয়া করে পুনরায় যাচাই করুন।"
                                        } catch (e: Exception) {
                                            isLoading = false
                                            Log.e("Auth", "Email login failed", e)
                                            errorMessage = parseFirebaseAuthError(e)
                                        }
                                    }
                                },
                                enabled = !isLoading,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("email_login_button")
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        strokeWidth = 2.5.dp,
                                        modifier = Modifier.size(22.dp)
                                    )
                                } else {
                                    Text(
                                        text = "লগইন করুন",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }

                            // Switch to Register Prompt
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "নতুন দোকানদার? ",
                                    fontSize = 13.5.sp,
                                    color = Color(0xFF1E293B),
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "নতুন অ্যাকাউন্ট রেজিস্ট্রেশন করুন",
                                    fontSize = 13.5.sp,
                                    color = SmartNavyPrimary,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier
                                        .clickable {
                                            selectedTab = 1
                                            errorMessage = null
                                        }
                                        .padding(4.dp)
                                )
                            }
                        }
                    }

                    // TAB 1: REGISTRATION
                    if (selectedTab == 1) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // 1. Shop Name
                            OutlinedTextField(
                                value = regShopName,
                                onValueChange = { regShopName = it },
                                label = {
                                    Text(
                                        text = "দোকানের নাম *",
                                        color = LabelDarkColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp
                                    )
                                },
                                placeholder = {
                                    Text(
                                        text = "যেমন: মেসার্স আল-আমিন ট্রেডার্স",
                                        color = PlaceholderDarkColor,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.5.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Business, contentDescription = null, tint = SmartTealPrimary)
                                },
                                singleLine = true,
                                textStyle = inputTextStyle,
                                colors = highContrastFieldColors,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("reg_shop_name_input"),
                                shape = RoundedCornerShape(10.dp)
                            )

                            // 2. Owner Name
                            OutlinedTextField(
                                value = regOwnerName,
                                onValueChange = { regOwnerName = it },
                                label = {
                                    Text(
                                        text = "মালিক / প্রোপাইটরের নাম *",
                                        color = LabelDarkColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp
                                    )
                                },
                                placeholder = {
                                    Text(
                                        text = "যেমন: মোঃ আব্দুল করিম",
                                        color = PlaceholderDarkColor,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.5.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = SmartTealPrimary)
                                },
                                singleLine = true,
                                textStyle = inputTextStyle,
                                colors = highContrastFieldColors,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("reg_owner_name_input"),
                                shape = RoundedCornerShape(10.dp)
                            )

                            // 3. Email
                            OutlinedTextField(
                                value = regEmail,
                                onValueChange = { regEmail = it },
                                label = {
                                    Text(
                                        text = "ইমেইল ঠিকানা *",
                                        color = LabelDarkColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp
                                    )
                                },
                                placeholder = {
                                    Text(
                                        text = "যেমন: shop@example.com",
                                        color = PlaceholderDarkColor,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.5.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Email, contentDescription = null, tint = SmartTealPrimary)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                textStyle = inputTextStyle,
                                colors = highContrastFieldColors,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("reg_email_input"),
                                shape = RoundedCornerShape(10.dp)
                            )

                            // 4. Mobile (Optional)
                            OutlinedTextField(
                                value = regPhone,
                                onValueChange = { regPhone = it },
                                label = {
                                    Text(
                                        text = "মোবাইল নম্বর (ঐচ্ছিক)",
                                        color = LabelDarkColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp
                                    )
                                },
                                placeholder = {
                                    Text(
                                        text = "যেমন: ০১৭১২-০৪৬৫৭৮",
                                        color = PlaceholderDarkColor,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.5.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Phone, contentDescription = null, tint = SmartTealPrimary)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                textStyle = inputTextStyle,
                                colors = highContrastFieldColors,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("reg_phone_input"),
                                shape = RoundedCornerShape(10.dp)
                            )

                            // 5. Password
                            OutlinedTextField(
                                value = regPassword,
                                onValueChange = { regPassword = it },
                                label = {
                                    Text(
                                        text = "পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর) *",
                                        color = LabelDarkColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp
                                    )
                                },
                                placeholder = {
                                    Text(
                                        text = "গোপন পাসওয়ার্ড লিখুন",
                                        color = PlaceholderDarkColor,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.5.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = SmartTealPrimary)
                                },
                                trailingIcon = {
                                    IconButton(onClick = { isRegPasswordVisible = !isRegPasswordVisible }) {
                                        Icon(
                                            imageVector = if (isRegPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                            contentDescription = if (isRegPasswordVisible) "পাসওয়ার্ড লুকান" else "পাসওয়ার্ড দেখুন",
                                            tint = Color(0xFF1E293B)
                                        )
                                    }
                                },
                                visualTransformation = if (isRegPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                singleLine = true,
                                textStyle = inputTextStyle,
                                colors = highContrastFieldColors,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("reg_password_input"),
                                shape = RoundedCornerShape(10.dp)
                            )

                            // 6. Confirm Password
                            OutlinedTextField(
                                value = regConfirmPassword,
                                onValueChange = { regConfirmPassword = it },
                                label = {
                                    Text(
                                        text = "পাসওয়ার্ড নিশ্চিত করুন *",
                                        color = LabelDarkColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp
                                    )
                                },
                                placeholder = {
                                    Text(
                                        text = "একই পাসওয়ার্ড পুনরায় লিখুন",
                                        color = PlaceholderDarkColor,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.5.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.LockReset, contentDescription = null, tint = SmartTealPrimary)
                                },
                                trailingIcon = {
                                    IconButton(onClick = { isRegConfirmVisible = !isRegConfirmVisible }) {
                                        Icon(
                                            imageVector = if (isRegConfirmVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                            contentDescription = if (isRegConfirmVisible) "পাসওয়ার্ড লুকান" else "পাসওয়ার্ড দেখুন",
                                            tint = Color(0xFF1E293B)
                                        )
                                    }
                                },
                                visualTransformation = if (isRegConfirmVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                singleLine = true,
                                textStyle = inputTextStyle,
                                colors = highContrastFieldColors,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("reg_confirm_password_input"),
                                shape = RoundedCornerShape(10.dp)
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // Register Submit Button
                            Button(
                                onClick = {
                                    val shopName = regShopName.trim()
                                    val ownerName = regOwnerName.trim()
                                    val email = regEmail.trim()
                                    val phone = regPhone.trim()
                                    val password = regPassword.trim()
                                    val confirmPassword = regConfirmPassword.trim()

                                    if (shopName.isBlank()) {
                                        errorMessage = "দয়া করে আপনার দোকানের নাম লিখুন।"
                                        return@Button
                                    }
                                    if (ownerName.isBlank()) {
                                        errorMessage = "দয়া করে মালিকের নাম লিখুন।"
                                        return@Button
                                    }
                                    if (email.isBlank() || !email.contains("@")) {
                                        errorMessage = "দয়া করে সঠিক ইমেইল ঠিকানা দিন।"
                                        return@Button
                                    }
                                    if (password.length < 6) {
                                        errorMessage = "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।"
                                        return@Button
                                    }
                                    if (password != confirmPassword) {
                                        errorMessage = "পাসওয়ার্ড দুটি মিলছে না! নিশ্চিতকরণ পাসওয়ার্ড পুনরায় যাচাই করুন।"
                                        return@Button
                                    }

                                    isLoading = true
                                    errorMessage = null
                                    coroutineScope.launch {
                                        try {
                                            val authResult = Firebase.auth.createUserWithEmailAndPassword(email, password).await()
                                            val uid = authResult.user?.uid
                                            if (uid != null) {
                                                // Create user-scoped shop profile in Firestore
                                                val profile = ShopProfile(
                                                    userId = uid,
                                                    shopName = shopName,
                                                    ownerName = ownerName,
                                                    phone = phone,
                                                    email = email,
                                                    address = "",
                                                    memoNotice = "ধন্যবাদ, আবার আসবেন"
                                                )
                                                repository.saveShopProfile(profile)
                                            }
                                            isLoading = false
                                            onAuthSuccess()
                                        } catch (e: FirebaseAuthUserCollisionException) {
                                            isLoading = false
                                            errorMessage = "এই ইমেইল (${email}) দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা আছে। অনুগ্রহ করে 'লগইন' করুন।"
                                        } catch (e: FirebaseAuthWeakPasswordException) {
                                            isLoading = false
                                            errorMessage = "পাসওয়ার্ড অত্যন্ত দুর্বল। কমপক্ষে ৬ অক্ষরের শক্তিশালী পাসওয়ার্ড দিন।"
                                        } catch (e: Exception) {
                                            isLoading = false
                                            Log.e("Auth", "Registration failed", e)
                                            val parsed = parseFirebaseAuthError(e)
                                            if (parsed.contains("ইতিমধ্যে একটি অ্যাকাউন্ট") || e.message?.contains("already in use", ignoreCase = true) == true) {
                                                errorMessage = "এই ইমেইল (${email}) দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা আছে। অনুগ্রহ করে 'লগইন' করুন।"
                                            } else {
                                                errorMessage = parsed
                                            }
                                        }
                                    }
                                },
                                enabled = !isLoading,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("email_register_button")
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        strokeWidth = 2.5.dp,
                                        modifier = Modifier.size(22.dp)
                                    )
                                } else {
                                    Text(
                                        text = "রেজিস্ট্রেশন সম্পন্ন করুন",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }

                            // Switch to Login Prompt
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "ইতিমধ্যে অ্যাকাউন্ট আছে? ",
                                    fontSize = 13.5.sp,
                                    color = Color(0xFF1E293B),
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "লগইন করুন",
                                    fontSize = 13.5.sp,
                                    color = SmartNavyPrimary,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier
                                        .clickable {
                                            selectedTab = 0
                                            errorMessage = null
                                        }
                                        .padding(4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // "অথবা" High-Contrast Divider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFF94A3B8), thickness = 1.dp)
                        Text(
                            text = "অথবা",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF334155),
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFF94A3B8), thickness = 1.dp)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Option 3: Optional Google Sign-In / Sign-Up
                    OutlinedButton(
                        onClick = {
                            isLoading = true
                            errorMessage = null
                            startGoogleSignIn(
                                context = context,
                                credentialManager = credentialManager,
                                repository = repository,
                                scope = coroutineScope,
                                onAuthSuccess = {
                                    isLoading = false
                                    onAuthSuccess()
                                },
                                onAuthError = { err ->
                                    isLoading = false
                                    errorMessage = err
                                },
                                onAuthCancelled = {
                                    isLoading = false
                                }
                            )
                        },
                        enabled = !isLoading,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, SmartNavyPrimary),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color(0xFFF8FAFC)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("google_sign_in_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = SmartTealPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (selectedTab == 0) "Google দিয়ে সাইন ইন করুন" else "Google দিয়ে সাইন আপ করুন",
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = SmartNavyPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Security & Cloud Guarantee
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "সম্পূর্ণ নিরাপদ ও ডেটা ক্লাউড সুরক্ষিত",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Forgot Password Dialog
    if (showForgotPasswordDialog) {
        AlertDialog(
            onDismissRequest = { showForgotPasswordDialog = false },
            title = {
                Text(
                    text = "পাসওয়ার্ড পুনরুদ্ধার",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color(0xFF111111)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "আপনার অ্যাকাউন্টের ইমেইল ঠিকানা দিন। আমরা পাসওয়ার্ড রিসেট করার একটি লিংক পাঠিয়ে দেব।",
                        fontSize = 13.sp,
                        color = Color(0xFF1E293B),
                        fontWeight = FontWeight.Medium
                    )

                    OutlinedTextField(
                        value = resetEmail,
                        onValueChange = { resetEmail = it },
                        label = {
                            Text(
                                text = "ইমেইল *",
                                color = LabelDarkColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp
                            )
                        },
                        placeholder = {
                            Text(
                                text = "shop@example.com",
                                color = PlaceholderDarkColor,
                                fontWeight = FontWeight.Medium,
                                fontSize = 13.5.sp
                            )
                        },
                        singleLine = true,
                        textStyle = inputTextStyle,
                        colors = highContrastFieldColors,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reset_email_input"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )

                    if (resetEmailSent) {
                        Text(
                            text = "আপনার ইমেইলে পাসওয়ার্ড রিসেট লিংক পাঠানো হয়েছে! ইনবক্স বা স্প্যাম ফোল্ডার পরীক্ষা করুন।",
                            color = Color(0xFF15803D),
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val email = resetEmail.trim()
                        if (email.isNotBlank() && email.contains("@")) {
                            coroutineScope.launch {
                                try {
                                    Firebase.auth.sendPasswordResetEmail(email).await()
                                    resetEmailSent = true
                                    successMessage = "পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে।"
                                } catch (e: Exception) {
                                    errorMessage = "রিসেট লিংক পাঠানো ব্যর্থ হয়েছে: ${e.localizedMessage}"
                                    showForgotPasswordDialog = false
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary)
                ) {
                    Text(
                        text = if (resetEmailSent) "ঠিক আছে" else "রিসেট লিংক পাঠান",
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotPasswordDialog = false }) {
                    Text(
                        text = "বাতিল",
                        color = Color(0xFF333333),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )
    }
}

private fun parseFirebaseAuthError(e: Exception): String {
    val fullErrorText = buildString {
        append(e.message ?: "")
        append(" ")
        append(e.localizedMessage ?: "")
        append(" ")
        append(e.cause?.message ?: "")
        append(" ")
        append(e.javaClass.simpleName)
    }

    return when {
        fullErrorText.contains("already in use", ignoreCase = true) ||
        fullErrorText.contains("already-in-use", ignoreCase = true) ||
        fullErrorText.contains("UserCollision", ignoreCase = true) ||
        fullErrorText.contains("email address is already in use", ignoreCase = true) ->
            "এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা আছে। অনুগ্রহ করে 'লগইন' করুন।"

        fullErrorText.contains("network", ignoreCase = true) ->
            "ইন্টারনেট সংযোগ নেই বা অত্যন্ত দুর্বল। ইন্টারনেট সংযোগ পরীক্ষা করুন।"

        fullErrorText.contains("user-not-found", ignoreCase = true) ||
        fullErrorText.contains("no user record", ignoreCase = true) ->
            "এই ইমেইলে কোনো দোকান অ্যাকাউন্ট নেই। দয়া করে রেজিস্ট্রেশন করুন।"

        fullErrorText.contains("wrong-password", ignoreCase = true) ||
        fullErrorText.contains("invalid-credential", ignoreCase = true) ||
        fullErrorText.contains("invalid credential", ignoreCase = true) ->
            "পাসওয়ার্ড বা ইমেইল সঠিক নয়। পুনরায় চেষ্টা করুন।"

        fullErrorText.contains("weak-password", ignoreCase = true) ||
        fullErrorText.contains("weak password", ignoreCase = true) ->
            "পাসওয়ার্ড অত্যন্ত দুর্বল। কমপক্ষে ৬ অক্ষরের শক্তিশালী পাসওয়ার্ড দিন।"

        fullErrorText.contains("invalid-email", ignoreCase = true) ||
        fullErrorText.contains("badly formatted", ignoreCase = true) ->
            "সঠিক ফরম্যাটের ইমেইল ঠিকানা প্রদান করুন।"

        fullErrorText.contains("too-many-requests", ignoreCase = true) ||
        fullErrorText.contains("blocked all requests", ignoreCase = true) ->
            "অতিরিক্ত চেষ্টার কারণে সাময়িকভাবে ব্লক করা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।"

        else -> e.localizedMessage ?: "একটি ত্রুটি ঘটেছে। দয়া করে আবার চেষ্টা করুন।"
    }
}

private fun startGoogleSignIn(
    context: Context,
    credentialManager: CredentialManager,
    repository: ShopRepository,
    scope: CoroutineScope,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    onAuthCancelled: () -> Unit
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onAuthError("Google Sign-In কনফিগারেশন পাওয়া যায়নি (default_web_client_id)")
        return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(context as Activity, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                val authResult = Firebase.auth.signInWithCredential(authCredential).await()
                val uid = authResult.user?.uid

                if (uid != null) {
                    // Check if shop profile already exists
                    val db = FirebaseFirestore.getInstance(
                        context.applicationContext.getString(R.string.firestore_database_id)
                    )
                    val profileDoc = db.collection("users").document(uid)
                        .collection("shop_profile").document("info")
                        .get().await()

                    if (!profileDoc.exists()) {
                        val displayName = authResult.user?.displayName ?: "আমার দোকান"
                        val email = authResult.user?.email ?: ""
                        val initialProfile = ShopProfile(
                            userId = uid,
                            shopName = if (displayName.isNotBlank()) "$displayName - এর দোকান" else "মেসার্স আল-আমিন ট্রেডার্স",
                            ownerName = displayName,
                            email = email,
                            phone = "",
                            address = "",
                            memoNotice = "ধন্যবাদ, আবার আসবেন"
                        )
                        repository.saveShopProfile(initialProfile)
                    }
                }

                onAuthSuccess()
            } else {
                onAuthError("অপ্রত্যাশিত ক্রেডেনশিয়াল ফরম্যাট")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google Sign-In বাতিল করা হয়েছে: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e("Auth", "Google Sign-In ব্যর্থ হয়েছে", e)
            onAuthError(e.localizedMessage ?: "সাইন ইন ব্যর্থ হয়েছে। দয়া করে আবার চেষ্টা করুন।")
        }
    }
}
