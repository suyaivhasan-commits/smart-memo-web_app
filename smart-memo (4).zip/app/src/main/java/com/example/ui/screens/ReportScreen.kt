package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Memo
import com.example.ui.components.AppHeader
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel
import com.example.util.BengaliUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun ReportScreen(
    viewModel: SmartMemoViewModel
) {
    val shopProfile by viewModel.shopProfile.collectAsState()
    val allMemos by viewModel.memos.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    var selectedPeriodTab by remember { mutableIntStateOf(0) } // 0: দৈনিক, 1: সাপ্তাহিক, 2: মাসিক, 3: বার্ষিক
    val periodLabels = listOf("দৈনিক", "সাপ্তাহিক", "মাসিক", "বার্ষিক")

    // Filter memos by selected period
    val todayStr = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
    val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
    val curCal = Calendar.getInstance()

    val reportMemos = allMemos.filter { memo ->
        try {
            val date = sdf.parse(memo.memoDate) ?: return@filter true
            val cal = Calendar.getInstance()
            cal.time = date

            when (selectedPeriodTab) {
                0 -> memo.memoDate == todayStr // Daily
                1 -> cal.get(Calendar.WEEK_OF_YEAR) == curCal.get(Calendar.WEEK_OF_YEAR) && cal.get(Calendar.YEAR) == curCal.get(Calendar.YEAR)
                2 -> cal.get(Calendar.MONTH) == curCal.get(Calendar.MONTH) && cal.get(Calendar.YEAR) == curCal.get(Calendar.YEAR)
                3 -> cal.get(Calendar.YEAR) == curCal.get(Calendar.YEAR)
                else -> true
            }
        } catch (e: Exception) {
            true
        }
    }

    val totalSales = reportMemos.sumOf { it.grandTotal }
    val totalMemoCount = reportMemos.size
    val totalItems = reportMemos.sumOf { memo -> memo.items.filter { it.productName.isNotBlank() }.sumOf { it.quantity }.toInt() }
    val totalSubtotal = reportMemos.sumOf { it.subtotal }
    val totalDiscount = reportMemos.sumOf { it.discount }
    val totalPaid = reportMemos.sumOf { it.paidAmount }
    val totalDue = reportMemos.sumOf { it.dueAmount }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("report_screen")
    ) {
        AppHeader(
            title = "ব্যবসায়িক রিপোর্ট",
            shopProfile = shopProfile,
            showBackButton = true,
            onBackClick = { viewModel.navigateBack() },
            onSettingsClick = { viewModel.navigateTo(Screen.SHOP_SETTINGS) }
        )

        // Period Tab Selector
        TabRow(
            selectedTabIndex = selectedPeriodTab,
            containerColor = Color.White,
            contentColor = SmartTealPrimary
        ) {
            periodLabels.forEachIndexed { index, title ->
                Tab(
                    selected = selectedPeriodTab == index,
                    onClick = { selectedPeriodTab = index },
                    text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Big Metrics Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "মোট বিক্রি",
                        value = BengaliUtils.formatTaka(totalSales),
                        color = SmartNavyPrimary,
                        modifier = Modifier.weight(1.2f)
                    )
                    MetricCard(
                        title = "মোট মেমো",
                        value = "$totalMemoCount টি",
                        color = Color(0xFF2563EB),
                        modifier = Modifier.weight(0.9f)
                    )
                    MetricCard(
                        title = "মোট পণ্য",
                        value = "$totalItems টি",
                        color = Color(0xFF0D9488),
                        modifier = Modifier.weight(0.9f)
                    )
                }
            }

            // Financial Breakdown Donut Chart
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Text(
                            text = "আর্থিক পর্যালোচনা ও বিতরণ",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = SmartNavyPrimary
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Donut Chart on Left
                            Box(
                                modifier = Modifier
                                    .size(130.dp)
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                val grandSafe = if (totalSales > 0) totalSales else 1.0
                                val paidSweep = ((totalPaid / grandSafe) * 360f).toFloat().coerceIn(0f, 360f)
                                val dueSweep = ((totalDue / grandSafe) * 360f).toFloat().coerceIn(0f, 360f)

                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val strokeWidth = 22.dp.toPx()
                                    // Background track
                                    drawCircle(
                                        color = Color(0xFFF1F5F9),
                                        style = Stroke(width = strokeWidth)
                                    )

                                    if (totalSales > 0) {
                                        // Paid Arc (Green)
                                        drawArc(
                                            color = Color(0xFF16A34A),
                                            startAngle = -90f,
                                            sweepAngle = paidSweep,
                                            useCenter = false,
                                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                        )
                                        // Due Arc (Red)
                                        drawArc(
                                            color = Color(0xFFDC2626),
                                            startAngle = -90f + paidSweep,
                                            sweepAngle = dueSweep,
                                            useCenter = false,
                                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "${periodLabels[selectedPeriodTab]}",
                                        fontSize = 10.sp,
                                        color = Color(0xFF64748B)
                                    )
                                    Text(
                                        text = "সারসংক্ষেপ",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SmartNavyPrimary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            // Legend on Right
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                LegendRow(
                                    label = "পণ্যমূল্য",
                                    value = BengaliUtils.formatTaka(totalSubtotal),
                                    color = Color(0xFF2563EB)
                                )
                                LegendRow(
                                    label = "ছাড়",
                                    value = BengaliUtils.formatTaka(totalDiscount),
                                    color = Color(0xFFD97706)
                                )
                                LegendRow(
                                    label = "মোট জমা",
                                    value = BengaliUtils.formatTaka(totalPaid),
                                    color = Color(0xFF16A34A)
                                )
                                LegendRow(
                                    label = "মোট বাকি",
                                    value = BengaliUtils.formatTaka(totalDue),
                                    color = Color(0xFFDC2626)
                                )
                            }
                        }
                    }
                }
            }

            // Summary List Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "বিবরণী তথ্য",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = SmartNavyPrimary
                        )

                        ReportDetailItem(label = "সর্বমোট বিক্রিত মেমো:", value = "$totalMemoCount টি")
                        ReportDetailItem(label = "মোট বিক্রীত পণ্যের পরিমাণ:", value = "$totalItems একক")
                        ReportDetailItem(label = "মোট সর্বমোট ইনভয়েস মূল্য:", value = BengaliUtils.formatTaka(totalSales))
                        ReportDetailItem(label = "নগদ ও অ্যাকাউন্টে জমা:", value = BengaliUtils.formatTaka(totalPaid), valueColor = Color(0xFF16A34A))
                        ReportDetailItem(label = "বাকি পাওনা:", value = BengaliUtils.formatTaka(totalDue), valueColor = Color(0xFFDC2626))
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Text(title, fontSize = 11.5.sp, color = Color(0xFF64748B))
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
        }
    }
}

@Composable
private fun LegendRow(
    label: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(label, fontSize = 12.sp, color = Color(0xFF334155))
        }
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun ReportDetailItem(
    label: String,
    value: String,
    valueColor: Color = Color(0xFF0F172A)
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.5.sp, color = Color(0xFF64748B))
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
