package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SmartLightColorScheme = lightColorScheme(
    primary = SmartTealPrimary,
    onPrimary = Color.White,
    primaryContainer = SmartTealContainer,
    onPrimaryContainer = SmartTealDark,
    secondary = SmartNavyPrimary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCE5F0),
    onSecondaryContainer = SmartNavyDark,
    tertiary = StatusBlue,
    onTertiary = Color.White,
    background = SmartBackgroundLight,
    onBackground = Color(0xFF000000),
    surface = SmartSurfaceLight,
    onSurface = Color(0xFF000000),
    surfaceVariant = SmartSurfaceVariant,
    onSurfaceVariant = Color(0xFF111111),
    outline = Color(0xFF475569),
    outlineVariant = Color(0xFF64748B)
)

private val SmartDarkColorScheme = SmartLightColorScheme

@Composable
fun SmartMemoTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = SmartLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

