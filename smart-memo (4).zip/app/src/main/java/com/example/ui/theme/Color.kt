package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Navy & Teal
val SmartNavyDark = Color(0xFF0A192F)
val SmartNavyPrimary = Color(0xFF0F2B48)
val SmartNavyCard = Color(0xFF16385C)
val SmartTealPrimary = Color(0xFF00897B)
val SmartTealDark = Color(0xFF004D40)
val SmartTealLight = Color(0xFF26A69A)
val SmartTealContainer = Color(0xFFE0F2F1)

val SmartBackgroundLight = Color(0xFFF4F7FB)
val SmartSurfaceLight = Color(0xFFFFFFFF)
val SmartSurfaceVariant = Color(0xFFE8EEF5)

val TextPrimary = Color(0xFF000000)
val TextSecondary = Color(0xFF1E293B)
val TextMuted = Color(0xFF475569)

// High-contrast form elements requested by user
val FormLabelColor = Color(0xFF111111)
val FormPlaceholderColor = Color(0xFF333333)
val FormInputTextColor = Color(0xFF000000)
val FormBorderColor = Color(0xFF475569)
val FormFocusedBorderColor = Color(0xFF00897B)

// Status colors
val StatusPaidGreen = Color(0xFF16A34A)
val StatusPaidContainer = Color(0xFFDCFCE7)
val StatusDueRed = Color(0xFFDC2626)
val StatusDueContainer = Color(0xFFFEE2E2)
val StatusPendingOrange = Color(0xFFEA580C)
val StatusOrangeContainer = Color(0xFFFFEDD5)
val StatusBlue = Color(0xFF2563EB)
val StatusBlueContainer = Color(0xFFDBEAFE)

val BorderLight = Color(0xFF64748B)
val MemoPaperBg = Color(0xFFFFFFFF)

