package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Memo
import com.example.ui.components.AppHeader
import com.example.ui.theme.SmartNavyDark
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealLight
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel
import com.example.util.BengaliUtils

@Composable
fun DashboardScreen(
    viewModel: SmartMemoViewModel,
    onLogoutClick: () -> Unit
) {
    val shopProfile by viewModel.shopProfile.collectAsState()
    val todaySales by viewModel.todaySales.collectAsState()
    val todayMemos by viewModel.todayMemoCount.collectAsState()
    val totalDues by viewModel.totalDues.collectAsState()
    val allMemos by viewModel.memos.collectAsState()

    val recentMemos = allMemos.take(5)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("dashboard_screen")
    ) {
        // App Header
        AppHeader(
            title = "ড্যাশবোর্ড",
            shopProfile = shopProfile,
            showBackButton = false,
            onSettingsClick = { viewModel.navigateTo(Screen.SHOP_SETTINGS) },
            onLogoutClick = onLogoutClick
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Today Sales Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "আজকের বিক্রি",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF64748B)
                            )
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFDCFCE7)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.TrendingUp,
                                        contentDescription = null,
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "সক্রিয় ব্যবসা",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF16A34A)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = BengaliUtils.formatTaka(todaySales),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = SmartNavyPrimary
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Sub stats
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { viewModel.openTodayMemos() }
                                    .testTag("dashboard_today_memos_card"),
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFF1F5F9)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "আজকের মেমো",
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B)
                                        )
                                        Icon(
                                            imageVector = Icons.Default.ArrowForward,
                                            contentDescription = "আজকের মেমো দেখুন",
                                            tint = SmartTealPrimary,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.Bottom
                                    ) {
                                        Text(
                                            text = "$todayMemos টি",
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SmartNavyPrimary
                                        )
                                        Text(
                                            text = "দেখুন →",
                                            fontSize = 10.sp,
                                            color = SmartTealPrimary,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }

                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { viewModel.openDueMemos() }
                                    .testTag("dashboard_due_memos_card"),
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFFEE2E2)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "মোট বাকি পাওনা",
                                            fontSize = 11.sp,
                                            color = Color(0xFF991B1B)
                                        )
                                        Icon(
                                            imageVector = Icons.Default.ArrowForward,
                                            contentDescription = "বাকি মেমো দেখুন",
                                            tint = Color(0xFFDC2626),
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.Bottom
                                    ) {
                                        Text(
                                            text = BengaliUtils.formatTaka(totalDues),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFDC2626)
                                        )
                                        Text(
                                            text = "দেখুন →",
                                            fontSize = 10.sp,
                                            color = Color(0xFFDC2626),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Quick Actions Grid
            item {
                Text(
                    text = "প্রধান সেবাসমূহ",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = SmartNavyPrimary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Row 1
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ActionCard(
                            title = "নতুন মেমো",
                            icon = Icons.Default.AddCircle,
                            color = Color(0xFF00897B),
                            modifier = Modifier.weight(1f),
                            testTag = "action_new_memo",
                            onClick = { viewModel.startNewMemo() }
                        )
                        ActionCard(
                            title = "সব মেমো",
                            icon = Icons.Default.ReceiptLong,
                            color = Color(0xFF2563EB),
                            modifier = Modifier.weight(1f),
                            testTag = "action_all_memos",
                            onClick = { viewModel.navigateTo(Screen.MEMO_ARCHIVE) }
                        )
                        ActionCard(
                            title = "গ্রাহক",
                            icon = Icons.Default.People,
                            color = Color(0xFF9333EA),
                            modifier = Modifier.weight(1f),
                            testTag = "action_customers",
                            onClick = { viewModel.navigateTo(Screen.CUSTOMERS) }
                        )
                    }

                    // Row 2
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ActionCard(
                            title = "পণ্য ও স্টক",
                            icon = Icons.Default.Inventory2,
                            color = Color(0xFFEA580C),
                            modifier = Modifier.weight(1f),
                            testTag = "action_products",
                            onClick = { viewModel.navigateTo(Screen.PRODUCTS) }
                        )
                        ActionCard(
                            title = "জমা-বাকি",
                            icon = Icons.Default.AccountBalanceWallet,
                            color = Color(0xFFE11D48),
                            modifier = Modifier.weight(1f),
                            testTag = "action_dues",
                            onClick = { viewModel.navigateTo(Screen.DUE_MANAGEMENT) }
                        )
                        ActionCard(
                            title = "রিপোর্ট",
                            icon = Icons.Default.Analytics,
                            color = Color(0xFF0D9488),
                            modifier = Modifier.weight(1f),
                            testTag = "action_reports",
                            onClick = { viewModel.navigateTo(Screen.REPORTS) }
                        )
                    }

                    // Row 3
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ActionCard(
                            title = "দোকানের সেটিংস",
                            icon = Icons.Default.Settings,
                            color = Color(0xFF475569),
                            modifier = Modifier.weight(1f),
                            testTag = "action_settings",
                            onClick = { viewModel.navigateTo(Screen.SHOP_SETTINGS) }
                        )
                        ActionCard(
                            title = "ব্যাকআপ",
                            icon = Icons.Default.CloudSync,
                            color = Color(0xFF0284C7),
                            modifier = Modifier.weight(1f),
                            testTag = "action_backup",
                            onClick = { viewModel.navigateTo(Screen.BACKUP) }
                        )
                        ActionCard(
                            title = "সাহায্য",
                            icon = Icons.Default.HelpOutline,
                            color = Color(0xFFD97706),
                            modifier = Modifier.weight(1f),
                            testTag = "action_help",
                            onClick = { viewModel.navigateTo(Screen.HELP) }
                        )
                    }
                }
            }

            // Recent Memos Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "সাম্প্রতিক মেমো",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = SmartNavyPrimary
                    )
                    TextButton(
                        onClick = { viewModel.navigateTo(Screen.MEMO_ARCHIVE) }
                    ) {
                        Text(
                            text = "সব দেখুন",
                            color = SmartTealPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (recentMemos.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color.White,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = null,
                                tint = Color(0xFFCBD5E1),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "এখনও কোনো মেমো তৈরি হয়নি",
                                fontSize = 14.sp,
                                color = Color(0xFF64748B)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.startNewMemo() },
                                colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("প্রথম মেমো তৈরি করুন")
                            }
                        }
                    }
                }
            } else {
                items(recentMemos) { memo ->
                    RecentMemoCard(
                        memo = memo,
                        onViewClick = { viewModel.selectMemoForDetail(memo) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }
}

@Composable
private fun ActionCard(
    title: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = color),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun RecentMemoCard(
    memo: Memo,
    onViewClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onViewClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE0F2F1)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ReceiptLong,
                    contentDescription = null,
                    tint = SmartTealPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = memo.memoNumber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        color = SmartNavyPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = memo.memoDate,
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = memo.customerName.ifBlank { "সাধারণ ক্রেতা" },
                    fontSize = 13.sp,
                    color = Color(0xFF1E293B),
                    fontWeight = FontWeight.Medium
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = BengaliUtils.formatTaka(memo.grandTotal),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = SmartNavyPrimary
                )
                if (memo.dueAmount > 0) {
                    Text(
                        text = "বাকি: ${BengaliUtils.formatTaka(memo.dueAmount)}",
                        fontSize = 11.sp,
                        color = Color(0xFFDC2626),
                        fontWeight = FontWeight.SemiBold
                    )
                } else {
                    Text(
                        text = "পরিশোধিত",
                        fontSize = 11.sp,
                        color = Color(0xFF16A34A),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
