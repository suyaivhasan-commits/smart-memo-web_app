package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Memo
import com.example.ui.components.AppHeader
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel
import com.example.ui.viewmodel.StatusFilter
import com.example.ui.viewmodel.TimeFilter
import com.example.util.BengaliUtils
import com.example.util.PdfPrintGenerator

@Composable
fun MemoArchiveScreen(
    viewModel: SmartMemoViewModel
) {
    val context = LocalContext.current
    val shopProfile by viewModel.shopProfile.collectAsState()
    val filteredMemos by viewModel.filteredMemos.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedTimeFilter by viewModel.selectedTimeFilter.collectAsState()
    val selectedStatusFilter by viewModel.selectedStatusFilter.collectAsState()

    // Multi-selection & Deletion States
    var isSelectionMode by remember { mutableStateOf(false) }
    var selectedMemoIds by remember { mutableStateOf(setOf<String>()) }
    var onlyPaidFilterInSelect by remember { mutableStateOf(false) }

    var memoToDeleteSingle by remember { mutableStateOf<Memo?>(null) }
    var showBulkDeleteConfirm by remember { mutableStateOf(false) }
    var isDeleting by remember { mutableStateOf(false) }

    BackHandler {
        if (isSelectionMode) {
            isSelectionMode = false
            selectedMemoIds = emptySet()
        } else {
            viewModel.navigateBack()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("memo_archive_screen")
    ) {
        AppHeader(
            title = if (isSelectionMode) "মেমো নির্বাচন (${selectedMemoIds.size})" else "মেমো আর্কাইভ ও সার্চ",
            shopProfile = shopProfile,
            showBackButton = true,
            onBackClick = {
                if (isSelectionMode) {
                    isSelectionMode = false
                    selectedMemoIds = emptySet()
                } else {
                    viewModel.navigateBack()
                }
            },
            onSettingsClick = { viewModel.navigateTo(Screen.SHOP_SETTINGS) }
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.searchQuery.value = it },
                placeholder = { Text("মেমো নং / ক্রেতার নাম / ফোন নম্বর দিয়ে খুঁজুন...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = SmartTealPrimary)
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "পরিষ্কার করুন")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("archive_search_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Time Filters
            val timeScroll = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(timeScroll),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TimeFilterChip(label = "সব", selected = selectedTimeFilter == TimeFilter.ALL) {
                    viewModel.selectedTimeFilter.value = TimeFilter.ALL
                }
                TimeFilterChip(label = "আজ", selected = selectedTimeFilter == TimeFilter.TODAY) {
                    viewModel.selectedTimeFilter.value = TimeFilter.TODAY
                }
                TimeFilterChip(label = "এই সপ্তাহ", selected = selectedTimeFilter == TimeFilter.THIS_WEEK) {
                    viewModel.selectedTimeFilter.value = TimeFilter.THIS_WEEK
                }
                TimeFilterChip(label = "এই মাস", selected = selectedTimeFilter == TimeFilter.THIS_MONTH) {
                    viewModel.selectedTimeFilter.value = TimeFilter.THIS_MONTH
                }
                TimeFilterChip(label = "এই বছর", selected = selectedTimeFilter == TimeFilter.THIS_YEAR) {
                    viewModel.selectedTimeFilter.value = TimeFilter.THIS_YEAR
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Status Filter Chips
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusFilterChip(label = "সব স্ট্যাটাস", selected = selectedStatusFilter == StatusFilter.ALL) {
                    viewModel.selectedStatusFilter.value = StatusFilter.ALL
                }
                StatusFilterChip(label = "পরিশোধিত", selected = selectedStatusFilter == StatusFilter.PAID) {
                    viewModel.selectedStatusFilter.value = StatusFilter.PAID
                }
                StatusFilterChip(label = "বাকি আছে", selected = selectedStatusFilter == StatusFilter.DUE) {
                    viewModel.selectedStatusFilter.value = StatusFilter.DUE
                }
            }
        }

        // Selection Mode Controls OR Normal Count Banner
        if (isSelectionMode) {
            Surface(
                color = Color(0xFFEFF6FF),
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    isSelectionMode = false
                                    selectedMemoIds = emptySet()
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "বন্ধ করুন", tint = SmartNavyPrimary)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${selectedMemoIds.size} টি মেমো নির্বাচিত",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = SmartNavyPrimary
                            )
                        }

                        Button(
                            onClick = { showBulkDeleteConfirm = true },
                            enabled = selectedMemoIds.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFDC2626),
                                disabledContainerColor = Color(0xFFCBD5E1)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("bulk_delete_button")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("মুছুন (${selectedMemoIds.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Quick Selection Filters Row
                    val quickScroll = rememberScrollState()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(quickScroll),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Select All / Deselect All
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White,
                            modifier = Modifier.clickable {
                                val targetPool = if (onlyPaidFilterInSelect) {
                                    filteredMemos.filter { it.dueAmount <= 0.0 }
                                } else {
                                    filteredMemos
                                }
                                selectedMemoIds = if (selectedMemoIds.size == targetPool.size && targetPool.isNotEmpty()) {
                                    emptySet()
                                } else {
                                    targetPool.map { it.id }.toSet()
                                }
                            }
                        ) {
                            Text(
                                text = if (selectedMemoIds.size == filteredMemos.size && filteredMemos.isNotEmpty()) "সব আনসিলেক্ট" else "সব নির্বাচন",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SmartTealPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        // 1 Week Older
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White,
                            modifier = Modifier.clickable {
                                val older1Week = filteredMemos.filter {
                                    val older = viewModel.isMemoOlderThanDays(it.memoDate, 7)
                                    if (onlyPaidFilterInSelect) older && it.dueAmount <= 0.0 else older
                                }.map { it.id }.toSet()
                                selectedMemoIds = selectedMemoIds + older1Week
                                if (older1Week.isEmpty()) {
                                    Toast.makeText(context, "৭ দিনের পুরোনো কোনো মেমো নেই", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Text(
                                text = "৭ দিনের পুরোনো",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SmartNavyPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        // 1 Month Older
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White,
                            modifier = Modifier.clickable {
                                val older1Month = filteredMemos.filter {
                                    val older = viewModel.isMemoOlderThanDays(it.memoDate, 30)
                                    if (onlyPaidFilterInSelect) older && it.dueAmount <= 0.0 else older
                                }.map { it.id }.toSet()
                                selectedMemoIds = selectedMemoIds + older1Month
                                if (older1Month.isEmpty()) {
                                    Toast.makeText(context, "৩০ দিনের পুরোনো কোনো মেমো নেই", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Text(
                                text = "৩০ দিনের পুরোনো",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SmartNavyPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        // Only Paid Toggle Chip
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (onlyPaidFilterInSelect) SmartTealPrimary else Color.White,
                            modifier = Modifier.clickable {
                                onlyPaidFilterInSelect = !onlyPaidFilterInSelect
                                if (onlyPaidFilterInSelect) {
                                    // Remove any already selected memos that have dues
                                    val paidIds = filteredMemos.filter { it.dueAmount <= 0.0 }.map { it.id }.toSet()
                                    selectedMemoIds = selectedMemoIds.intersect(paidIds)
                                }
                            }
                        ) {
                            Text(
                                text = if (onlyPaidFilterInSelect) "✓ শুধু পরিশোধিত" else "শুধু পরিশোধিত",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (onlyPaidFilterInSelect) Color.White else Color(0xFF0F766E),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        } else {
            // Normal Count Banner with "Select / Multiple Delete" Trigger
            Surface(
                color = Color(0xFFE2E8F0),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "মোট মেমো: ${filteredMemos.size} টি",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = SmartNavyPrimary
                        )
                        val totalFilteredAmount = filteredMemos.sumOf { it.grandTotal }
                        Text(
                            text = "মোট মূল্য: ${BengaliUtils.formatTaka(totalFilteredAmount)}",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = SmartTealPrimary
                        )
                    }

                    // Button to enter Multi-Selection / Batch Delete mode
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White,
                        modifier = Modifier
                            .clickable {
                                isSelectionMode = true
                                selectedMemoIds = emptySet()
                            }
                            .testTag("start_selection_mode_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = null,
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "একাধিক মুছুন",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFDC2626)
                            )
                        }
                    }
                }
            }
        }

        // Memos List
        if (filteredMemos.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ReceiptLong,
                    contentDescription = null,
                    tint = Color(0xFFCBD5E1),
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "কোনো মেমো পাওয়া যায়নি",
                    fontSize = 15.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Medium
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredMemos, key = { it.id }) { memo ->
                    val isSelected = memo.id in selectedMemoIds
                    ArchiveMemoCard(
                        memo = memo,
                        isSelectionMode = isSelectionMode,
                        isSelected = isSelected,
                        onToggleSelect = {
                            if (onlyPaidFilterInSelect && memo.dueAmount > 0) {
                                Toast.makeText(context, "বকেয়া মেমো নির্বাচন ফিল্টার বন্ধ রয়েছে", Toast.LENGTH_SHORT).show()
                            } else {
                                selectedMemoIds = if (isSelected) {
                                    selectedMemoIds - memo.id
                                } else {
                                    selectedMemoIds + memo.id
                                }
                            }
                        },
                        onViewClick = { viewModel.selectMemoForDetail(memo) },
                        onPrintClick = {
                            val pdf = PdfPrintGenerator.generateMemoPdf(context, memo, shopProfile)
                            PdfPrintGenerator.printPdf(context, pdf, "Memo_${memo.memoNumber}")
                        },
                        onShareClick = {
                            val pdf = PdfPrintGenerator.generateMemoPdf(context, memo, shopProfile)
                            PdfPrintGenerator.sharePdf(context, pdf)
                        },
                        onDeleteClick = {
                            memoToDeleteSingle = memo
                        }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }

    // --- Single Memo Delete Confirmation Dialog ---
    if (memoToDeleteSingle != null) {
        val targetMemo = memoToDeleteSingle!!
        AlertDialog(
            onDismissRequest = {
                if (!isDeleting) memoToDeleteSingle = null
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "মেমো মুছে ফেলা নিশ্চিত করুন",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFDC2626),
                        fontSize = 16.sp
                    )
                }
            },
            text = {
                Column {
                    Text(
                        text = "আপনি কি নিশ্চিত যে মেমো নং ${targetMemo.memoNumber} স্থায়ীভাবে মুছে ফেলতে চান?",
                        fontSize = 13.5.sp,
                        color = Color(0xFF1E293B)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ক্রেতা: ${targetMemo.customerName.ifBlank { "সাধারণ ক্রেতা" }} | তারিখ: ${targetMemo.memoDate}",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = "মোট মূল্য: ${BengaliUtils.formatTaka(targetMemo.grandTotal)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SmartNavyPrimary
                    )

                    // BOKEYA (DUE) WARNING PROTECTION
                    if (targetMemo.dueAmount > 0) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEE2E2),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "⚠️ সতর্কতা: বকেয়া পাওনা রয়েছে!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFFDC2626)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "এই মেমোতে ${BengaliUtils.formatTaka(targetMemo.dueAmount)} টাকা বাকি আছে। মেমোটি ডিলিট করলে এই ক্রেতার মোট বাকি পাওনার হিসাব ক্ষতিগ্রস্ত হতে পারে।",
                                    fontSize = 12.sp,
                                    color = Color(0xFF991B1B)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isDeleting = true
                        viewModel.deleteMemo(
                            memo = targetMemo,
                            onSuccess = {
                                isDeleting = false
                                memoToDeleteSingle = null
                                Toast.makeText(context, "মেমোটি সফলভাবে মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
                            },
                            onError = { err ->
                                isDeleting = false
                                Toast.makeText(context, "ডিলিট ব্যর্থ: $err", Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    enabled = !isDeleting,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    if (isDeleting) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text("মুছে ফেলুন")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { memoToDeleteSingle = null },
                    enabled = !isDeleting
                ) {
                    Text("বাতিল")
                }
            }
        )
    }

    // --- Bulk Memo Delete Confirmation Dialog ---
    if (showBulkDeleteConfirm) {
        val selectedMemos = filteredMemos.filter { it.id in selectedMemoIds }
        val dueMemos = selectedMemos.filter { it.dueAmount > 0 }
        val totalDueInSelected = dueMemos.sumOf { it.dueAmount }
        val totalBillInSelected = selectedMemos.sumOf { it.grandTotal }

        AlertDialog(
            onDismissRequest = {
                if (!isDeleting) showBulkDeleteConfirm = false
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.DeleteSweep,
                        contentDescription = null,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "একাধিক মেমো মুছে ফেলা",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFDC2626),
                        fontSize = 16.sp
                    )
                }
            },
            text = {
                Column {
                    Text(
                        text = "আপনি কি নিশ্চিত যে নির্বাচিত ${selectedMemos.size}টি মেমো ডেটাবেস থেকে স্থায়ীভাবে মুছে ফেলতে চান?",
                        fontSize = 13.5.sp,
                        color = Color(0xFF1E293B)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "নির্বাচিত মেমোর মোট মূল্য: ${BengaliUtils.formatTaka(totalBillInSelected)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SmartNavyPrimary
                    )

                    // BOKEYA (DUE) WARNING PROTECTION
                    if (dueMemos.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEE2E2),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "⚠️ সতর্কতা: বকেয়া মেমো অন্তর্ভুক্ত রয়েছে!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFFDC2626)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "নির্বাচিত ${selectedMemos.size}টি মেমোর মধ্যে ${dueMemos.size}টি মেমোতে মোট ${BengaliUtils.formatTaka(totalDueInSelected)} টাকা বাকি পাওনা রয়েছে। এগুলো ডিলিট করলে ক্রেতাদের বকেয়া হিসাব পরিবর্তিত হতে পারে।",
                                    fontSize = 12.sp,
                                    color = Color(0xFF991B1B)
                                )
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFDCFCE7),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "✓ নির্বাচিত সবকটি মেমো সম্পূর্ণরূপে পরিশোধিত। কোনো বকেয়া নেই।",
                                fontSize = 11.5.sp,
                                color = Color(0xFF15803D),
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isDeleting = true
                        viewModel.deleteMultipleMemos(
                            memosToDelete = selectedMemos,
                            onSuccess = { count ->
                                isDeleting = false
                                showBulkDeleteConfirm = false
                                selectedMemoIds = emptySet()
                                isSelectionMode = false
                                Toast.makeText(context, "সফলভাবে $count টি মেমো মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
                            },
                            onError = { err ->
                                isDeleting = false
                                Toast.makeText(context, "ডিলিট ব্যর্থ: $err", Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    enabled = !isDeleting,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    if (isDeleting) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text("সবগুলো মুছে ফেলুন")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showBulkDeleteConfirm = false },
                    enabled = !isDeleting
                ) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
private fun TimeFilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (selected) SmartTealPrimary else Color(0xFFF1F5F9),
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 2.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.5.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) Color.White else Color(0xFF334155),
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
        )
    }
}

@Composable
private fun StatusFilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (selected) SmartNavyPrimary else Color(0xFFF1F5F9),
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 2.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) Color.White else Color(0xFF475569),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun ArchiveMemoCard(
    memo: Memo,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onViewClick: () -> Unit,
    onPrintClick: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable {
                if (isSelectionMode) {
                    onToggleSelect()
                } else {
                    onViewClick()
                }
            },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFEFF6FF) else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isSelectionMode) {
                        Checkbox(
                            checked = isSelected,
                            onCheckedChange = { onToggleSelect() },
                            colors = CheckboxDefaults.colors(
                                checkedColor = SmartTealPrimary,
                                uncheckedColor = Color(0xFF94A3B8)
                            ),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Text(
                        text = memo.memoNumber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = SmartNavyPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFFF1F5F9)
                    ) {
                        Text(
                            text = memo.memoDate,
                            fontSize = 11.sp,
                            color = Color(0xFF64748B),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                if (memo.dueAmount > 0) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFFEE2E2)
                    ) {
                        Text(
                            text = "বাকি: ${BengaliUtils.formatTaka(memo.dueAmount)}",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFDCFCE7)
                    ) {
                        Text(
                            text = "পরিশোধিত",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF16A34A),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = memo.customerName.ifBlank { "সাধারণ ক্রেতা" },
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF0F172A)
                    )
                    if (memo.customerPhone.isNotBlank()) {
                        Text(
                            text = "☎ ${memo.customerPhone}",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "মোট বিল",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = BengaliUtils.formatTaka(memo.grandTotal),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = SmartNavyPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Card Action Buttons (when not selecting)
            if (!isSelectionMode) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onViewClick, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Visibility, contentDescription = "দেখুন", tint = SmartTealPrimary, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(onClick = onPrintClick, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Print, contentDescription = "প্রিন্ট", tint = Color(0xFF2563EB), modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(onClick = onShareClick, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Share, contentDescription = "শেয়ার", tint = Color(0xFF475569), modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    // Individual Memo Delete Button
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("delete_memo_${memo.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "মুছুন",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
