package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ShopProfile
import com.example.ui.components.AppHeader
import com.example.ui.theme.SmartNavyPrimary
import com.example.ui.theme.SmartTealPrimary
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel
import com.example.util.ImageStorageHelper
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopSettingsScreen(
    viewModel: SmartMemoViewModel
) {
    val context = LocalContext.current
    val currentProfile by viewModel.shopProfile.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    var shopName by remember(currentProfile) { mutableStateOf(currentProfile.shopName) }
    var ownerName by remember(currentProfile) { mutableStateOf(currentProfile.ownerName) }
    var address by remember(currentProfile) { mutableStateOf(currentProfile.address) }
    var phone by remember(currentProfile) { mutableStateOf(currentProfile.phone) }
    var altPhone by remember(currentProfile) { mutableStateOf(currentProfile.altPhone) }
    var email by remember(currentProfile) { mutableStateOf(currentProfile.email) }
    var shopType by remember(currentProfile) { mutableStateOf(currentProfile.shopType.ifBlank { "স্যানিটারি ও ইলেকট্রিক" }) }
    var logoPath by remember(currentProfile) { mutableStateOf(currentProfile.logoPath) }
    var shopPhotoPath by remember(currentProfile) { mutableStateOf(currentProfile.shopPhotoPath) }
    var memoNotice by remember(currentProfile) { mutableStateOf(currentProfile.memoNotice) }
    var paperSize by remember(currentProfile) { mutableStateOf(currentProfile.paperSize) }

    var shopTypeExpanded by remember { mutableStateOf(false) }

    // Photo pickers using zero-permission Android Photo Picker
    val logoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedPath = ImageStorageHelper.saveUriToInternalStorage(context, uri, "shop_logo")
            if (savedPath != null) {
                logoPath = savedPath
                Toast.makeText(context, "লোগো নির্বাচন সম্পন্ন হয়েছে", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val shopPhotoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedPath = ImageStorageHelper.saveUriToInternalStorage(context, uri, "shop_photo")
            if (savedPath != null) {
                shopPhotoPath = savedPath
                Toast.makeText(context, "দোকানের ছবি নির্বাচন সম্পন্ন হয়েছে", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val highContrastColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFF000000),
        unfocusedTextColor = Color(0xFF000000),
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White,
        focusedLabelColor = Color(0xFF111111),
        unfocusedLabelColor = Color(0xFF111111),
        focusedPlaceholderColor = Color(0xFF333333),
        unfocusedPlaceholderColor = Color(0xFF333333),
        focusedBorderColor = SmartTealPrimary,
        unfocusedBorderColor = Color(0xFF475569)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FB))
            .testTag("shop_settings_screen")
    ) {
        AppHeader(
            title = "দোকানের সেটিংস",
            shopProfile = currentProfile,
            showBackButton = true,
            onBackClick = { viewModel.navigateBack() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Section 1: Logo & Outlet Profile Photo Card (Matching Reference Infographic)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "দোকানের তথ্য, লোগো ও প্রোফাইল ছবি",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = SmartNavyPrimary,
                            modifier = Modifier.align(Alignment.Start)
                        )

                        // Logo preview & change button
                        Box(
                            contentAlignment = Alignment.BottomEnd,
                            modifier = Modifier.size(90.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFF1F5F9),
                                border = androidx.compose.foundation.BorderStroke(2.dp, SmartTealPrimary),
                                modifier = Modifier.size(90.dp)
                            ) {
                                if (logoPath.isNotBlank() && File(logoPath).exists()) {
                                    AsyncImage(
                                        model = File(logoPath),
                                        contentDescription = "দোকানের লোগো",
                                        modifier = Modifier.fillMaxSize().clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                        Icon(
                                            Icons.Default.Storefront,
                                            contentDescription = null,
                                            tint = SmartTealPrimary,
                                            modifier = Modifier.size(44.dp)
                                        )
                                    }
                                }
                            }

                            // Edit icon on logo
                            Surface(
                                shape = CircleShape,
                                color = SmartNavyPrimary,
                                shadowElevation = 2.dp,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clickable {
                                        logoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.CameraAlt,
                                        contentDescription = "লোগো নির্বাচন",
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    logoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (logoPath.isBlank()) "লোগো যোগ করুন" else "লোগো পরিবর্তন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            if (logoPath.isNotBlank()) {
                                OutlinedButton(
                                    onClick = { logoPath = "" },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("মুছুন", color = Color(0xFFDC2626), fontSize = 12.sp)
                                }
                            }
                        }

                        // Shop Profile Photo (Optional store picture)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF8FAFC), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "দোকানের প্রোফাইল ছবি (ঐচ্ছিক)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SmartNavyPrimary
                                )
                                Text(
                                    text = if (shopPhotoPath.isNotBlank()) "ছবি সংযুক্ত আছে" else "দোকানের আউটলেটের ছবি যুক্ত করতে পারেন",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (shopPhotoPath.isNotBlank() && File(shopPhotoPath).exists()) {
                                    AsyncImage(
                                        model = File(shopPhotoPath),
                                        contentDescription = "দোকানের ছবি",
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(6.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                    IconButton(onClick = { shopPhotoPath = "" }) {
                                        Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = Color(0xFFDC2626))
                                    }
                                } else {
                                    OutlinedButton(
                                        onClick = {
                                            shopPhotoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("ছবি যোগ", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 2: Shop Details Form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Business, contentDescription = null, tint = SmartTealPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "দোকানের মূল পরিচিতি",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = SmartNavyPrimary
                            )
                        }

                        // Shop Type Dropdown (Matching Infographic Item 1)
                        ExposedDropdownMenuBox(
                            expanded = shopTypeExpanded,
                            onExpandedChange = { shopTypeExpanded = !shopTypeExpanded }
                        ) {
                            OutlinedTextField(
                                value = shopType,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("দোকানের ধরন *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = shopTypeExpanded) },
                                colors = highContrastColors,
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = shopTypeExpanded,
                                onDismissRequest = { shopTypeExpanded = false }
                            ) {
                                val shopTypes = listOf(
                                    "স্যানিটারি ও ইলেকট্রিক",
                                    "মুদি দোকান",
                                    "কাপড়ের দোকান / পোশাক",
                                    "ফার্মেসি",
                                    "কসমেটিকস",
                                    "হার্ডওয়্যার",
                                    "সাধারণ / অন্যান্য"
                                )
                                shopTypes.forEach { type ->
                                    DropdownMenuItem(
                                        text = { Text(type, fontSize = 13.5.sp, fontWeight = FontWeight.Medium) },
                                        onClick = {
                                            shopType = type
                                            shopTypeExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = shopName,
                            onValueChange = { shopName = it },
                            label = { Text("দোকানের নাম *") },
                            singleLine = true,
                            colors = highContrastColors,
                            modifier = Modifier.fillMaxWidth().testTag("settings_shop_name_input")
                        )

                        OutlinedTextField(
                            value = ownerName,
                            onValueChange = { ownerName = it },
                            label = { Text("প্রোপাইটর / মালিকের নাম") },
                            singleLine = true,
                            colors = highContrastColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text("দোকানের ঠিকানা *") },
                            singleLine = true,
                            colors = highContrastColors,
                            modifier = Modifier.fillMaxWidth().testTag("settings_address_input")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("প্রধান মোবাইল নম্বর *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                colors = highContrastColors,
                                modifier = Modifier.weight(1f).testTag("settings_phone_input")
                            )
                            OutlinedTextField(
                                value = altPhone,
                                onValueChange = { altPhone = it },
                                label = { Text("বিকল্প নম্বর") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                colors = highContrastColors,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("ইমেইল (ঐচ্ছিক)") },
                            singleLine = true,
                            colors = highContrastColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Section 3: Memo Design Studio Banner Button (Entry point to Studio)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(Screen.MEMO_DESIGN_STUDIO) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2B48)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = SmartTealPrimary,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Palette, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "মেমো ডিজাইন স্টুডিও",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "কাস্টম রং, প্রিসেট ডিজাইন, লোগো ও লেআউট নিয়ন্ত্রণ",
                                fontSize = 11.5.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                        Button(
                            onClick = { viewModel.navigateTo(Screen.MEMO_DESIGN_STUDIO) },
                            colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("প্রবেশ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Section 4: Paper & Print Notice Settings
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Print, contentDescription = null, tint = SmartTealPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "মেমো ও প্রিন্ট সেটিংস",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = SmartNavyPrimary
                            )
                        }

                        OutlinedTextField(
                            value = memoNotice,
                            onValueChange = { memoNotice = it },
                            label = { Text("মেমোর নিচের ধন্যবাদ / শুভেচ্ছা বার্তা") },
                            singleLine = true,
                            colors = highContrastColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Paper Size Selector
                        Text("কাগজের সাইজ নির্বাচন:", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = SmartNavyPrimary)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf("A4" to "A4 সাইজ (পূর্ণাঙ্গ)", "POS_80" to "৮০মিমি থার্মাল", "SMALL" to "ছোট মেমো প্যাড").forEach { (code, label) ->
                                val selected = (paperSize == code)
                                Button(
                                    onClick = { paperSize = code },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) SmartNavyPrimary else Color(0xFFF1F5F9),
                                        contentColor = if (selected) Color.White else Color(0xFF334155)
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                                ) {
                                    Text(label, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                                }
                            }
                        }
                    }
                }
            }

            // Save Button
            item {
                Button(
                    onClick = {
                        if (shopName.isNotBlank() && phone.isNotBlank()) {
                            viewModel.updateShopProfile(
                                currentProfile.copy(
                                    shopName = shopName.trim(),
                                    ownerName = ownerName.trim(),
                                    address = address.trim(),
                                    phone = phone.trim(),
                                    altPhone = altPhone.trim(),
                                    email = email.trim(),
                                    shopType = shopType,
                                    logoPath = logoPath,
                                    shopPhotoPath = shopPhotoPath,
                                    memoNotice = memoNotice.trim(),
                                    paperSize = paperSize
                                )
                            )
                            Toast.makeText(context, "দোকানের তথ্য সফলভাবে সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                            viewModel.navigateBack()
                        } else {
                            Toast.makeText(context, "দয়া করে দোকানের নাম ও মোবাইল নম্বর পূরণ করুন", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SmartTealPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_settings_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("তথ্য সংরক্ষণ করুন", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}
