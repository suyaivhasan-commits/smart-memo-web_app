package com.example.util

import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BengaliUtils {

    private val banglaDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    fun toBanglaDigits(numberStr: String): String {
        val sb = StringBuilder()
        for (ch in numberStr) {
            if (ch in '0'..'9') {
                sb.append(banglaDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toEnglishDigits(numberStr: String): String {
        val sb = StringBuilder()
        for (ch in numberStr) {
            val idx = banglaDigits.indexOf(ch)
            if (idx >= 0) {
                sb.append(idx)
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun formatTaka(amount: Double, inBangla: Boolean = false): String {
        val formatter = DecimalFormat("#,##,##0.##")
        val formatted = formatter.format(amount)
        return if (inBangla) {
            "৳ " + toBanglaDigits(formatted)
        } else {
            "৳ $formatted"
        }
    }

    fun formatNumber(number: Double, inBangla: Boolean = false): String {
        val formatter = DecimalFormat("#,##,##0.##")
        val formatted = formatter.format(number)
        return if (inBangla) toBanglaDigits(formatted) else formatted
    }

    fun parseNumber(str: String?): Double {
        if (str.isNullOrBlank()) return 0.0
        val englishStr = toEnglishDigits(str).replace(",", "").trim()
        return englishStr.toDoubleOrNull() ?: 0.0
    }

    fun formatCleanNumber(num: Double): String {
        return if (num % 1.0 == 0.0) {
            num.toLong().toString()
        } else {
            DecimalFormat("0.##").format(num)
        }
    }

    fun getCurrentDateStr(): String {
        val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
        return sdf.format(Date())
    }

    fun generateNextMemoNumber(existingCount: Int): String {
        val next = existingCount + 1
        return String.format(Locale.US, "#%04d", next)
    }
}

