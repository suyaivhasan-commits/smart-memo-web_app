package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Memo
import com.example.data.model.MemoDesignConfig
import com.example.data.model.ShopProfile
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream

object PdfPrintGenerator {

    private const val PAGE_WIDTH = 595 // Standard A4 width in points
    private const val PAGE_HEIGHT = 842 // Standard A4 height in points
    private const val ITEMS_PER_PAGE = 25

    fun generateMemoPdf(context: Context, memo: Memo, profile: ShopProfile): File {
        val pdfDocument = PdfDocument()

        val items = memo.items.filter { it.productName.isNotBlank() }
        val effectiveItems = if (items.isEmpty()) memo.items else items
        val totalPages = ((effectiveItems.size - 1) / ITEMS_PER_PAGE + 1).coerceAtLeast(1)

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val startIdx = pageIndex * ITEMS_PER_PAGE
            val endIdx = (startIdx + ITEMS_PER_PAGE).coerceAtMost(effectiveItems.size)
            val pageItems = effectiveItems.subList(startIdx, endIdx)

            drawMemoPage(
                canvas = canvas,
                memo = memo,
                profile = profile,
                pageItems = pageItems,
                pageIndex = pageIndex,
                totalPages = totalPages,
                isFinalPage = (pageIndex == totalPages - 1)
            )

            pdfDocument.finishPage(page)
        }

        val safeCustomerName = memo.customerName.replace(Regex("[^a-zA-Z0-9\\u0980-\\u09FF]"), "_").take(15)
        val safeMemoNo = memo.memoNumber.replace("#", "")
        val fileName = "Memo_${safeMemoNo}_${if (safeCustomerName.isBlank()) "Customer" else safeCustomerName}.pdf"
        val outputFile = File(context.cacheDir, fileName)

        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        return outputFile
    }

    fun generateMemoBitmap(memo: Memo, profile: ShopProfile, pageIndex: Int = 0): Bitmap {
        val bitmap = Bitmap.createBitmap(PAGE_WIDTH, PAGE_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val items = memo.items.filter { it.productName.isNotBlank() }
        val effectiveItems = if (items.isEmpty()) memo.items else items
        val totalPages = ((effectiveItems.size - 1) / ITEMS_PER_PAGE + 1).coerceAtLeast(1)

        val startIdx = (pageIndex * ITEMS_PER_PAGE).coerceAtMost(effectiveItems.size)
        val endIdx = (startIdx + ITEMS_PER_PAGE).coerceAtMost(effectiveItems.size)
        val pageItems = if (startIdx < endIdx) effectiveItems.subList(startIdx, endIdx) else emptyList()

        drawMemoPage(
            canvas = canvas,
            memo = memo,
            profile = profile,
            pageItems = pageItems,
            pageIndex = pageIndex,
            totalPages = totalPages,
            isFinalPage = (pageIndex == totalPages - 1)
        )

        return bitmap
    }

    private fun drawMemoPage(
        canvas: Canvas,
        memo: Memo,
        profile: ShopProfile,
        pageItems: List<com.example.data.model.MemoItem>,
        pageIndex: Int,
        totalPages: Int,
        isFinalPage: Boolean
    ) {
        val design = if (memo.designConfig.presetId.isNotBlank() && memo.designConfig != MemoDesignConfig()) {
            memo.designConfig
        } else {
            profile.memoDesign
        }

        val colorPrimary = parseHexColorInt(design.primaryColorHex, 0xFF0F2B48.toInt())
        val colorSecondary = parseHexColorInt(design.secondaryColorHex, 0xFF00897B.toInt())
        val colorBgHeader = parseHexColorInt(design.tableHeaderBgHex, 0xFFF1F5F9.toInt())
        val colorBorder = parseHexColorInt(design.tableLineColorHex, 0xFF334155.toInt())

        val colorTextPrimary = 0xFF0F172A.toInt()
        val colorTextSecondary = 0xFF1E293B.toInt()
        val colorMuted = 0xFF64748B.toInt()
        val colorBgZebra = 0xFFF8FAFC.toInt()
        val colorHighlight = 0xFFE2E8F0.toInt()
        val colorFaint = 0xFFCBD5E1.toInt()

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), bgPaint)

        // Outer Border
        val borderPaint = Paint().apply {
            color = colorPrimary
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRect(20f, 20f, PAGE_WIDTH - 20f, PAGE_HEIGHT - 20f, borderPaint)

        // Inner Border (Classic Bengali Cash Memo look)
        val innerBorderPaint = Paint().apply {
            color = colorPrimary
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        canvas.drawRect(23f, 23f, PAGE_WIDTH - 23f, PAGE_HEIGHT - 23f, innerBorderPaint)

        // Shop Header Information
        val shopName = if (memo.shopNameSnapshot.isNotBlank()) memo.shopNameSnapshot else profile.shopName
        val shopOwner = if (memo.shopOwnerSnapshot.isNotBlank()) memo.shopOwnerSnapshot else profile.ownerName
        val shopAddr = if (memo.shopAddressSnapshot.isNotBlank()) memo.shopAddressSnapshot else profile.address
        val shopPhone = if (memo.shopPhoneSnapshot.isNotBlank()) memo.shopPhoneSnapshot else profile.phone

        val logoPath = memo.shopLogoSnapshot.ifBlank { profile.logoPath }
        val hasLogo = design.showLogo && logoPath.isNotBlank() && File(logoPath).exists()

        // Draw Shop Logo if enabled and present
        if (hasLogo) {
            val logoBmp = ImageStorageHelper.loadBitmapFromPath(logoPath, maxDimension = 120)
            if (logoBmp != null) {
                val logoSizePt = when (design.logoSize) {
                    "SMALL" -> 36f
                    "LARGE" -> 50f
                    else -> 42f
                }

                val logoX = when (design.logoPosition) {
                    "CENTER" -> (PAGE_WIDTH / 2f) - (logoSizePt / 2f)
                    "RIGHT" -> PAGE_WIDTH - 35f - logoSizePt
                    else -> 35f
                }

                val logoY = if (design.logoPosition == "CENTER") 28f else 36f
                val destRect = RectF(logoX, logoY, logoX + logoSizePt, logoY + logoSizePt)

                canvas.drawBitmap(logoBmp, null, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
                // Draw delicate circle or rounded border around logo
                val logoBorderPaint = Paint().apply {
                    color = colorSecondary
                    style = Paint.Style.STROKE
                    strokeWidth = 1f
                }
                canvas.drawRoundRect(destRect, 6f, 6f, logoBorderPaint)
            }
        }

        // Paints for text
        val titlePaint = Paint().apply {
            color = colorPrimary
            textSize = 19f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        val textPaint = Paint().apply {
            color = colorTextSecondary
            textSize = 10f
            textAlign = Paint.Align.CENTER
        }

        val centerX = PAGE_WIDTH / 2f
        val startHeaderY = if (hasLogo && design.logoPosition == "CENTER") 78f else 46f

        canvas.drawText(shopName, centerX, startHeaderY, titlePaint)
        if (shopOwner.isNotBlank()) {
            val ownerPaint = Paint().apply {
                color = colorTextPrimary
                textSize = 10f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("প্রোপ্রাইটর: $shopOwner", centerX, startHeaderY + 14f, ownerPaint)
            canvas.drawText(shopAddr, centerX, startHeaderY + 26f, textPaint)
            canvas.drawText("মোবাইল: $shopPhone", centerX, startHeaderY + 38f, textPaint)
        } else {
            canvas.drawText(shopAddr, centerX, startHeaderY + 14f, textPaint)
            canvas.drawText("মোবাইল: $shopPhone", centerX, startHeaderY + 26f, textPaint)
        }

        // Cash Memo Pill Badge
        val badgeY = if (shopOwner.isNotBlank()) startHeaderY + 44f else startHeaderY + 34f
        val headerFillPaint = Paint().apply {
            color = colorSecondary
            style = Paint.Style.FILL
        }
        val badgeRect = RectF(centerX - 55f, badgeY, centerX + 55f, badgeY + 17f)
        canvas.drawRoundRect(badgeRect, 6f, 6f, headerFillPaint)
        val badgeTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 10.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("বিক্রয় মেমো", centerX, badgeY + 12f, badgeTextPaint)

        // Page Indicator if multi-page
        if (totalPages > 1) {
            val pageTextPaint = Paint().apply {
                color = colorPrimary
                textSize = 9.5f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText("পৃষ্ঠা ${pageIndex + 1} / $totalPages", PAGE_WIDTH - 30f, 42f, pageTextPaint)
        }

        // Top Banner Studio Image if configured
        val studioImagePath = design.studioImagePath.ifBlank { profile.memoDesign.studioImagePath }
        val hasStudioImage = design.showStudioImage && studioImagePath.isNotBlank() && File(studioImagePath).exists()
        var currentTopOffset = badgeY + 22f

        if (hasStudioImage && design.studioImagePosition == "TOP_BANNER") {
            val bannerBmp = ImageStorageHelper.loadBitmapFromPath(studioImagePath, maxDimension = 300)
            if (bannerBmp != null) {
                val bannerH = when (design.studioImageSize) {
                    "SMALL" -> 35f
                    "LARGE" -> 60f
                    else -> 46f
                }
                val bannerW = PAGE_WIDTH - 64f
                val bannerRect = RectF(32f, currentTopOffset, 32f + bannerW, currentTopOffset + bannerH)
                canvas.drawBitmap(bannerBmp, null, bannerRect, Paint(Paint.FILTER_BITMAP_FLAG))
                val bannerBorder = Paint().apply {
                    color = colorSecondary
                    style = Paint.Style.STROKE
                    strokeWidth = 0.8f
                }
                canvas.drawRoundRect(bannerRect, 4f, 4f, bannerBorder)
                currentTopOffset += bannerH + 6f
            }
        }

        // Customer & Memo Metadata Bar
        val metaY = currentTopOffset + 10f
        val boldTextPaint = Paint().apply {
            color = colorPrimary
            textSize = 10.5f
            isFakeBoldText = true
            textAlign = Paint.Align.LEFT
        }
        canvas.drawText("মেমো নং: ${memo.memoNumber}", 32f, metaY, boldTextPaint)

        val datePaint = Paint(boldTextPaint).apply { textAlign = Paint.Align.RIGHT }
        val dateText = if (memo.memoDate.isNotBlank()) memo.memoDate else BengaliUtils.getCurrentDateStr()
        canvas.drawText("তারিখ: $dateText", PAGE_WIDTH - 32f, metaY, datePaint)

        canvas.drawText("ক্রেতার নাম: ${if (memo.customerName.isNotBlank()) memo.customerName else "—"}", 32f, metaY + 15f, boldTextPaint)
        canvas.drawText("মোবাইল: ${if (memo.customerPhone.isNotBlank()) memo.customerPhone else "—"}", PAGE_WIDTH - 32f, metaY + 15f, datePaint)

        if (memo.customerAddress.isNotBlank()) {
            val addrPaint = Paint(textPaint).apply { textAlign = Paint.Align.LEFT; textSize = 9.5f }
            canvas.drawText("ঠিকানা: ${memo.customerAddress}", 32f, metaY + 28f, addrPaint)
        }

        // --- Table ---
        val tableTop = metaY + (if (memo.customerAddress.isNotBlank()) 38f else 25f)
        val tableLeft = 28f
        val tableRight = PAGE_WIDTH - 28f
        val colNo = 58f
        val colName = 310f
        val colQty = 370f
        val colUnit = 420f
        val colRate = 485f

        val tableLinePaint = Paint().apply {
            color = colorBorder
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }

        // Table Header Fill
        val thPaint = Paint().apply {
            color = colorBgHeader
            style = Paint.Style.FILL
        }
        canvas.drawRect(tableLeft, tableTop, tableRight, tableTop + 20f, thPaint)
        canvas.drawRect(tableLeft, tableTop, tableRight, tableTop + 20f, tableLinePaint)

        val thTextPaint = Paint().apply {
            color = colorPrimary
            textSize = 9.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("নং", (tableLeft + colNo) / 2f, tableTop + 14f, thTextPaint)
        canvas.drawText("পণ্যের বিবরণ", (colNo + colName) / 2f, tableTop + 14f, thTextPaint)
        canvas.drawText("পরিমাণ", (colName + colQty) / 2f, tableTop + 14f, thTextPaint)
        canvas.drawText("একক", (colQty + colUnit) / 2f, tableTop + 14f, thTextPaint)
        canvas.drawText("দর (টাকা)", (colUnit + colRate) / 2f, tableTop + 14f, thTextPaint)
        canvas.drawText("মোট টাকা", (colRate + tableRight) / 2f, tableTop + 14f, thTextPaint)

        // Draw Row Lines for 25 items
        val rowHeight = 17.5f
        val maxRows = ITEMS_PER_PAGE
        val currentY = tableTop + 20f

        val cellTextPaint = Paint().apply {
            color = colorTextPrimary
            textSize = 9f
        }

        for (i in 0 until maxRows) {
            val item = pageItems.getOrNull(i)
            val yPos = currentY + (i * rowHeight)
            val textBase = yPos + 12.5f

            // Zebra striping subtle background
            if (i % 2 == 1) {
                val rowBgPaint = Paint().apply { color = colorBgZebra }
                canvas.drawRect(tableLeft, yPos, tableRight, yPos + rowHeight, rowBgPaint)
            }

            // Row Bottom Line
            canvas.drawLine(tableLeft, yPos + rowHeight, tableRight, yPos + rowHeight, tableLinePaint)

            if (item != null && item.productName.isNotBlank()) {
                // Serial
                cellTextPaint.textAlign = Paint.Align.CENTER
                canvas.drawText(item.serial.toString(), (tableLeft + colNo) / 2f, textBase, cellTextPaint)

                // Name
                cellTextPaint.textAlign = Paint.Align.LEFT
                val safeName = if (item.productName.length > 34) item.productName.take(32) + ".." else item.productName
                canvas.drawText(safeName, colNo + 4f, textBase, cellTextPaint)

                // Quantity
                cellTextPaint.textAlign = Paint.Align.CENTER
                canvas.drawText(BengaliUtils.formatCleanNumber(item.quantity), (colName + colQty) / 2f, textBase, cellTextPaint)

                // Unit
                canvas.drawText(item.unit, (colQty + colUnit) / 2f, textBase, cellTextPaint)

                // Rate
                cellTextPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText(BengaliUtils.formatNumber(item.unitPrice), colRate - 4f, textBase, cellTextPaint)

                // Total
                canvas.drawText(BengaliUtils.formatNumber(item.totalPrice), tableRight - 4f, textBase, cellTextPaint)
            } else if (item == null) {
                // Empty row serial placeholder
                val emptySerial = (pageIndex * ITEMS_PER_PAGE) + i + 1
                val faintPaint = Paint(cellTextPaint).apply { color = colorFaint; textAlign = Paint.Align.CENTER }
                canvas.drawText(emptySerial.toString(), (tableLeft + colNo) / 2f, textBase, faintPaint)
            }
        }

        val tableBottom = currentY + (maxRows * rowHeight)

        // Draw Vertical Grid Lines
        canvas.drawLine(tableLeft, tableTop, tableLeft, tableBottom, tableLinePaint)
        canvas.drawLine(colNo, tableTop, colNo, tableBottom, tableLinePaint)
        canvas.drawLine(colName, tableTop, colName, tableBottom, tableLinePaint)
        canvas.drawLine(colQty, tableTop, colQty, tableBottom, tableLinePaint)
        canvas.drawLine(colUnit, tableTop, colUnit, tableBottom, tableLinePaint)
        canvas.drawLine(colRate, tableTop, colRate, tableBottom, tableLinePaint)
        canvas.drawLine(tableRight, tableTop, tableRight, tableBottom, tableLinePaint)

        // --- Bottom Summary & Product Images ---
        var summaryY = tableBottom + 10f

        if (isFinalPage) {
            // Draw Below Table Studio Image if configured
            if (hasStudioImage && design.studioImagePosition == "BELOW_TABLE") {
                val belowBmp = ImageStorageHelper.loadBitmapFromPath(studioImagePath, maxDimension = 260)
                if (belowBmp != null) {
                    val imgH = when (design.studioImageSize) {
                        "SMALL" -> 32f
                        "LARGE" -> 56f
                        else -> 42f
                    }
                    val imgW = PAGE_WIDTH - 64f
                    val belowRect = RectF(32f, summaryY, 32f + imgW, summaryY + imgH)
                    canvas.drawBitmap(belowBmp, null, belowRect, Paint(Paint.FILTER_BITMAP_FLAG))
                    val borderPaint = Paint().apply {
                        color = colorBorder
                        style = Paint.Style.STROKE
                        strokeWidth = 0.6f
                    }
                    canvas.drawRoundRect(belowRect, 3f, 3f, borderPaint)
                    summaryY += imgH + 8f
                }
            }
            // Draw Attached Product Photos if enabled
            val showPhotos = design.showProductImages && memo.productImages.isNotEmpty()
            if (showPhotos) {
                val photoSize = 36f
                val photoSpacing = 6f
                val maxPhotos = if (design.productImagesPosition == "BESIDE_TOTALS") 3 else 5
                val photosToDraw = memo.productImages.take(maxPhotos)

                val photoStartX = 35f
                val photoStartY = if (design.productImagesPosition == "BESIDE_TOTALS") summaryY + 10f else summaryY

                val labelPaint = Paint().apply {
                    color = colorPrimary
                    textSize = 8.5f
                    isFakeBoldText = true
                }
                canvas.drawText("পণ্যের ছবি:", photoStartX, photoStartY, labelPaint)

                var curX = photoStartX
                val imgDrawY = photoStartY + 4f

                photosToDraw.forEach { path ->
                    val bmp = ImageStorageHelper.loadBitmapFromPath(path, maxDimension = 100)
                    if (bmp != null) {
                        val rect = RectF(curX, imgDrawY, curX + photoSize, imgDrawY + photoSize)
                        canvas.drawBitmap(bmp, null, rect, Paint(Paint.FILTER_BITMAP_FLAG))
                        canvas.drawRoundRect(rect, 3f, 3f, tableLinePaint)
                        curX += photoSize + photoSpacing
                    }
                }

                if (design.productImagesPosition == "BELOW_TABLE") {
                    summaryY += photoSize + 12f
                }
            }

            // Draw Totals Box on Right
            val sumBoxLeft = colQty - 20f
            val sumBoxRight = tableRight
            val sumRowH = 15f

            val sumLabelPaint = Paint().apply {
                color = colorPrimary
                textSize = 9f
                isFakeBoldText = true
                textAlign = Paint.Align.LEFT
            }

            val sumValPaint = Paint().apply {
                color = colorTextPrimary
                textSize = 9f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }

            fun drawSummaryRow(label: String, value: Double, y: Float, highlight: Boolean = false) {
                if (highlight) {
                    val hBg = Paint().apply { color = colorBgHeader }
                    canvas.drawRect(sumBoxLeft, y, sumBoxRight, y + sumRowH, hBg)
                }
                canvas.drawRect(sumBoxLeft, y, sumBoxRight, y + sumRowH, tableLinePaint)
                canvas.drawText(label, sumBoxLeft + 6f, y + 11f, sumLabelPaint)
                canvas.drawText(BengaliUtils.formatTaka(value), sumBoxRight - 6f, y + 11f, sumValPaint)
            }

            drawSummaryRow("মোট পণ্য মূল্য:", memo.subtotal, summaryY)
            if (memo.discount > 0.0) {
                drawSummaryRow("ছাড়:", memo.discount, summaryY + sumRowH)
                summaryY += sumRowH
            }
            if (memo.extraCharges > 0.0) {
                drawSummaryRow("অতিরিক্ত চার্জ:", memo.extraCharges, summaryY + sumRowH)
                summaryY += sumRowH
            }
            drawSummaryRow("সর্বমোট বিল:", memo.grandTotal, summaryY + sumRowH, highlight = true)
            drawSummaryRow("জমা টাকা:", memo.paidAmount, summaryY + (sumRowH * 2))
            drawSummaryRow("বাকি টাকা:", memo.dueAmount, summaryY + (sumRowH * 3))

            // Notice / Note on Bottom Left
            val noticeText = if (memo.memoNoticeSnapshot.isNotBlank()) memo.memoNoticeSnapshot else profile.memoNotice
            val noticePaint = Paint().apply {
                color = colorSecondary
                textSize = 9.5f
                isFakeBoldText = true
                textAlign = Paint.Align.LEFT
            }
            canvas.drawText(noticeText, 35f, summaryY + 28f, noticePaint)

            val inWordsPaint = Paint().apply {
                color = colorMuted
                textSize = 8.5f
                textAlign = Paint.Align.LEFT
            }
            canvas.drawText("পেমেন্ট পদ্ধতি: ${memo.paymentType}", 35f, summaryY + 41f, inWordsPaint)

            // Draw Beside Totals Studio Image if configured
            if (hasStudioImage && design.studioImagePosition == "BESIDE_TOTALS") {
                val besideBmp = ImageStorageHelper.loadBitmapFromPath(studioImagePath, maxDimension = 180)
                if (besideBmp != null) {
                    val imgH = when (design.studioImageSize) {
                        "SMALL" -> 32f
                        "LARGE" -> 52f
                        else -> 40f
                    }
                    val imgW = 85f
                    val besideRect = RectF(35f, summaryY + 48f, 35f + imgW, summaryY + 48f + imgH)
                    canvas.drawBitmap(besideBmp, null, besideRect, Paint(Paint.FILTER_BITMAP_FLAG))
                    val borderPaint = Paint().apply {
                        color = colorBorder
                        style = Paint.Style.STROKE
                        strokeWidth = 0.6f
                    }
                    canvas.drawRoundRect(besideRect, 3f, 3f, borderPaint)
                }
            }
        } else {
            // "চলমান..." text on continuation pages
            val contPaint = Paint().apply {
                color = colorPrimary
                textSize = 10.5f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText("পরবর্তী পৃষ্ঠায় চলমান... ->", tableRight - 10f, summaryY + 15f, contPaint)
        }

        // --- Signature Lines ---
        val sigY = PAGE_HEIGHT - 45f
        val sigLinePaint = Paint().apply {
            color = colorBorder
            strokeWidth = 0.8f
        }
        val sigTextPaint = Paint().apply {
            color = colorTextPrimary
            textSize = 9.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        // Customer Signature
        canvas.drawLine(35f, sigY, 140f, sigY, sigLinePaint)
        canvas.drawText("ক্রেতার স্বাক্ষর", 87.5f, sigY + 12f, sigTextPaint)

        // Slogan in Center
        val sloganPaint = Paint().apply {
            color = colorPrimary
            textSize = 10f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("আপনার আস্থাই আমাদের সফলতা", PAGE_WIDTH / 2f, sigY + 8f, sloganPaint)

        // Seller Signature
        canvas.drawLine(PAGE_WIDTH - 140f, sigY, PAGE_WIDTH - 35f, sigY, sigLinePaint)
        canvas.drawText("বিক্রেতার স্বাক্ষর", PAGE_WIDTH - 87.5f, sigY + 12f, sigTextPaint)
    }

    private fun parseHexColorInt(hex: String, defaultColor: Int): Int {
        return try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            defaultColor
        }
    }

    fun sharePdf(context: Context, pdfFile: File) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "মেমো PDF শেয়ার করুন"))
    }

    fun shareBitmap(context: Context, bitmap: Bitmap, memoNumber: String) {
        val file = File(context.cacheDir, "Memo_${memoNumber.replace("#", "")}.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "মেমোর ছবি শেয়ার করুন"))
    }

    fun saveBitmapToGallery(context: Context, bitmap: Bitmap, memoNumber: String) {
        val filename = "SmartMemo_${memoNumber.replace("#", "")}_${System.currentTimeMillis()}.png"
        var outputStream: OutputStream? = null
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/SmartMemo")
                }
                val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (imageUri != null) {
                    outputStream = resolver.openOutputStream(imageUri)
                }
            } else {
                val imagesDir = File(context.getExternalFilesDir(null), "Pictures")
                if (!imagesDir.exists()) imagesDir.mkdirs()
                val image = File(imagesDir, filename)
                outputStream = FileOutputStream(image)
            }

            outputStream?.let {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                it.flush()
                Toast.makeText(context, "মেমোর ছবি সফলভাবে সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "সংরক্ষণ করতে সমস্যা হয়েছে: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            outputStream?.close()
        }
    }

    fun printPdf(context: Context, pdfFile: File, jobName: String = "Print Memo") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (printManager == null) {
            Toast.makeText(context, "প্রিন্ট সেবা উপলব্ধ নেই", Toast.LENGTH_SHORT).show()
            return
        }

        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("$jobName.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                var input: FileInputStream? = null
                var output: FileOutputStream? = null
                try {
                    input = FileInputStream(pdfFile)
                    output = FileOutputStream(destination?.fileDescriptor)
                    val buf = ByteArray(1024)
                    var bytesRead: Int
                    while (input.read(buf).also { bytesRead = it } > 0) {
                        if (cancellationSignal?.isCanceled == true) {
                            callback?.onWriteCancelled()
                            return
                        }
                        output.write(buf, 0, bytesRead)
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    input?.close()
                    output?.close()
                }
            }
        }

        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    }
}
