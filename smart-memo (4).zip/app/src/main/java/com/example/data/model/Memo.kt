package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Memo(
    @DocumentId val id: String = "",
    val userId: String = "",
    val memoNumber: String = "#0001",
    val memoDate: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val customerAddress: String = "",
    val paymentType: String = "নগদ",
    val items: List<MemoItem> = emptyList(),
    val subtotal: Double = 0.0,
    val discount: Double = 0.0,
    val extraCharges: Double = 0.0,
    val grandTotal: Double = 0.0,
    val paidAmount: Double = 0.0,
    val dueAmount: Double = 0.0,
    val shopNameSnapshot: String = "",
    val shopOwnerSnapshot: String = "",
    val shopAddressSnapshot: String = "",
    val shopPhoneSnapshot: String = "",
    val shopLogoSnapshot: String = "",
    val shopPhotoSnapshot: String = "",
    val memoNoticeSnapshot: String = "ধন্যবাদ, আবার আসবেন",
    val designConfig: MemoDesignConfig = MemoDesignConfig(),
    val productImages: List<String> = emptyList(),
    val pageCount: Int = 1,
    val isDeleted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
