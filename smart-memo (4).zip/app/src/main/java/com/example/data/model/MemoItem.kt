package com.example.data.model

import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
data class MemoItem(
    val serial: Int = 1,
    val productName: String = "",
    val quantity: Double = 1.0,
    val unit: String = "পিস",
    val unitPrice: Double = 0.0,
    val totalPrice: Double = 0.0,
    val quantityStr: String = "1",
    val unitPriceStr: String = ""
)
