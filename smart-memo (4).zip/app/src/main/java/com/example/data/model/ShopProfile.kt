package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class ShopProfile(
    @DocumentId val id: String = "info",
    val userId: String = "",
    val shopName: String = "মেসার্স আল-আমিন ট্রেডার্স",
    val ownerName: String = "মোঃ আব্দুল করিম",
    val address: String = "১২০, বাজার রোড, রাজশাহী",
    val phone: String = "০১৭১২-০৪৬৫৭৮",
    val altPhone: String = "",
    val email: String = "",
    val memoNotice: String = "ধন্যবাদ, আবার আসবেন",
    val paperSize: String = "A4",
    val designStyle: String = "STANDARD",
    val shopType: String = "স্যানিটারি ও ইলেকট্রিক",
    val logoPath: String = "",
    val shopPhotoPath: String = "",
    val memoDesign: MemoDesignConfig = MemoDesignConfig(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
