package com.example.data.util

import android.util.Log

enum class OperationType {
    CREATE,
    READ,
    UPDATE,
    DELETE,
    LIST
}

fun handleFirestoreError(e: Exception, operationType: OperationType, path: String) {
    val errorDetails = """
        {
            "event": "firestore_error",
            "operation": "${operationType.name}",
            "path": "$path",
            "message": "${e.message?.replace("\"", "\\\"") ?: "Unknown error"}",
            "exception": "${e.javaClass.simpleName}"
        }
    """.trimIndent()
    Log.e("FirestoreError", errorDetails, e)
}
