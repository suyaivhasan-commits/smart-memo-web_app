package com.example.data.model

import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
data class MemoDesignConfig(
    val presetId: String = "PRESET_SANITARY_ELECTRIC",
    val primaryColorHex: String = "#0F2B48",       // Main header, borders, title
    val secondaryColorHex: String = "#00897B",     // Cash memo badge, highlight accents
    val tableHeaderBgHex: String = "#F1F5F9",      // Table header background
    val tableLineColorHex: String = "#334155",     // Grid & borders
    val logoPosition: String = "LEFT",             // "LEFT", "CENTER", "RIGHT"
    val logoSize: String = "MEDIUM",               // "SMALL", "MEDIUM", "LARGE"
    val showLogo: Boolean = true,
    val showShopPhoto: Boolean = false,
    val showProductImages: Boolean = true,
    val productImagesPosition: String = "BELOW_TABLE", // "BELOW_TABLE", "BESIDE_TOTALS"
    val studioImagePath: String = "",              // Persistent design image/banner picked in studio
    val showStudioImage: Boolean = true,           // Toggle to show/hide the studio design image
    val studioImagePosition: String = "TOP_BANNER",// "TOP_BANNER", "BELOW_TABLE", "BESIDE_TOTALS"
    val studioImageSize: String = "MEDIUM",        // "SMALL", "MEDIUM", "LARGE"
    val studioImagePadding: String = "NORMAL"      // "COMPACT", "NORMAL", "SPACIOUS"
) {
    companion object {
        val PRESET_FASHION = MemoDesignConfig(
            presetId = "PRESET_FASHION",
            primaryColorHex = "#881337",
            secondaryColorHex = "#BE185D",
            tableHeaderBgHex = "#FCE7F3",
            tableLineColorHex = "#9D174D",
            logoPosition = "LEFT",
            logoSize = "MEDIUM",
            showLogo = true,
            showShopPhoto = false,
            showProductImages = true,
            productImagesPosition = "BELOW_TABLE"
        )

        val PRESET_GROCERY = MemoDesignConfig(
            presetId = "PRESET_GROCERY",
            primaryColorHex = "#14532D",
            secondaryColorHex = "#16A34A",
            tableHeaderBgHex = "#DCFCE7",
            tableLineColorHex = "#15803D",
            logoPosition = "LEFT",
            logoSize = "MEDIUM",
            showLogo = true,
            showShopPhoto = false,
            showProductImages = true,
            productImagesPosition = "BELOW_TABLE"
        )

        val PRESET_SANITARY_ELECTRIC = MemoDesignConfig(
            presetId = "PRESET_SANITARY_ELECTRIC",
            primaryColorHex = "#0F2B48",
            secondaryColorHex = "#00897B",
            tableHeaderBgHex = "#E0F2F1",
            tableLineColorHex = "#334155",
            logoPosition = "LEFT",
            logoSize = "MEDIUM",
            showLogo = true,
            showShopPhoto = false,
            showProductImages = true,
            productImagesPosition = "BELOW_TABLE"
        )

        val PRESET_CLASSIC_BW = MemoDesignConfig(
            presetId = "PRESET_CLASSIC_BW",
            primaryColorHex = "#111827",
            secondaryColorHex = "#374151",
            tableHeaderBgHex = "#F3F4F6",
            tableLineColorHex = "#111827",
            logoPosition = "LEFT",
            logoSize = "MEDIUM",
            showLogo = true,
            showShopPhoto = false,
            showProductImages = true,
            productImagesPosition = "BELOW_TABLE"
        )
    }
}
