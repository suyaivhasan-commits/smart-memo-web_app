package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.Customer
import com.example.data.model.Memo
import com.example.data.model.MemoDesignConfig
import com.example.data.model.Payment
import com.example.data.model.Product
import com.example.data.model.ShopProfile
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ShopRepository(
    private val db: FirebaseFirestore
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be authenticated before accessing Firestore.")
    }

    // --- Shop Profile ---
    fun observeShopProfile(userId: String): Flow<ShopProfile?> {
        val path = "users/$userId/shop_profile/info"
        return db.collection("users").document(userId)
            .collection("shop_profile").document("info")
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    val profile = snapshot.toObject(ShopProfile::class.java)
                    val designMap = snapshot.get("memoDesign") as? Map<*, *>
                    if (designMap != null && profile != null) {
                        val customDesign = MemoDesignConfig(
                            presetId = (designMap["presetId"] as? String) ?: profile.memoDesign.presetId,
                            primaryColorHex = (designMap["primaryColorHex"] as? String) ?: profile.memoDesign.primaryColorHex,
                            secondaryColorHex = (designMap["secondaryColorHex"] as? String) ?: profile.memoDesign.secondaryColorHex,
                            tableHeaderBgHex = (designMap["tableHeaderBgHex"] as? String) ?: profile.memoDesign.tableHeaderBgHex,
                            tableLineColorHex = (designMap["tableLineColorHex"] as? String) ?: profile.memoDesign.tableLineColorHex,
                            logoPosition = (designMap["logoPosition"] as? String) ?: profile.memoDesign.logoPosition,
                            logoSize = (designMap["logoSize"] as? String) ?: profile.memoDesign.logoSize,
                            showLogo = (designMap["showLogo"] as? Boolean) ?: profile.memoDesign.showLogo,
                            showShopPhoto = (designMap["showShopPhoto"] as? Boolean) ?: profile.memoDesign.showShopPhoto,
                            showProductImages = (designMap["showProductImages"] as? Boolean) ?: profile.memoDesign.showProductImages,
                            productImagesPosition = (designMap["productImagesPosition"] as? String) ?: profile.memoDesign.productImagesPosition,
                            studioImagePath = (designMap["studioImagePath"] as? String) ?: profile.memoDesign.studioImagePath,
                            showStudioImage = (designMap["showStudioImage"] as? Boolean) ?: profile.memoDesign.showStudioImage,
                            studioImagePosition = (designMap["studioImagePosition"] as? String) ?: profile.memoDesign.studioImagePosition,
                            studioImageSize = (designMap["studioImageSize"] as? String) ?: profile.memoDesign.studioImageSize,
                            studioImagePadding = (designMap["studioImagePadding"] as? String) ?: profile.memoDesign.studioImagePadding
                        )
                        profile.copy(
                            memoDesign = customDesign,
                            shopType = snapshot.getString("shopType") ?: profile.shopType,
                            logoPath = snapshot.getString("logoPath") ?: profile.logoPath,
                            shopPhotoPath = snapshot.getString("shopPhotoPath") ?: profile.shopPhotoPath
                        )
                    } else {
                        profile
                    }
                } else {
                    null
                }
            }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.READ, path)
                emit(null)
            }
    }

    suspend fun saveShopProfile(profile: ShopProfile) {
        val uid = auth.currentUser?.uid ?: return
        val path = "users/$uid/shop_profile/info"
        try {
            val docRef = db.collection("users").document(uid)
                .collection("shop_profile").document("info")
            val memoDesignMap = mapOf(
                "presetId" to profile.memoDesign.presetId,
                "primaryColorHex" to profile.memoDesign.primaryColorHex,
                "secondaryColorHex" to profile.memoDesign.secondaryColorHex,
                "tableHeaderBgHex" to profile.memoDesign.tableHeaderBgHex,
                "tableLineColorHex" to profile.memoDesign.tableLineColorHex,
                "logoPosition" to profile.memoDesign.logoPosition,
                "logoSize" to profile.memoDesign.logoSize,
                "showLogo" to profile.memoDesign.showLogo,
                "showShopPhoto" to profile.memoDesign.showShopPhoto,
                "showProductImages" to profile.memoDesign.showProductImages,
                "productImagesPosition" to profile.memoDesign.productImagesPosition,
                "studioImagePath" to profile.memoDesign.studioImagePath,
                "showStudioImage" to profile.memoDesign.showStudioImage,
                "studioImagePosition" to profile.memoDesign.studioImagePosition,
                "studioImageSize" to profile.memoDesign.studioImageSize,
                "studioImagePadding" to profile.memoDesign.studioImagePadding
            )
            val payload = mapOf(
                "userId" to uid,
                "shopName" to profile.shopName,
                "ownerName" to profile.ownerName,
                "address" to profile.address,
                "phone" to profile.phone,
                "altPhone" to profile.altPhone,
                "email" to profile.email,
                "memoNotice" to profile.memoNotice,
                "paperSize" to profile.paperSize,
                "designStyle" to profile.designStyle,
                "shopType" to profile.shopType,
                "logoPath" to profile.logoPath,
                "shopPhotoPath" to profile.shopPhotoPath,
                "memoDesign" to memoDesignMap,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload, com.google.firebase.firestore.SetOptions.merge()).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            throw e
        }
    }

    // --- Memos ---
    fun observeMemos(userId: String): Flow<List<Memo>> {
        val path = "users/$userId/memos"
        return db.collection("users").document(userId)
            .collection("memos")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Memo::class.java).filter { !it.isDeleted }
            }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    suspend fun saveMemo(memo: Memo, isNew: Boolean = true): String {
        val uid = requireUserId()
        val colRef = db.collection("users").document(uid).collection("memos")
        val targetId = if (memo.id.isNotBlank()) memo.id else colRef.document().id
        val docRef = colRef.document(targetId)

        try {
            val memoToSave = memo.copy(
                id = targetId,
                userId = uid
            )
            docRef.set(memoToSave).await()

            // Update customer totals if customer name or phone is provided
            if (memo.customerName.isNotBlank() || memo.customerPhone.isNotBlank()) {
                updateCustomerFromMemo(uid, memo)
            }

            // Update product stock if items are present
            if (isNew) {
                deductInventoryStock(uid, memo)
            }

            return targetId
        } catch (e: Exception) {
            handleFirestoreError(e, if (isNew) OperationType.CREATE else OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    private suspend fun deductInventoryStock(userId: String, memo: Memo) {
        try {
            for (item in memo.items) {
                if (item.productName.isBlank()) continue
                val productsQuery = db.collection("users").document(userId)
                    .collection("products")
                    .whereEqualTo("name", item.productName)
                    .get()
                    .await()

                for (doc in productsQuery.documents) {
                    val currentStock = doc.getDouble("stock") ?: 0.0
                    val newStock = (currentStock - item.quantity).coerceAtLeast(0.0)
                    doc.reference.update(
                        mapOf(
                            "stock" to newStock,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$userId/products")
        }
    }

    private suspend fun updateCustomerFromMemo(userId: String, memo: Memo) {
        try {
            val phone = memo.customerPhone.trim()
            val name = memo.customerName.trim()
            val customersCol = db.collection("users").document(userId).collection("customers")

            val existingQuery = if (phone.isNotBlank()) {
                customersCol.whereEqualTo("phone", phone).get().await()
            } else {
                customersCol.whereEqualTo("name", name).get().await()
            }

            if (!existingQuery.isEmpty) {
                val custDoc = existingQuery.documents.first()
                val currentPurchases = custDoc.getDouble("totalPurchases") ?: 0.0
                val currentPaid = custDoc.getDouble("totalPaid") ?: 0.0
                val currentDue = custDoc.getDouble("totalDue") ?: 0.0
                val currentMemos = custDoc.getLong("memoCount") ?: 0L

                custDoc.reference.update(
                    mapOf(
                        "totalPurchases" to currentPurchases + memo.grandTotal,
                        "totalPaid" to currentPaid + memo.paidAmount,
                        "totalDue" to currentDue + memo.dueAmount,
                        "memoCount" to currentMemos + 1,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else if (name.isNotBlank() && phone.isNotBlank()) {
                val newCust = Customer(
                    userId = userId,
                    name = name,
                    phone = phone,
                    address = memo.customerAddress,
                    totalPurchases = memo.grandTotal,
                    totalPaid = memo.paidAmount,
                    totalDue = memo.dueAmount,
                    memoCount = 1
                )
                customersCol.add(newCust).await()
            }
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$userId/customers")
        }
    }

    suspend fun deleteMemo(userId: String, memoId: String) {
        val path = "users/$userId/memos/$memoId"
        try {
            db.collection("users").document(userId).collection("memos").document(memoId)
                .delete().await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            throw e
        }
    }

    suspend fun deleteMemos(userId: String, memoIds: List<String>) {
        if (memoIds.isEmpty()) return
        val memosCol = db.collection("users").document(userId).collection("memos")
        try {
            // Firestore batches support up to 500 writes
            memoIds.chunked(400).forEach { chunk ->
                val batch = db.batch()
                for (id in chunk) {
                    batch.delete(memosCol.document(id))
                }
                batch.commit().await()
            }
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "users/$userId/memos")
            throw e
        }
    }

    // --- Customers ---
    fun observeCustomers(userId: String): Flow<List<Customer>> {
        val path = "users/$userId/customers"
        return db.collection("users").document(userId)
            .collection("customers")
            .snapshots()
            .map { it.toObjects(Customer::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    suspend fun saveCustomer(customer: Customer) {
        val uid = requireUserId()
        val col = db.collection("users").document(uid).collection("customers")
        val targetId = if (customer.id.isNotBlank()) customer.id else col.document().id
        val docRef = col.document(targetId)
        try {
            docRef.set(customer.copy(id = targetId, userId = uid)).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    // --- Products ---
    fun observeProducts(userId: String): Flow<List<Product>> {
        val path = "users/$userId/products"
        return db.collection("users").document(userId)
            .collection("products")
            .snapshots()
            .map { it.toObjects(Product::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    suspend fun saveProduct(product: Product) {
        val uid = requireUserId()
        val col = db.collection("users").document(uid).collection("products")
        val targetId = if (product.id.isNotBlank()) product.id else col.document().id
        val docRef = col.document(targetId)
        try {
            docRef.set(product.copy(id = targetId, userId = uid)).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteProduct(userId: String, productId: String) {
        val path = "users/$userId/products/$productId"
        try {
            db.collection("users").document(userId).collection("products").document(productId)
                .delete().await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            throw e
        }
    }

    // --- Payments ---
    fun observePayments(userId: String): Flow<List<Payment>> {
        val path = "users/$userId/payments"
        return db.collection("users").document(userId)
            .collection("payments")
            .snapshots()
            .map { it.toObjects(Payment::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    suspend fun recordPayment(payment: Payment) {
        val uid = requireUserId()
        val col = db.collection("users").document(uid).collection("payments")
        val targetId = if (payment.id.isNotBlank()) payment.id else col.document().id
        val docRef = col.document(targetId)
        try {
            docRef.set(payment.copy(id = targetId, userId = uid)).await()

            // Update memo due if memoId is specified
            if (payment.memoId.isNotBlank()) {
                val memoRef = db.collection("users").document(uid).collection("memos").document(payment.memoId)
                val memoSnap = memoRef.get().await()
                if (memoSnap.exists()) {
                    val memo = memoSnap.toObject(Memo::class.java)
                    if (memo != null) {
                        val newPaid = memo.paidAmount + payment.amount
                        val newDue = (memo.grandTotal - newPaid).coerceAtLeast(0.0)
                        memoRef.update(
                            mapOf(
                                "paidAmount" to newPaid,
                                "dueAmount" to newDue,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                    }
                }
            }

            // Update customer totals
            if (payment.customerId.isNotBlank()) {
                val custRef = db.collection("users").document(uid).collection("customers").document(payment.customerId)
                val custSnap = custRef.get().await()
                if (custSnap.exists()) {
                    val cust = custSnap.toObject(Customer::class.java)
                    if (cust != null) {
                        val newPaid = cust.totalPaid + payment.amount
                        val newDue = (cust.totalDue - payment.amount).coerceAtLeast(0.0)
                        custRef.update(
                            mapOf(
                                "totalPaid" to newPaid,
                                "totalDue" to newDue,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                    }
                }
            }
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }
}
