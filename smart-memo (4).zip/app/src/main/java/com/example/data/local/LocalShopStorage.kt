package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.model.MemoDesignConfig
import com.example.data.model.ShopProfile
import org.json.JSONObject

class LocalShopStorage(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("smart_memo_shop_storage", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SHOP_PROFILE = "saved_shop_profile_json"
    }

    fun saveProfile(profile: ShopProfile): Boolean {
        return try {
            val json = profileToJson(profile)
            val success = prefs.edit().putString(KEY_SHOP_PROFILE, json.toString()).commit()
            Log.d("LocalShopStorage", "Profile saved locally with status: $success")
            success
        } catch (e: Exception) {
            Log.e("LocalShopStorage", "Error saving profile", e)
            false
        }
    }

    fun loadProfile(): ShopProfile? {
        val jsonStr = prefs.getString(KEY_SHOP_PROFILE, null) ?: return null
        return try {
            val json = JSONObject(jsonStr)
            jsonToProfile(json)
        } catch (e: Exception) {
            Log.e("LocalShopStorage", "Error loading profile", e)
            null
        }
    }

    private fun profileToJson(p: ShopProfile): JSONObject {
        val root = JSONObject()
        root.put("id", p.id)
        root.put("userId", p.userId)
        root.put("shopName", p.shopName)
        root.put("ownerName", p.ownerName)
        root.put("address", p.address)
        root.put("phone", p.phone)
        root.put("altPhone", p.altPhone)
        root.put("email", p.email)
        root.put("memoNotice", p.memoNotice)
        root.put("paperSize", p.paperSize)
        root.put("designStyle", p.designStyle)
        root.put("shopType", p.shopType)
        root.put("logoPath", p.logoPath)
        root.put("shopPhotoPath", p.shopPhotoPath)

        // Nested MemoDesignConfig
        val d = p.memoDesign
        val designJson = JSONObject()
        designJson.put("presetId", d.presetId)
        designJson.put("primaryColorHex", d.primaryColorHex)
        designJson.put("secondaryColorHex", d.secondaryColorHex)
        designJson.put("tableHeaderBgHex", d.tableHeaderBgHex)
        designJson.put("tableLineColorHex", d.tableLineColorHex)
        designJson.put("logoPosition", d.logoPosition)
        designJson.put("logoSize", d.logoSize)
        designJson.put("showLogo", d.showLogo)
        designJson.put("showShopPhoto", d.showShopPhoto)
        designJson.put("showProductImages", d.showProductImages)
        designJson.put("productImagesPosition", d.productImagesPosition)
        designJson.put("studioImagePath", d.studioImagePath)
        designJson.put("showStudioImage", d.showStudioImage)
        designJson.put("studioImagePosition", d.studioImagePosition)
        designJson.put("studioImageSize", d.studioImageSize)
        designJson.put("studioImagePadding", d.studioImagePadding)

        root.put("memoDesign", designJson)
        return root
    }

    private fun jsonToProfile(json: JSONObject): ShopProfile {
        val dJson = json.optJSONObject("memoDesign")
        val design = if (dJson != null) {
            MemoDesignConfig(
                presetId = dJson.optString("presetId", "PRESET_SANITARY_ELECTRIC"),
                primaryColorHex = dJson.optString("primaryColorHex", "#0F2B48"),
                secondaryColorHex = dJson.optString("secondaryColorHex", "#00897B"),
                tableHeaderBgHex = dJson.optString("tableHeaderBgHex", "#F1F5F9"),
                tableLineColorHex = dJson.optString("tableLineColorHex", "#334155"),
                logoPosition = dJson.optString("logoPosition", "LEFT"),
                logoSize = dJson.optString("logoSize", "MEDIUM"),
                showLogo = dJson.optBoolean("showLogo", true),
                showShopPhoto = dJson.optBoolean("showShopPhoto", false),
                showProductImages = dJson.optBoolean("showProductImages", true),
                productImagesPosition = dJson.optString("productImagesPosition", "BELOW_TABLE"),
                studioImagePath = dJson.optString("studioImagePath", ""),
                showStudioImage = dJson.optBoolean("showStudioImage", true),
                studioImagePosition = dJson.optString("studioImagePosition", "TOP_BANNER"),
                studioImageSize = dJson.optString("studioImageSize", "MEDIUM"),
                studioImagePadding = dJson.optString("studioImagePadding", "NORMAL")
            )
        } else {
            MemoDesignConfig()
        }

        return ShopProfile(
            id = json.optString("id", "info"),
            userId = json.optString("userId", ""),
            shopName = json.optString("shopName", "মেসার্স আল-আমিন ট্রেডার্স"),
            ownerName = json.optString("ownerName", "মোঃ আব্দুল করিম"),
            address = json.optString("address", "১২০, বাজার রোড, রাজশাহী"),
            phone = json.optString("phone", "০১৭১২-০৪৬৫৭৮"),
            altPhone = json.optString("altPhone", ""),
            email = json.optString("email", ""),
            memoNotice = json.optString("memoNotice", "ধন্যবাদ, আবার আসবেন"),
            paperSize = json.optString("paperSize", "A4"),
            designStyle = json.optString("designStyle", "STANDARD"),
            shopType = json.optString("shopType", "স্যানিটারি ও ইলেকট্রিক"),
            logoPath = json.optString("logoPath", ""),
            shopPhotoPath = json.optString("shopPhotoPath", ""),
            memoDesign = design
        )
    }
}
