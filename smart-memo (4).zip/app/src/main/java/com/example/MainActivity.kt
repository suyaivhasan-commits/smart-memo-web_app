package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.BackupScreen
import com.example.ui.screens.CustomerScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DueManagementScreen
import com.example.ui.screens.HelpScreen
import com.example.ui.screens.MemoArchiveScreen
import com.example.ui.screens.MemoDesignStudioScreen
import com.example.ui.screens.MemoDetailScreen
import com.example.ui.screens.NewMemoScreen
import com.example.ui.screens.ProductScreen
import com.example.ui.screens.ReportScreen
import com.example.ui.screens.ShopSettingsScreen
import com.example.ui.theme.SmartMemoTheme
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.SmartMemoViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SmartMemoTheme {
                AppRoot()
            }
        }
    }
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        if (currentUser == null) {
            AuthScreen(
                onAuthSuccess = {
                    currentUser = Firebase.auth.currentUser
                }
            )
        } else {
            val memoViewModel: SmartMemoViewModel = viewModel()
            MainAppContent(
                viewModel = memoViewModel,
                onLogout = {
                    Firebase.auth.signOut()
                    coroutineScope.launch {
                        try {
                            credentialManager.clearCredentialState(ClearCredentialStateRequest())
                        } catch (_: Exception) {}
                        currentUser = null
                    }
                }
            )
        }
    }
}

@Composable
fun MainAppContent(
    viewModel: SmartMemoViewModel,
    onLogout: () -> Unit
) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    when (currentScreen) {
        Screen.DASHBOARD -> {
            DashboardScreen(
                viewModel = viewModel,
                onLogoutClick = onLogout
            )
        }
        Screen.NEW_MEMO -> {
            NewMemoScreen(viewModel = viewModel)
        }
        Screen.MEMO_ARCHIVE -> {
            MemoArchiveScreen(viewModel = viewModel)
        }
        Screen.MEMO_DETAIL, Screen.PDF_PREVIEW -> {
            MemoDetailScreen(viewModel = viewModel)
        }
        Screen.CUSTOMERS -> {
            CustomerScreen(viewModel = viewModel)
        }
        Screen.PRODUCTS -> {
            ProductScreen(viewModel = viewModel)
        }
        Screen.DUE_MANAGEMENT -> {
            DueManagementScreen(viewModel = viewModel)
        }
        Screen.REPORTS -> {
            ReportScreen(viewModel = viewModel)
        }
        Screen.SHOP_SETTINGS -> {
            ShopSettingsScreen(viewModel = viewModel)
        }
        Screen.MEMO_DESIGN_STUDIO -> {
            MemoDesignStudioScreen(viewModel = viewModel)
        }
        Screen.BACKUP -> {
            BackupScreen(viewModel = viewModel)
        }
        Screen.HELP -> {
            HelpScreen(viewModel = viewModel)
        }
    }
}
