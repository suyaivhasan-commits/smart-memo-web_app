package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.Customer
import com.example.data.model.Memo
import com.example.data.model.MemoItem
import com.example.data.model.ShopProfile
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ShopRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun authenticatedUser_canSaveAndReadShopProfileAndMemos() = runBlocking {
        val uid = signInTestUser("shopkeeper@test.com")
        val repository = ShopRepository(firestore)

        val profile = ShopProfile(
            userId = uid,
            shopName = "মেসার্স আল-আমিন ট্রেডার্স",
            phone = "০১৭১২-০৪৬৫৭৮",
            address = "১২০, বাজার রোড, রাজশাহী"
        )
        repository.saveShopProfile(profile)

        val fetchedProfile = repository.observeShopProfile(uid).first()
        assertNotNull(fetchedProfile)
        assertEquals("মেসার্স আল-আমিন ট্রেডার্স", fetchedProfile?.shopName)

        val memo = Memo(
            userId = uid,
            memoNumber = "#0001",
            memoDate = "17-05-2025",
            customerName = "রহিম উদ্দিন",
            customerPhone = "01712000000",
            items = listOf(
                MemoItem(serial = 1, productName = "LED বাল্ব", quantity = 10.0, unitPrice = 50.0, totalPrice = 500.0)
            ),
            subtotal = 500.0,
            grandTotal = 500.0,
            paidAmount = 500.0,
            dueAmount = 0.0
        )
        val memoId = repository.saveMemo(memo, isNew = true)
        assertNotNull(memoId)

        val memos = repository.observeMemos(uid).first()
        assertTrue(memos.any { it.memoNumber == "#0001" })
    }

    @Test
    fun unauthenticatedUser_failsOperation() = runBlocking {
        auth.signOut()
        val repository = ShopRepository(firestore)

        var failed = false
        try {
            repository.saveCustomer(Customer(name = "করিম", phone = "01800000000"))
        } catch (e: Exception) {
            failed = true
        }
        assertTrue("Unauthenticated call must fail", failed)
    }
}
