package com.example

import com.example.data.model.MemoItem
import com.example.util.BengaliUtils
import org.junit.Assert.assertEquals
import org.junit.Test

class MemoCalculationTest {

    @Test
    fun testProductCalculation_10_x_50_equals_500() {
        val qty = BengaliUtils.parseNumber("10")
        val rate = BengaliUtils.parseNumber("50")
        val total = qty * rate
        assertEquals(500.0, total, 0.001)

        // Also test with Bengali numerals
        val qtyBn = BengaliUtils.parseNumber("১০")
        val rateBn = BengaliUtils.parseNumber("৫০")
        val totalBn = qtyBn * rateBn
        assertEquals(500.0, totalBn, 0.001)
    }

    @Test
    fun testProductCalculation_20_x_80_equals_1600() {
        val qty = BengaliUtils.parseNumber("20")
        val rate = BengaliUtils.parseNumber("80")
        val total = qty * rate
        assertEquals(1600.0, total, 0.001)

        val qtyBn = BengaliUtils.parseNumber("২০")
        val rateBn = BengaliUtils.parseNumber("৮০")
        val totalBn = qtyBn * rateBn
        assertEquals(1600.0, totalBn, 0.001)
    }

    @Test
    fun testSubtotal_GrandTotal_Due_Calculations() {
        // Item 1: 500 tk
        val item1Total = BengaliUtils.parseNumber("10") * BengaliUtils.parseNumber("50") // 500
        // Item 2: 300 tk
        val item2Total = BengaliUtils.parseNumber("6") * BengaliUtils.parseNumber("50")  // 300

        val subtotal = item1Total + item2Total
        assertEquals(800.0, subtotal, 0.001)

        val discount = BengaliUtils.parseNumber("20")
        val extraCharges = BengaliUtils.parseNumber("0")
        val grandTotal = (subtotal - discount + extraCharges).coerceAtLeast(0.0)
        assertEquals(780.0, grandTotal, 0.001)

        val paid = BengaliUtils.parseNumber("300")
        val due = (grandTotal - paid).coerceAtLeast(0.0)
        assertEquals(480.0, due, 0.001)
    }

    @Test
    fun testPagination_25ItemsIs1Page_26ItemsIs2Pages() {
        val items25 = List(25) { MemoItem(serial = it + 1, productName = "Item ${it + 1}") }
        val pages25 = ((items25.size - 1) / 25 + 1).coerceAtLeast(1)
        assertEquals(1, pages25)

        val items26 = List(26) { MemoItem(serial = it + 1, productName = "Item ${it + 1}") }
        val pages26 = ((items26.size - 1) / 25 + 1).coerceAtLeast(1)
        assertEquals(2, pages26)

        val items50 = List(50) { MemoItem(serial = it + 1, productName = "Item ${it + 1}") }
        val pages50 = ((items50.size - 1) / 25 + 1).coerceAtLeast(1)
        assertEquals(2, pages50)

        val items51 = List(51) { MemoItem(serial = it + 1, productName = "Item ${it + 1}") }
        val pages51 = ((items51.size - 1) / 25 + 1).coerceAtLeast(1)
        assertEquals(3, pages51)
    }

    @Test
    fun testBengaliNumberFormatting() {
        assertEquals("500", BengaliUtils.formatCleanNumber(500.0))
        assertEquals("1600", BengaliUtils.formatCleanNumber(1600.0))
        assertEquals("৳ 500", BengaliUtils.formatTaka(500.0))
        assertEquals("৳ ৫০০", BengaliUtils.formatTaka(500.0, inBangla = true))
    }
}
