const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: "127.0.0.1",
      port: 8085,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write memos", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("memos").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("memos").add({
    userId: ALICE_UID,
    memoNumber: "#0001",
    grandTotal: 1000
  }));
});

test("Authenticated Alice: can create and read her own memos", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const memoRef = aliceDb.collection("users").doc(ALICE_UID).collection("memos").doc("memo_1");
  await assertSucceeds(memoRef.set({
    userId: ALICE_UID,
    memoNumber: "#0001",
    grandTotal: 1250,
    customerName: "রহিম উদ্দিন",
    customerPhone: "01712000000"
  }));
  await assertSucceeds(memoRef.get());
});

test("Cross-user isolation: Bob cannot read or write Alice data", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("memos").doc("memo_1").set({
    userId: ALICE_UID,
    memoNumber: "#0001",
    grandTotal: 500
  }));

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("memos").doc("memo_1").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("memos").doc("memo_hacked").set({
    userId: ALICE_UID,
    memoNumber: "#0001",
    grandTotal: 500
  }));
});

test("Schema validation: memo missing grandTotal or invalid userId is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("users").doc(ALICE_UID).collection("memos").doc("inv_1").set({
    userId: ALICE_UID,
    memoNumber: "#0001"
  }));
  await assertFails(aliceDb.collection("users").doc(ALICE_UID).collection("memos").doc("inv_2").set({
    userId: BOB_UID,
    memoNumber: "#0002",
    grandTotal: 100
  }));
});
